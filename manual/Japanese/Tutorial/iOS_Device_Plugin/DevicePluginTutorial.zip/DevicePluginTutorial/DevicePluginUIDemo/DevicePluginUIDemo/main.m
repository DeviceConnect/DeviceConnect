/**
 main
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import <UIKit/UIKit.h>

#import "DevicePluginUIDemoAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DevicePluginUIDemoAppDelegate class]));
    }
}
