/**
 ExampleDevicePlugin
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "ExampleDevicePlugin.h"

#import "ExampleBatteryProfile.h"
#import "ExampleConnectProfile.h"
#import "ExampleDeviceOrientationProfile.h"
#import "ExampleFileDescriptorProfile.h"
#import "ExampleFileProfile.h"
#import "ExampleMediaPlayerProfile.h"
#import "ExampleMediaStreamRecordingProfile.h"
#import "ExampleNetworkServiceDiscoveryProfile.h"
#import "ExamplePhoneProfile.h"
#import "ExampleProximityProfile.h"
#import "ExampleSettingsProfile.h"
#import "ExampleSystemProfile.h"
#import "ExampleVibrationProfile.h"

@interface ExampleDevicePlugin ()

@property NSString *mDeviceId;
@property NSString *mDeviceName;
@property NSBundle *mBundle;

@end

@implementation ExampleDevicePlugin

- (instancetype) init {
    self = [super init];
    
    if (self) {
        self.mDeviceId = @"example_device_id";
        self.mBundle = [NSBundle bundleWithPath:[[NSBundle mainBundle] pathForResource:@"ExampleDevicePluginResources" ofType:@"bundle"]];
        self.pluginName = NSLocalizedStringFromTableInBundle(@"example device plugin name", nil, self.mBundle, nil);
        self.mDeviceName = NSLocalizedStringFromTableInBundle(@"example device", nil, self.mBundle, nil);
        
        [self addProfile:[ExampleSystemProfile new]];
        [self addProfile:[ExampleNetworkServiceDiscoveryProfile new]];
        
        [self addProfile:[ExampleBatteryProfile new]];
        [self addProfile:[ExampleConnectProfile new]];
        [self addProfile:[ExampleDeviceOrientationProfile new]];
        [self addProfile:[ExampleFileDescriptorProfile new]];
        [self addProfile:[ExampleFileProfile new]];
        [self addProfile:[ExampleMediaPlayerProfile new]];
        [self addProfile:[ExampleMediaStreamRecordingProfile new]];
        [self addProfile:[ExamplePhoneProfile new]];
        [self addProfile:[ExampleProximityProfile new]];
        [self addProfile:[ExampleSettingsProfile new]];
        [self addProfile:[ExampleVibrationProfile new]];
    }
    
    return self;
}

- (void) asyncSendEvent:(DConnectMessage *)event {
    [self asyncSendEvent:event delay:DEFAULT_EVENT_DELAY];
}

- (void) asyncSendEvent:(DConnectMessage *)event delay:(NSTimeInterval)delay {
    __block ExampleDevicePlugin *_self = self;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [NSThread sleepForTimeInterval:delay];
        [_self sendEvent:event];
    });
}

- (NSString *) deviceId {
    return _mDeviceId;
}

- (NSString *) deviceName {
    return _mDeviceName;
}

- (NSBundle *) devicePluginBundle
{
    return _mBundle;
}

@end
