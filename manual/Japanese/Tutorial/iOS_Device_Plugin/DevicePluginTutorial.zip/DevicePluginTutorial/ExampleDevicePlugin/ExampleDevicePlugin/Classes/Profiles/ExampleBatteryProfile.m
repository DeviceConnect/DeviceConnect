/**
 ExampleBatteryProfile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "ExampleBatteryProfile.h"

const double TestBatteryChargingTime = 50000.0;
const double TestBatteryDischargingTime = 10000.0;
const double TestBatteryLevel = 0.5;
const BOOL TestBatteryCharging = NO;

@interface ExampleBatteryProfile ()
@property (strong, nonatomic) NSTimer *onchargingchangeTimer;
@property (strong, nonatomic) NSTimer *onbatterychangeTimer;
@end

@implementation ExampleBatteryProfile

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.delegate = self;
    }
    return self;
}

#pragma mark - DConnectBatteryProfileDelegate

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceiveGetAllRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectBatteryProfile setCharging:TestBatteryCharging target:response];
    [DConnectBatteryProfile setChargingTime:TestBatteryChargingTime target:response];
    [DConnectBatteryProfile setDischargingTime:TestBatteryDischargingTime target:response];
    [DConnectBatteryProfile setLevel:TestBatteryLevel target:response];
    
    return YES;
}

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceiveGetLevelRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectBatteryProfile setLevel:TestBatteryLevel target:response];
    
    return YES;
}

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceiveGetChargingRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectBatteryProfile setCharging:TestBatteryCharging target:response];
    
    return YES;
}

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceiveGetChargingTimeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectBatteryProfile setChargingTime:TestBatteryChargingTime target:response];
    
    return YES;
}

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceiveGetDischargingTimeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectBatteryProfile setDischargingTime:TestBatteryDischargingTime target:response];
    
    return YES;
}

#pragma mark - Put Methods
#pragma mark Event Registration

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceivePutOnChargingChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
      sessionKey:(NSString *)sessionKey
{
    DConnectEventManager *eventMgr = [DConnectEventManager sharedManagerForClass:[self.provider class]];
    DConnectEventError error = [eventMgr addEventForRequest:request];
    switch (error) {
        case DConnectEventErrorNone:
            [response setResult:DConnectMessageResultTypeOk];
            
            // サンプル用イベントの定期的な送信を開始する
            @synchronized (self) {
                if (!_onchargingchangeTimer) {
                    _onchargingchangeTimer = [NSTimer timerWithTimeInterval:DEFAULT_EVENT_INTERVAL
                                                                     target:self
                                                                   selector:@selector(sendOnChargingChangeEvent:)
                                                                   userInfo:nil
                                                                    repeats:YES];
                    [[NSRunLoop mainRunLoop] addTimer:_onchargingchangeTimer forMode:NSDefaultRunLoopMode];
                }
            }
            break;
        case DConnectEventErrorInvalidParameter:
            [response setErrorToInvalidRequestParameter];
            break;
        default:
            [response setErrorToUnknown];
            break;
    }
    return YES;
}

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceivePutOnBatteryChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    DConnectEventManager *eventMgr = [DConnectEventManager sharedManagerForClass:[self.provider class]];
    DConnectEventError error = [eventMgr addEventForRequest:request];
    switch (error) {
        case DConnectEventErrorNone:
            [response setResult:DConnectMessageResultTypeOk];
            
            // サンプル用イベントの定期的な送信を開始する
            @synchronized (self) {
                if (!_onbatterychangeTimer) {
                    _onbatterychangeTimer = [NSTimer timerWithTimeInterval:DEFAULT_EVENT_INTERVAL
                                                                    target:self
                                                                  selector:@selector(sendOnBatteryChangeEvent:)
                                                                  userInfo:nil
                                                                   repeats:YES];
                    [[NSRunLoop mainRunLoop] addTimer:_onbatterychangeTimer forMode:NSDefaultRunLoopMode];
                }
            }
            break;
        case DConnectEventErrorInvalidParameter:
            [response setErrorToInvalidRequestParameter];
            break;
        default:
            [response setErrorToUnknown];
            break;
    }
    return YES;
}

#pragma mark - Delete Methods

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceiveDeleteOnChargingChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    DConnectEventManager *eventMgr = [DConnectEventManager sharedManagerForClass:[self.provider class]];
    DConnectEventError error = [eventMgr removeEventForRequest:request];
    switch (error) {
        case DConnectEventErrorNone:
            [response setResult:DConnectMessageResultTypeOk];
            @synchronized (self) {
                if (_onchargingchangeTimer) {
                    [_onchargingchangeTimer invalidate];
                    _onchargingchangeTimer = nil;
                }
            }
            break;
        case DConnectEventErrorInvalidParameter:
            [response setErrorToInvalidRequestParameter];
            break;
        default:
            [response setErrorToUnknown];
            break;
    }
    return YES;
}

- (BOOL) profile:(DConnectBatteryProfile *)profile didReceiveDeleteOnBatteryChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    DConnectEventManager *eventMgr = [DConnectEventManager sharedManagerForClass:[self.provider class]];
    DConnectEventError error = [eventMgr removeEventForRequest:request];
    switch (error) {
        case DConnectEventErrorNone:
            [response setResult:DConnectMessageResultTypeOk];
            @synchronized (self) {
                if (_onbatterychangeTimer) {
                    [_onbatterychangeTimer invalidate];
                    _onbatterychangeTimer = nil;
                }
            }
            break;
        case DConnectEventErrorInvalidParameter:
            [response setErrorToInvalidRequestParameter];
            break;
        default:
            [response setErrorToUnknown];
            break;
    }
    return YES;
}

#pragma mark - Sending sample event

- (void) sendOnChargingChangeEvent:(NSTimer*)timer
{
    DConnectEventManager *mgr = [DConnectEventManager sharedManagerForClass:[self.provider class]];
    NSArray *events = [mgr eventListForDeviceId:[THIS_PLUGIN deviceId] profile:self.profileName attribute:DConnectBatteryProfileAttrOnChargingChange];
    for (DConnectEvent *event in events) {
        DConnectMessage *eventMsg = [DConnectMessage message];
        [eventMsg setString:event.sessionKey forKey:DConnectMessageSessionKey];
        [eventMsg setString:event.deviceId forKey:DConnectMessageDeviceId];
        [eventMsg setString:event.profile forKey:DConnectMessageProfile];
        [eventMsg setString:event.attribute forKey:DConnectMessageAttribute];
        
        DConnectMessage *battery = [DConnectMessage message];
        [DConnectBatteryProfile setCharging:TestBatteryCharging target:battery];
        [DConnectBatteryProfile setBattery:battery target:eventMsg];
        
        [THIS_PLUGIN asyncSendEvent:eventMsg];
    }
}

- (void) sendOnBatteryChangeEvent:(NSTimer*)timer
{
    DConnectEventManager *mgr = [DConnectEventManager sharedManagerForClass:[self.provider class]];
    NSArray *events = [mgr eventListForDeviceId:[THIS_PLUGIN deviceId] profile:self.profileName attribute:DConnectBatteryProfileAttrOnBatteryChange];
    for (DConnectEvent *event in events) {
        DConnectMessage *eventMsg = [DConnectMessage message];
        [eventMsg setString:event.sessionKey forKey:DConnectMessageSessionKey];
        [eventMsg setString:event.deviceId forKey:DConnectMessageDeviceId];
        [eventMsg setString:event.profile forKey:DConnectMessageProfile];
        [eventMsg setString:event.attribute forKey:DConnectMessageAttribute];
        
        DConnectMessage *battery = [DConnectMessage message];
        [DConnectBatteryProfile setChargingTime:TestBatteryChargingTime target:battery];
        [DConnectBatteryProfile setDischargingTime:TestBatteryDischargingTime target:battery];
        [DConnectBatteryProfile setLevel:TestBatteryLevel target:battery];
        [DConnectBatteryProfile setBattery:battery target:eventMsg];
        
        [THIS_PLUGIN asyncSendEvent:eventMsg];
    }
}

@end
