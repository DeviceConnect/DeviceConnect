/**
 ExampleDevicePlugin
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import <DConnectSDK/DConnectSDK.h>

@interface ExampleDevicePlugin : DConnectDevicePlugin

- (void) asyncSendEvent:(DConnectMessage *)event;
- (void) asyncSendEvent:(DConnectMessage *)event delay:(NSTimeInterval)delay;

- (NSString *) deviceId;
- (NSString *) deviceName;

/// このデバイスプラグインのバンドルを返す。
- (NSBundle *) devicePluginBundle;

@end
