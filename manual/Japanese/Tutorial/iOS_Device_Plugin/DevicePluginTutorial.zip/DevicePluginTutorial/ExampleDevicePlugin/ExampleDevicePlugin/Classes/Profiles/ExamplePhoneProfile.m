/**
 ExamplePhoneProfile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "ExamplePhoneProfile.h"

@implementation ExamplePhoneProfile

- (instancetype)init
{
    self = [super init];
    
    if (self) {
        self.delegate = self;
    }
    
    return self;
}

#pragma mark - Post Methods

- (BOOL) profile:(DConnectPhoneProfile *)profile didReceivePostCallRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId phoneNumber:(NSString *)phoneNumber
{
    if (phoneNumber == nil || phoneNumber.length == 0) {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

#pragma mark - Put Methods
- (BOOL) profile:(DConnectPhoneProfile *)profile didReceivePutSetRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
            mode:(NSNumber *)mode
{
    if (mode == nil || [mode intValue] == DConnectPhoneProfilePhoneModeUnknown) {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

#pragma mark Event Registration

- (BOOL) profile:(DConnectPhoneProfile *)profile didReceivePutOnConnectRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
      sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    DConnectMessage *event = [DConnectMessage message];
    [event setString:sessionKey forKey:DConnectMessageSessionKey];
    [event setString:self.profileName forKey:DConnectMessageProfile];
    [event setString:DConnectPhoneProfileAttrOnConnect forKey:DConnectMessageAttribute];
    
    DConnectMessage *phoneStatus = [DConnectMessage message];
    [DConnectPhoneProfile setPhoneNumber:@"090xxxxxxxx" target:phoneStatus];
    [DConnectPhoneProfile setState:DConnectPhoneProfileCallStateFinished target:phoneStatus];
    
    [DConnectPhoneProfile setPhoneStatus:phoneStatus target:event];
    [THIS_PLUGIN asyncSendEvent:event];
    
    return YES;
}

#pragma mark - Delete Methods
#pragma mark Event Unregistration

- (BOOL) profile:(DConnectPhoneProfile *)profile didReceiveDeleteOnConnectRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
      sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

@end
