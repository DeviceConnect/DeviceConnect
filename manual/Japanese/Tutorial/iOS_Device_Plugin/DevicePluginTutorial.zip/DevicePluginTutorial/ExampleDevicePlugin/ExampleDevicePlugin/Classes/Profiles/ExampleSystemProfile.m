/**
 ExampleSystemProfile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import <UIKit/UIKit.h>

#import "ExampleSystemProfile.h"

@interface ExampleSystemProfile ()

@property NSString *mDisplayName;
@property NSString *mDetail;

@end

@implementation ExampleSystemProfile

- (id)init {
    self = [super init];
    if (self) {
        self.dataSource = self;
        
        NSBundle *bundle = [THIS_PLUGIN devicePluginBundle];
        self.mDisplayName = NSLocalizedStringFromTableInBundle(@"example system profile displayName", nil, bundle, nil);
        self.mDetail = NSLocalizedStringFromTableInBundle(@"example system profile detail", nil, bundle, nil);
    }
    return self;
}

- (NSString *)displayName {
    return _mDisplayName;
}

- (NSString *)detail {
    return _mDetail;
}

- (NSString *) versionOfSystemProfile:(DConnectSystemProfile *)profile {
    return @"1.0";
}

- (UIViewController *) profile:(DConnectSystemProfile *)sender settingPageForRequest:(DConnectRequestMessage *)request {
    
    // 設定画面用のViewControllerをStoryboardから生成する
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"ExampleDevicePluginResources" ofType:@"bundle"];
    NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
    
    UIStoryboard *sb = [UIStoryboard storyboardWithName:@"ExampleDevicePlugin" bundle:bundle];
    
    return [sb instantiateInitialViewController];
}


@end
