//
//  SampleApp1Tests.m
//  SampleApp1Tests
//
//  Created by Mitsuhiro Suzuki on 2014/09/20.
//  Copyright (c) 2014年 NTT DOCOMO, INC. All rights reserved.
//

//
//  DeviceConnectUIAppTutorialTests.m
//  DeviceConnectUIAppTutorial
//
//  Copyright (c) 2014 NTT DOCOMO, INC.
//  Released under the MIT license
//  http://opensource.org/licenses/mit-license.php
//


#import <XCTest/XCTest.h>

@interface DeviceConnectUIAppTutorialTests : XCTestCase

@end

@implementation DeviceConnectUIAppTutorialTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
