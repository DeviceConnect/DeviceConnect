/**
 ExampleNetworkServiceDiscoveryProfile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "ExampleNetworkServiceDiscoveryProfile.h"

@implementation ExampleNetworkServiceDiscoveryProfile

- (id)init
{
    self = [super init];
    if (self) {
        self.delegate = self;
    }
    return self;
    
}

- (BOOL)                       profile:(DConnectNetworkServiceDiscoveryProfile *)profile
didReceiveGetGetNetworkServicesRequest:(DConnectRequestMessage *)request
                              response:(DConnectResponseMessage *)response
{
    DConnectMessage *service = [DConnectMessage message];
    [DConnectNetworkServiceDiscoveryProfile setId:[THIS_PLUGIN deviceId] target:service];
    [DConnectNetworkServiceDiscoveryProfile setName:[THIS_PLUGIN deviceName] target:service];
    [DConnectNetworkServiceDiscoveryProfile setType:DConnectNetworkServiceDiscoveryProfileNetworkTypeWiFi
                                             target:service];
    [DConnectNetworkServiceDiscoveryProfile setOnline:YES target:service];
    
    DConnectArray *services = [DConnectArray array];
    [services addMessage:service];
    [DConnectNetworkServiceDiscoveryProfile setServices:services target:response];
    
    [response setResult:DConnectMessageResultTypeOk];
    return YES;
}

@end
