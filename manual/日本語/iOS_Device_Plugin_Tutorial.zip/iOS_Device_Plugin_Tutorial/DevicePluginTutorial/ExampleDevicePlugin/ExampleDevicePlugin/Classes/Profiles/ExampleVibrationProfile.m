/**
 ExampleVibrationProfile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "ExampleVibrationProfile.h"

@implementation ExampleVibrationProfile

- (id) init {
    self = [super init];
    
    if (self) {
        self.delegate = self;
    }
    
    return self;
}

#pragma mark - Put Methods

- (BOOL) profile:(DConnectVibrationProfile *)profile didReceivePutVibrateRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId pattern:(NSArray *) pattern
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

#pragma mark - Delete Methods

- (BOOL) profile:(DConnectVibrationProfile *)profile didReceiveDeleteVibrateRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

@end
