/**
 ExampleSettingsProfile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "ExampleSettingsProfile.h"

const double TestSettingsLevel = 0.5;
NSString *const TestSettingsDate = @"2014-01-01T01:01:01+09:00";

@implementation ExampleSettingsProfile

- (id) init {
    self = [super init];
    
    if (self) {
        self.delegate = self;
    }
    
    return self;
}

#pragma mark - Get Methods

- (BOOL) profile:(DConnectSettingsProfile *)profile didReceiveGetVolumeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId kind:(DConnectSettingsProfileVolumeKind)kind
{
    if (kind == DConnectSettingsProfileVolumeKindUnknown) {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
        [DConnectSettingsProfile setVolumeLevel:TestSettingsLevel target:response];
    }
    
    return YES;
}
- (BOOL) profile:(DConnectSettingsProfile *)profile didReceiveGetDateRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectSettingsProfile setDate:TestSettingsDate target:response];
    
    return YES;
}
- (BOOL) profile:(DConnectSettingsProfile *)profile didReceiveGetLightRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectSettingsProfile setLightLevel:TestSettingsLevel target:response];
    
    return YES;
}

- (BOOL) profile:(DConnectSettingsProfile *)profile didReceiveGetSleepRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectSettingsProfile setTime:1 target:response];
    
    return YES;
}

#pragma mark - Put Methods

- (BOOL) profile:(DConnectSettingsProfile *)profile didReceivePutVolumeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId kind:(DConnectSettingsProfileVolumeKind)kind
           level:(NSNumber *)level
{
    if (kind == DConnectSettingsProfileVolumeKindUnknown
        || level == nil || [level doubleValue] < DConnectSettingsProfileMinLevel
        || [level doubleValue] > DConnectSettingsProfileMaxLevel)
    {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

- (BOOL) profile:(DConnectSettingsProfile *)profile didReceivePutDateRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId date:(NSString *)date
{
    if (date == nil) {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

- (BOOL) profile:(DConnectSettingsProfile *)profile didReceivePutLightRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId level:(NSNumber *)level
{
    if (level == nil || [level doubleValue] < DConnectSettingsProfileMinLevel
        || [level doubleValue] > DConnectSettingsProfileMaxLevel)
    {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

- (BOOL) profile:(DConnectSettingsProfile *)profile didReceivePutSleepRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId time:(NSNumber *)time
{
    if (time == nil) {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

@end
