/**
 ExampleConnectProfile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "ExampleConnectProfile.h"

@implementation ExampleConnectProfile

- (instancetype) init {
    self = [super init];
    
    if (self) {
        self.delegate = self;
    }
    
    return self;
}

#pragma mark - DConnectConnectProfileDelegate
#pragma mark - Get Methods

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveGetWifiRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectConnectProfile setEnable:YES target:response];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveGetBluetoothRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectConnectProfile setEnable:YES target:response];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveGetBLERequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectConnectProfile setEnable:YES target:response];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveGetNFCRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    [DConnectConnectProfile setEnable:YES target:response];
    
    return YES;
}

#pragma mark - Put Methods

- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutWiFiRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutBluetoothRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutBluetoothDiscoverableRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutBLERequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutNFCRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

#pragma mark - Event Registration

- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutOnWifiChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    DConnectMessage *event = [DConnectMessage message];
    [event setString:sessionKey forKey:DConnectMessageSessionKey];
    [event setString:deviceId forKey:DConnectMessageDeviceId];
    [event setString:self.profileName forKey:DConnectMessageProfile];
    [event setString:DConnectConnectProfileAttrOnWifiChange forKey:DConnectMessageAttribute];
    
    DConnectMessage *connectStatus = [DConnectMessage message];
    [DConnectConnectProfile setEnable:YES target:connectStatus];
    
    [DConnectConnectProfile setConnectStatus:connectStatus target:event];
    [THIS_PLUGIN asyncSendEvent:event];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutOnBluetoothChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    DConnectMessage *event = [DConnectMessage message];
    [event setString:sessionKey forKey:DConnectMessageSessionKey];
    [event setString:deviceId forKey:DConnectMessageDeviceId];
    [event setString:self.profileName forKey:DConnectMessageProfile];
    [event setString:DConnectConnectProfileAttrOnBluetoothChange forKey:DConnectMessageAttribute];
    
    DConnectMessage *connectStatus = [DConnectMessage message];
    [DConnectConnectProfile setEnable:YES target:connectStatus];
    
    [DConnectConnectProfile setConnectStatus:connectStatus target:event];
    [THIS_PLUGIN asyncSendEvent:event];
    
    return YES;
}


- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutOnBLEChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    DConnectMessage *event = [DConnectMessage message];
    [event setString:sessionKey forKey:DConnectMessageSessionKey];
    [event setString:deviceId forKey:DConnectMessageDeviceId];
    [event setString:self.profileName forKey:DConnectMessageProfile];
    [event setString:DConnectConnectProfileAttrOnBLEChange forKey:DConnectMessageAttribute];
    
    DConnectMessage *connectStatus = [DConnectMessage message];
    [DConnectConnectProfile setEnable:YES target:connectStatus];
    
    [DConnectConnectProfile setConnectStatus:connectStatus target:event];
    [THIS_PLUGIN asyncSendEvent:event];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceivePutOnNFCChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    DConnectMessage *event = [DConnectMessage message];
    [event setString:sessionKey forKey:DConnectMessageSessionKey];
    [event setString:deviceId forKey:DConnectMessageDeviceId];
    [event setString:self.profileName forKey:DConnectMessageProfile];
    [event setString:DConnectConnectProfileAttrOnNFCChange forKey:DConnectMessageAttribute];
    
    DConnectMessage *connectStatus = [DConnectMessage message];
    [DConnectConnectProfile setEnable:YES target:connectStatus];
    
    [DConnectConnectProfile setConnectStatus:connectStatus target:event];
    [THIS_PLUGIN asyncSendEvent:event];
    
    return YES;
}

#pragma mark - Delete Methods

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteWiFiRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}


- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteBluetoothRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}


- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteBluetoothDiscoverableRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteBLERequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteNFCRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

#pragma mark - Event Unregistration

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteOnWifiChangeRequest:(DConnectRequestMessage *)request response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteOnBluetoothChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteOnBLEChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

- (BOOL) profile:(DConnectConnectProfile *)profile didReceiveDeleteOnNFCChangeRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response deviceId:(NSString *)deviceId sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

#pragma mark - Sending sample event

- (void) sendOnWifiChangeEvent:(NSTimer *)timer
{
    
}

- (void) sendOnBluetoothChangeEvent:(NSTimer *)timer
{
    
}

- (void) sendOnBLEChangeEvent:(NSTimer *)timer
{
    
}

- (void) sendOnNFCChangeEvent:(NSTimer *)timer
{
    
}

@end
