/**
 ExampleFileDescriptorProfile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "ExampleFileDescriptorProfile.h"

const int TestFileDescriptorFileSize = 64000;
NSString *const TestFileDescriptorPath = @"test.txt";
NSString *const TestFileDescriptorUri = @"test_uri";
NSString *const TestFileDescriptorCurr = @"2014-06-01T00:00:00+0900";
NSString *const TestFileDescriptorPrev = @"2014-06-01T00:00:00+0900";

@implementation ExampleFileDescriptorProfile

- (instancetype) init {
    self = [super init];
    
    if (self) {
        self.delegate = self;
    }
    
    return self;
}

#pragma mark - Get Methods

- (BOOL) profile:(DConnectFileDescriptorProfile *)profile didReceiveGetOpenRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
            path:(NSString *)path
            flag:(NSString *)flag
{
    if (path == nil || flag == nil) {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

- (BOOL) profile:(DConnectFileDescriptorProfile *)profile didReceiveGetReadRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
            path:(NSString *)path
          length:(NSNumber *)length
        position:(NSNumber *)position
{
    if (path == nil || length == nil || length < 0 || (position != nil && position < 0)) {
        [response setErrorToInvalidRequestParameter];
    } else {
        
        NSData *data = [NSData data];
        NSString *fileData = [data base64EncodedStringWithOptions:kNilOptions];
        [response setResult:DConnectMessageResultTypeOk];
        [DConnectFileDescriptorProfile setSize:TestFileDescriptorFileSize target:response];
        [DConnectFileDescriptorProfile setFileData:fileData target:response];
    }
    
    return YES;
}

#pragma mark - Put Methods

- (BOOL) profile:(DConnectFileDescriptorProfile *)profile didReceivePutCloseRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
            path:(NSString *)path
{
    if (path == nil) {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

- (BOOL) profile:(DConnectFileDescriptorProfile *)profile didReceivePutWriteRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
            path:(NSString *)path
           media:(NSData *)media
        position:(NSNumber *)position
{
    if (path == nil || media == nil || (position != nil && position < 0)) {
        [response setErrorToInvalidRequestParameter];
    } else {
        [response setResult:DConnectMessageResultTypeOk];
    }
    
    return YES;
}

#pragma mark Event Registration

- (BOOL) profile:(DConnectFileDescriptorProfile *)profile didReceivePutOnWatchFileRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
      sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    DConnectMessage *event = [DConnectMessage message];
    [event setString:sessionKey forKey:DConnectMessageSessionKey];
    [event setString:self.profileName forKey:DConnectMessageProfile];
    [event setString:DConnectFileDescriptorProfileAttrOnWatchFile forKey:DConnectMessageAttribute];
    
    DConnectMessage *file = [DConnectMessage message];
    [DConnectFileDescriptorProfile setPath:TestFileDescriptorPath target:file];
    [DConnectFileDescriptorProfile setCurr:TestFileDescriptorCurr target:file];
    [DConnectFileDescriptorProfile setPrev:TestFileDescriptorPrev target:file];
    
    [DConnectFileDescriptorProfile setFile:file target:event];
    [THIS_PLUGIN asyncSendEvent:event];
    
    return YES;
}

#pragma mark - Delete Methods
#pragma mark Event Unregistration

- (BOOL) profile:(DConnectFileDescriptorProfile *)profile didReceiveDeleteOnWatchFileRequest:(DConnectRequestMessage *)request
        response:(DConnectResponseMessage *)response
        deviceId:(NSString *)deviceId
      sessionKey:(NSString *)sessionKey
{
    [response setResult:DConnectMessageResultTypeOk];
    
    return YES;
}

@end
