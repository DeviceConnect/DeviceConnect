/**
 DevicePluginUIDemoViewController
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import "DevicePluginUIDemoViewController.h"
#import <DConnectSDK/DConnectSDK.h>

@interface DevicePluginUIDemoViewController ()
@property (nonatomic) NSString *deviceId;
@end

@implementation DevicePluginUIDemoViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// デバイスIDの初期化
    self.deviceId = nil;
    
    // dConnect準備
    DConnectManager *mgr = [DConnectManager sharedManager];
    [mgr start];
    [mgr startWebsocket];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// NetworkServiceDiscovery
- (IBAction)pushDiscoveryBtn:(id)sender
{
    self.deviceLabel.text = @"no device.";
	
	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
        DConnectManager *manager = [DConnectManager sharedManager];
        DConnectRequestMessage *req = [DConnectRequestMessage new];
		
        [req setAction:DConnectMessageActionTypeGet];
        [req setProfile:DConnectNetworkServiceDiscoveryProfileName];
        [req setAttribute:DConnectNetworkServiceDiscoveryProfileAttrGetNetworkServices];
		NSLog(@"%@", DConnectNetworkServiceDiscoveryProfileName);
        [manager sendRequest:req callback:^(DConnectResponseMessage *response) {
            NSLog(@"RESPONSE: %lu", (unsigned long)[response result]);
            
            DConnectArray *services = [response arrayForKey:DConnectNetworkServiceDiscoveryProfileParamServices];
            NSLog(@"number of services: %d", [services count]);
            for (int i = 0; i < [services count]; ++i) {
                DConnectMessage *msg = [services messageAtIndex:i];
                NSLog(@"device name: %@", [msg stringForKey:DConnectNetworkServiceDiscoveryProfileParamName]);
                NSLog(@"device id: %@", [msg stringForKey:DConnectNetworkServiceDiscoveryProfileParamId]);
                
                //DeviceIdの取得
                self.deviceId = [msg stringForKey:DConnectNetworkServiceDiscoveryProfileParamId];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.deviceLabel.text = [msg stringForKey:DConnectNetworkServiceDiscoveryProfileParamName];
                });
            }
        }];
	});
}

// /system/device/wakeup
- (IBAction)pushOpenSettingBtn:(id)sender
{
    if (!self.deviceId) {
        NSLog(@"Perform Network Service Discovery first.");
        return;
    }
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0),^{
        DConnectManager *manager = [DConnectManager sharedManager];
        DConnectRequestMessage *req = [DConnectRequestMessage new];
        NSLog(@"device id: %@", self.deviceId);
        [req setAction:DConnectMessageActionTypePut];
        [req setProfile:DConnectSystemProfileName];
        [req setInterface:DConnectSystemProfileAttrDevice];
        [req setAttribute:DConnectSystemProfileAttrWakeUp];
        [req setPluginId:self.deviceId];
        [manager sendRequest:req callback:^(DConnectResponseMessage *response) {
            NSLog(@"RESPONSE: %lu", (unsigned long)[response result]);
        }];
    });
}

@end
