/**
 DevicePluginUIDemoViewController
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

#import <UIKit/UIKit.h>

@interface DevicePluginUIDemoViewController : UIViewController

@property (nonatomic) IBOutlet UILabel *deviceLabel;
- (IBAction)pushDiscoveryBtn:(id)sender;
- (IBAction)pushOpenSettingBtn:(id)sender;

@end
