/**
 * d-Connect SDK for Javascript.
 * @file
 */

var dconnectsdk = require("src/dconnectsdk");
exports = module.exports;

/**
 * d-Connect Class.
 */
exports.dConnect = dconnectsdk.dConnect;

