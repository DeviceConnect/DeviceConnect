/**
 * @constructor
 * @desc Τεκμηρίωση είναι η επικοινωνία!
 */
Test = function() {
};