/**
 * @type {(string|number)} A string or a number.
 */
var stringOrNumber;
