/** @namespace */
var x = {
};
/** @namespace Foo */
/** @namespace {function} Bar */

/** @namespace */
var S = {
	/** Member of the namespace S. */
	Socket: function() {}
};
