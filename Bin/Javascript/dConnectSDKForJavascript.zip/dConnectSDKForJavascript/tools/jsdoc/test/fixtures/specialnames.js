/** document me */
var hasOwnProperty = Object.prototype.hasOwnProperty;