/** @namespace */
var contacts = {

    /** @namespace */
    'say-"hello"@example.com': {

        /** document me */
        "username": 'Sue Smart'
    }
}