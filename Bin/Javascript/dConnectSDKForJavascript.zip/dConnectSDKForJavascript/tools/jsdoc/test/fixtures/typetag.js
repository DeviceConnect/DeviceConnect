/**
 * @type {string|Array<string>}
 */
var foo;

/**
 * @type integer
 */
var bar = +(new Date()).getTime();

/**
 * @type {!Array.<number>}
 */
var baz = [1, 2, 3];
