/**
 * Test {@tutorial test2} {@tutorial dupa}
 *
 * @class
 * @tutorial test
 * @tutorial jasia
 */
function Test() {}
