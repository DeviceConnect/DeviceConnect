/*global describe: true, expect: true, it: true, xdescribe: true, xit: true */
xdescribe('jsdoc/template', function() {
    // TODO
});
