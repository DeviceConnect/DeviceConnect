Device Connect SDK for Javascript

