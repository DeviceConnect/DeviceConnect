
describe('dConnect', function() {

  describe('#constructor()', function(){

    it('create instance', function(done){
      new dConnect();
      done();
    });

  });

  describe('#execute()', function(){

    it('get system information', function(done){
      var dconn = new dConnect();
      dconn.execute("http://localhost:3000/system/", null, null, function(data) {
        data.should.be.not.equal(null);
        data.should.be.not.equal(undefined);
        done();
      })
    });

    it('get error information', function(done){
      var dconn = new dConnect();
      dconn.execute("http://localhost:3000/system/error", null, null, function(data) {
        data.should.be.not.equal(null);
        data.should.be.not.equal(undefined);
        done();
      })
    });

    it('get battery information', function(done){
      var dconn = new dConnect();
      dconn.execute("http://localhost:3000/battery/level/01234", null, null, function(data) {
        data.should.be.not.equal(null);
        data.should.be.not.equal(undefined);
        done();
      })
    });

    it('get battery information', function(done){
      var dconn = new dConnect();
      dconn.execute("http://localhost:3000/battery/level/01234", null, null, function(data) {
        data.should.be.not.equal(null);
        data.should.be.not.equal(undefined);
        done();
      })
    });

  });

});
