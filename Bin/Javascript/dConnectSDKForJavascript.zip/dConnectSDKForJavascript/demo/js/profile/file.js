/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * File Profile
 */
function showFile(deviceId) {

    initContents();
    initListView();

    setTitle("File Profile");

    var str = "";
    var path = "/";
    str += '<li><a href="javascript:showFileList(\'' + deviceId + '\',\'' + path + '\');" value="list">File Manager</a></li>';
    str += '<li><a href="javascript:showFileSend(\'' + deviceId + '\');" value="send">File Upaloader</a></li>';

    var listHtml = document.getElementById('list');
    listHtml.innerHTML = str;
    $("#list").listview("refresh");

    var str = "";
    str += getProfileListLink(deviceId);

    $('#contents').html(str).trigger('create');
}


/**
 * File Manager
 * file/list
 */
function showFileList(deviceId, path) {

    initContents();
    initResult();

    var builder = new dConnect.URIBuilder();
    builder.setProfile("file");
    builder.setAttribute("list");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("path", path);
    var uri = builder.build();

    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
            setTitle("File list", "black");

            var cmdStr = "";
            cmdStr = '<input data-icon="folder" data-inline="true" data-mini="true" onclick="javascript:showFileList(\'' + deviceId + '\',\'/\');" type="button" value="/"/>';
            cmdStr += '<input data-icon="delete" data-inline="true" data-mini="true" onclick="javascript:changeDeleteMode(\'' + deviceId + '\');" type="button" value="Delete Mode"/>';

            $('#command').html(cmdStr).trigger('create');

            var str = "";
            for (var i = 0; i < json.files.length; i++) {
                var iconName = getFileIcon(json.files[i].mimeType);
                if (json.files[i].mimeType == "dir/folder") {
                    str += '<li><a href="javascript:showFileList(\'' + deviceId + '\',\'' + json.files[i].path + '\');"  ><img src=\'' + iconName + '\' >' + json.files[i].fileName + '</a></li>';
                } else {
                    str += '<li><a href="javascript:doFileAction(\'' + deviceId + '\',\'' + json.files[i].path + '\',\'' + json.files[i].mimeType + '\');"  ><img src=\'' + iconName + '\' >' + json.files[i].fileName + '</a></li>';
                }
            }

            var listHtml = document.getElementById('list');
            listHtml.innerHTML = str;
            $("#list").listview("refresh");

            var str = "";
            str += '<center><input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showFile(\'' + deviceId + '\');" type="button" value="File Top"/></center>';
            $('#result').html(str).trigger('create');
        } else {

        }
    }, function(xhr, textStatus, errorThrown) {

    });

}

/**
 * file delMode
 */
function changeDeleteMode(deviceId) {

    deleteMode = true;
    setTitle("ファイル一覧(削除モード)", "red");

    var cmdStr = "";
    cmdStr = '<input data-icon="folder" data-inline="true" data-mini="true" onclick="javascript:showFileList(\'' + deviceId + '\',\'/\');" type="button" value="/"/>';
    cmdStr += '<input data-icon="delete" data-inline="true" data-mini="true" onclick="javascript:changeNormalMode(\'' + deviceId + '\');" type="button" value="Normal  Mode"/>';



    $('#command').html(cmdStr).trigger('create');
}



/**
 * file normalMode
 */
function changeNormalMode(deviceId) {
    deleteMode = false;
    setTitle("ファイル一覧", "black");
    var cmdStr = "";
    cmdStr = '<input data-icon="folder" data-inline="true" data-mini="true" onclick="javascript:showFileList(\'' + deviceId + '\',\'/\');" type="button" value="/" />';
    cmdStr += '<input data-icon="delete" data-inline="true" data-mini="true" onclick="javascript:changeDeleteMode(\'' + deviceId + '\');" type="button" value="Delete  Mode" />';

    $('#command').html(cmdStr).trigger('create');
}


/**
 * Icon GET
 */
function getFileIcon(mimeType) {

    if (mimeType == "dir/folder") {
        iconName = "css/images/icon_folder.png";
    } else if (mimeType == "video/3gpp") {
        iconName = "css/images/icon_video.png";
    } else if (mimeType == "video/mp4") {
        iconName = "css/images/icon_video.png";
    } else if (mimeType == "video/m4v") {
        iconName = "css/images/icon_video.png";
    } else if (mimeType == "audio/mpeg") {
        iconName = "css/images/icon_music.png";
    } else if (mimeType == "image/png") {
        iconName = "css/images/icon_pic.png";
    } else if (mimeType == "image/jpg") {
        iconName = "css/images/icon_pic.png";
    } else if (mimeType == "image/jpeg") {
        iconName = "css/images/icon_pic.png";
    } else if (mimeType == "audio/x-wav") {
        iconName = "css/images/icon_music.png";
    } else {
        iconName = "css/images/icon_file.png";
    }
    return iconName;
}


/**
 * do Action for File
 */
function doFileAction(deviceId, path, mimeType) {
    if (deleteMode) {
        doDeleteFile(deviceId, path, mimeType);
    } else {
        initCommand();
        initContents();

        if (mimeType == "audio/mpeg") {
            doMusicPlayer(deviceId, path);
        } else if (mimeType == "image/png") {
            doImageShow(deviceId, path);
        } else if (mimeType == "image/jpeg") {
            doImageShow(deviceId, path);
        } else if (mimeType == "image/jpg") {
            doImageShow(deviceId, path);
        } else if (mimeType == "video/3gpp") {
            doVideoPlayer(deviceId, path);
        } else if (mimeType == "video/mp4") {
            doVideoPlayer(deviceId, path);
        } else if (mimeType == "video/m4v") {
            doVideoPlayer(deviceId, path);
        } else if (mimeType == "audio/x-wav") {
            doMusicPlayer(deviceId, path);
        } else {
            doMusicPlayer(deviceId, path);
        }
    }
}


/**
 * File Delete
 */
function doDeleteFile(deviceId, path) {
    var uri = BASE_URI + "/file/remove?deviceId=" + deviceId + "&accessToken=" + accessToken + "&path=" + path;

    connectHttp('DELETE', uri, function(text) {
        var str = "";
        var obj = JSON.parse(text);
        if (obj.result == 0) {
            var str = getSuccessString();
            showFileList(deviceId, "/");
        } else {
            var str = getFailString();
            var contentsHtml = document.getElementById('contents');
            contentsHtml.innerHTML += str;

        }


    });
}

/**
 * Uploader
 * file/send
 */
/*
function showFileSend(deviceId) {

    initListView();
    setTitle("File Profile(Send)");

    var uri = BASE_URI + "/file/send";
    var str = "";
    str += '<form action="' + uri + '" method="POST" enctype="multipart/form-data" id="fileForm" name="fileForm"><br>';
    str += '<input type="text" name="path" value=""/>';
    str += '<input type="hidden" name="fileType" value="0"/>';
    str += '<input type="file" name="media"/>';
    str += '<input type="button" name="送信" value="Send" onclick="doFileSend(\'' + deviceId + '\');"/>';
    str += '</form>';
    str += '<center>';
    str += '<input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showFile(\'' + deviceId + '\');" type="button" value="File TOP"/>';
    str += '</center>';

    $('#contents').html(str).trigger('create');
}
*/

/**
 * file/send
 */

/*
function doFileSend(deviceId) {
	showLoading();
	var form = document.getElementsByName("fileForm");
    var path = document.getElementsByName("path")[0].value;
    var media = document.getElementsByName("media")[0].value;
    var fileType = document.getElementsByName("fileType")[0].value;
    alert(path);
    
	var builder = new dConnect.URIBuilder();
    builder.setProfile("file");
    builder.setAttribute("send");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("path", path);
    builder.addParameter("media", media);
     builder.addParameter("fileType", fileType);
    var uri = builder.build();
	
    dConnect.execute('POST', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		alert(responseText);
        if (json.result == 0) {
			closeLoading();
        } else {
			closeLoading();
        }
    }, function(xhr, textStatus, errorThrown) {

    }); 
}
*/


/**
 * Uploader
 * file/send
 */
function showFileSend(deviceId) {

    initListView();
    setTitle("File Profile(Send)");

    var uri = BASE_URI + "/file/send";
    var str = "";
    str += '<form action="' + uri + '" method="POST" enctype="multipart/form-data" id="my_form"><br>';
    str += '<input type="hidden" name="deviceId" value="' + deviceId + '"/>';
    str += '<input type="hidden" name="accessToken" value="' + accessToken + '"/>';
    str += '<input type="text" name="path" value=""/>';
    str += '<input type="hidden" name="fileType" value="0"/>';
    str += '<input type="file" name="media"/>';
    str += '<input type="button" name="Send" value="Send" onclick="doFileSend(\'' + deviceId + '\');"/>';
    str += '</form>';
    str += '<center>';
    str += '<input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showFile(\'' + deviceId + '\');" type="button" value="File TOP"/>';
    str += '</center>';

    $('#contents').html(str).trigger('create');
}

/**
 * file/send
 */
function doFileSend(deviceId) {
    showLoading();
    var form = document.getElementById("my_form");
    var form_data = new FormData(form);
    var xhr = new XMLHttpRequest();
    xhr.open(form.method, form.action, false);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status == 0) {
                var str = "";
                var obj = JSON.parse(xhr.responseText);
                if (obj.result == 0) {}
                var result1 = document.getElementById('contents');
                result1.innerHTML = xhr.responseText;
                closeLoading();
            } else {
                alert("error:" + xhr.status);
                closeLoading();
            }
        }
    };
    xhr.send(form_data);
}


function getFile(deviceId, mediaid) {
    var uri = BASE_URI + "/file/receive?accessToken=" + accessToken + "&deviceId=" + deviceId + "&mediaId=" + mediaid;
    connectHttp('GET', uri, function(text) {
        var str = "";
        var obj = JSON.parse(text);
        if (obj.result == 0) {
            str += "<br><img src='" + obj.uri + "' width=100%>";
        }
        str + "<br><br>" + text;
        //var result1 = document.getElementById('contents');
        //result1.innerHTML = str;

        $('#result').html(str).trigger('create');
    });
}


/**
 * MediaPlayer
 */
function doImageShow(deviceId, path) {
	
	var builder = new dConnect.URIBuilder();
    builder.setProfile("file");
    builder.setAttribute("receive");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("path",path);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		
        if (json.result == 0) {
        	 setTitle("ImageShow");

            initListView();

            json.uri = json.uri.replace("localhost", ip);
            var str = "";
            str += '<img src="' + json.uri + '" width="100%">';
            str += '</center><br>';
            var result1 = document.getElementById('contents');
            result1.innerHTML = str;
           
        } else {
           
        }
    });
}