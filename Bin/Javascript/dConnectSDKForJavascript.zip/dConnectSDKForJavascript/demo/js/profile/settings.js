/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
/**
  Setting Profile
 */
var VOLUME_TYPE_ALERM = 1;
var VOLUME_TYPE_CALL = 2;
var VOLUME_TYPE_RINGTONE = 3;
var VOLUME_TYPE_MAIL = 4;
var VOLUME_TYPE_OTHER = 5;
var VOLUME_TYPE_MEDIA_PLAYER = 4;

var process_count = 0;

/** 
 * Show menu of setting profile.
 */
function showSetting(deviceId) {

    initListView();
    setTitle("Settings Profile");

    var str = "";
    str += 'Date:<br>';

    str += '<input type="text" value="" id="date" name="date" >';

    str += '<label for="slider-0">Volume Alerm:</label>';
    str += '<input type="range" name="slider" id="volumeAlerm" value="25" min="0" max="100"  />';
    str += '<input type="button" id="volumeSetAlerm" value="Set volume of Alerm"  />';

    str += '<label for="slider-0">Volume Call:</label>';
    str += '<input type="range" name="slider" id="volumeCall" value="25" min="0" max="100"  />';
    str += '<input type="button" id="volumeSeCall" value="Set volume of Call"  />';

    str += '<label for="slider-0">Volume Ringtone:</label>';
    str += '<input type="range" name="slider" id="volumeRingtone" value="25" min="0" max="100"  />';
    str += '<input type="button" id="volumeSetRingtone" value="Set volume of Ringtone"  />';

    str += '<label for="slider-0">Volume Mail:</label>';
    str += '<input type="range" name="slider" id="volumeMail" value="25" min="0" max="100"  />';
    str += '<input type="button" id="volumeSetMail" value="Set volume of Mail"  />';

    str += '<label for="slider-0">Volume Media Player:</label>';
    str += '<input type="range" name="slider" id="volumeMediaplayer" value="25" min="0" max="100"  />';
    str += '<input type="button" id="volumeSetMediaplayer" value="Set volume of Media Player"  />';

    str += '<label for="slider-0">Light:</label>';
    str += '<input type="range" name="slider" id="light" value="25" min="0" max="100"  />';
    str += '<input type="button" id="lightSet" value="Set light"  />';

    str += '<label for="slider-0">Sleep:</label>';
    str += '<input type="text" value="" id="sleep" name="sleep" >';
    str += '<input type="button" id="sleepSet" value="Set sleep"  />';


    str += getProfileListLink(deviceId);
    
    $('#contents').html(str).trigger('create');

    process_count = 0;
    showLoading();

    doCheckDate(deviceId);
    doCheckVolume(deviceId);
    doCheckLight(deviceId);
    doCheckSleep(deviceId);

}


/** 
 * Get date from Setting profile.
 */
function doCheckDate(deviceId) {

	var builder = new dConnect.URIBuilder();
    builder.setProfile("settings");
    builder.setAttribute("date");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	$('#date').val(json.date);
            
        } else {
           
        }
        process_count++;
        loadingCheck(process_count);
    }, function(xhr, textStatus, errorThrown) {
        
    });
}

/** 
 * Get volume from Setting profile.
 */
function doCheckVolume(deviceId) {

	var builder = new dConnect.URIBuilder();
    builder.setProfile("settings");
    builder.setAttribute("volume");
    builder.setInterface("sound");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
        if (json.result == 0) {
        	$('#volumeAlerm').val((json.volumes[0].alerm * 100));
            $('#volumeAlerm').slider('refresh');

            $('#volumeCall').val((json.volumes[1].call * 100));
            $('#volumeCall').slider('refresh');

            $('#volumeRingtone').val((json.volumes[2].ringtone * 100));
            $('#volumeRingtone').slider('refresh');

            $('#volumeMail').val((json.volumes[3].mail * 100));
            $('#volumeMail').slider('refresh');

            $('#volumeMediaplayer').val((json.volumes[4].mediaplayer * 100));
            $('#volumeMediaplayer').slider('refresh');
            
        } else {
            
        }
        process_count++;
        loadingCheck(process_count);
    }, function(xhr, textStatus, errorThrown) {
        
    });
}

/** 
 * Get light from Setting profile.
 */
function doCheckLight(deviceId) {
	var builder = new dConnect.URIBuilder();
    builder.setProfile("settings");
    builder.setInterface("display");
    builder.setAttribute("light");
    
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		
        if (json.result == 0) {
        	$('#light').val((json.level * 100));
            $('#light').slider('refresh');
        } else {
           
        }
        process_count++;
        loadingCheck(process_count);
    }, function(xhr, textStatus, errorThrown) {
        
    });
}


/** 
 * Get sleep time from Setting profile.
 */
function doCheckSleep(deviceId) {

	var builder = new dConnect.URIBuilder();
    builder.setProfile("settings");
   	builder.setInterface("display");
    builder.setAttribute("sleep");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		
        if (json.result == 0) {
        	$('#sleep').val(json.time);
        } else {
           
        }
        process_count++;
        loadingCheck(process_count);
    }, function(xhr, textStatus, errorThrown) {
        
    });
}

/**
 hide loading
*/
function loadingCheck(count) {
    if (count > 3) {
       closeLoading();
    }
}
