/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
/**
 System Profile.
 */
 
 
 /**
  Search profile.
  */
function searchSystem(deviceId) {

	initCommand();
    initContents();
    initResult();

    var builder = new dConnect.URIBuilder();
    builder.setProfile("system");
    builder.setAttribute("device");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	var str = "";
            for (var i = 0; i < json.supports.length; i++) {
                str += '<li><a href="javascript:searchProfile(\'' + deviceId + '\', ';
                str += '\'' + json.supports[i] + '\');" ';
                str += 'value="' + json.supports[i] + '">';
                str +=  json.supports[i] + '</a></li>';
            }

            setTitle("Profile List");

            var listHtml = document.getElementById('list');
            listHtml.innerHTML = str;
            $("ul.list").listview("refresh");
            
        } else {
            var errorCode = json.errorCode;
            var errorMessage = json.errorMessage;
            if (error_cb) {
                error_cb(errorCode, errorMessage);
            }
        }
    }, function(xhr, textStatus, errorThrown) {
        
    });

}