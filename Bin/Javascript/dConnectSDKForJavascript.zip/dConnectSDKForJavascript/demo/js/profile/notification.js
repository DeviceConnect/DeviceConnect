/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
 
 
function showNotification(deviceId) {
    initListView();
    setTitle("Notification Profile(Notify)");
   
    var str = "";
    str += '<form name="notificationForm">';
    str += '<br>';
    str += '<center><input type="text" value="hello world!" name="body1">';
    str += '<SELECT name="type">';
    str += '<OPTION value="0">Call event</OPTION>';
    str += '<OPTION value="1">Mail event</OPTION>';
    str += '<OPTION value="2">SMS event</OPTION>';
    str += '<OPTION value="3">Normal event</OPTION>';
    str += '</SELECT>';
    str += '</form>';
    str += '<input type="button" onclick="doNotificationNotify(\'' + deviceId + '\');" value="Notify" type="button" >';
    str += '</center>';
    
    str += getProfileListLink(deviceId);

    $('#contents').html(str).trigger('create');
}

/**
 * Notification(Notify)
 */
function doNotificationNotify(deviceId) {
    var type = document.notificationForm.type.value;
    var txtBody = document.notificationForm.body1.value;
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("notify");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("type", type);
    builder.addParameter("body", txtBody);
    var uri = builder.build();

    dConnect.execute('POST', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {


        } else {

        }
    }, function(xhr, textStatus, errorThrown) {

    });
   
}

function notificationDel(deviceId, notificationId) {
    var uri = BASE_URI + "/notification/notify?deviceId=" + deviceId + "&notificationId=" + notificationId;
    connectHttp('DELETE', uri, function(text) {
        var str = "";
        var obj = JSON.parse(text);
        if (obj.result == 0) {
            setTitle("Notification Delete Result");
            var str = "Correct";
            var result1 = document.getElementById('contents');
            result1.innerHTML = str;
        }
    });
}