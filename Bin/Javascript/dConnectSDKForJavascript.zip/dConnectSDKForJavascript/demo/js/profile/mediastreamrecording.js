/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * MediastreamRecording profile
 */
function showMediastreamRecording(deviceId) {

    setTitle("MediastreamRecording");

    var str = "";
    str += '<li><a href="javascript:doPreviewStart(\'' + deviceId + '\');">Preview</a></li>';
    str += '<li><a href="javascript:doTakePhoto(\'' + deviceId + '\');">Take Photo</a></li>';
    str += '<li><a href="javascript:doMediaRecord(\'' + deviceId + '\',\'video\');">Record Video</a></li>';
    str += '<li><a href="javascript:doMediaRecord(\'' + deviceId + '\',\'audio\');">Record Audio</a></li>';


    var listHtml = document.getElementById('list');
    listHtml.innerHTML = str;
    $("#list").listview("refresh");

    var str = '<center><input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:searchSystem(\'' + deviceId + '\');" type="button" value="Device TOP"/></center>';
    $('#contents').html(str).trigger('create');

}


/**
 * onDataAvailable
 */
function doRegisterOnDataAvailable(deviceId, sessionKey) {


 	var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("ondataavailable");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.addEventListener(uri, deviceId, sessionKey, function(message) {
        // イベントメッセージが送られてくる
        var json = JSON.parse(message);
        alert("JSON=" + message);
    });
    	

            setTitle("takephoto preview");
            var str = '<center>';
            str += '<img src="./images/icon_music.png" width="100%" id="preview">';
            str += '</center><br>';
            str += '<center><input data-icon="stop" data-inline="true" data-mini="true" ';
            str += 'onclick="javascript:doPreviewStop(\'' + deviceId + '\', \'' + sessionKey + '\');" type="button" value="Stop"/>';
            str += '</center>';


            $('#result').html(str).trigger('create');

}

/**
 * MediaPlayer stop
 */
function doPreviewStop(deviceId, sessionKey) {
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("ondataavailable");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.removeEventListener(uri, deviceId, sessionKey);
    
    doMediaStop(deviceId);
    
    
}

function doPreviewStart(deviceId) {
    var mDate = new Date();
    var webSocketName = mDate.getTime();
    loadFlag = false;
    sessionKey = webSocketName;
    doExecWebSocket(webSocketName);
    doRegisterOnDataAvailable(deviceId, webSocketName);

    initListView();
}

function doTakePhoto(deviceId) {

	 var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("takephoto");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);

    var uri = builder.build();
    
    dConnect.execute('POST', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	json.uri = json.uri.replace("localhost", ip);
            var str = "";
            str += '<img src="' + json.uri + '" width="100%">';
            str += '</center><br>';
            $('#result').html(str).trigger('create');
            
        } else {
           
        }
        
    }, function(xhr, textStatus, errorThrown) {
        
    });
    
}


function refreshImg(uri) {
    if (!loadFlag) {
        loadFlag = true;
        var img = document.getElementById('preview');
        img.src = uri;
        img.onload = function() {
            loadFlag = false;
        }
    }
}


function doMediaRecord(deviceId, target) {
    initListView();
    initContents();
    setTitle("Recording, now");
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("record");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("target",target);
    var uri = builder.build();
    
    dConnect.execute('POST', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	var str = "";
        	str += '<center><input data-icon="stop" data-inline="true" data-mini="true" ';
            str += 'onclick="javascript:doMediaStop(\'' + deviceId + '\');" type="button" value="Stop"/>';
            str += '</center>';
			$('#result').html(str).trigger('create');
            
        } else {
           
        }
        
    }, function(xhr, textStatus, errorThrown) {
        
    });
}

function doMediaStop(deviceId){
	var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("stop");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	
            
        } else {
           
        }
        
    }, function(xhr, textStatus, errorThrown) {
        
    });
}