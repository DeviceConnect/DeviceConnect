/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
/** 
 * DeviceOrientation
 */
function showDeviceOrientation(deviceId) {
    initListView();
    setTitle("DeviceOrientation Profile(Event)");

    var str = "";
    var mData = new Date();

    var webSocketName = mData.getTime();

    str += '<input type="button" onclick="doDeviceOrientationRegist(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Register Event" >';
    str += '<input type="button" onclick="doExecWebSocket(\'' + webSocketName + '\');" value="Open WebSocket" type="button" >';
    str += '<form  name="deviceOrientationForm">';
    str += 'Accelerometer<br>';
    str += '<input type="text" id="accelX" width="100%">';
    str += '<input type="text" id="accelY" width="100%">';
    str += '<input type="text" id="accelZ" width="100%">';
    str += 'Accelerometer(Gravity)<br>';
    str += '<input type="text" id="accelXG" width="100%">';
    str += '<input type="text" id="accelYG" width="100%">';
    str += '<input type="text" id="accelZG" width="100%">';
    str += 'Rotation<br>';
    str += '<input type="text" id="rotationBeta" width="100%">';
    str += '<input type="text" id="rotationAlpha" width="100%">';
    str += '<input type="text" id="rotationGamma" width="100%">';
    str += 'Interval<br>';
    str += '<input type="text" id="interval" width="100%">';
    str += '</form>';
    str += '<input type="button" onclick="doDeviceOrientationUnregister(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Unregister Event">';
    
    str += getProfileListLink(deviceId);


    $('#contents').html(str).trigger('create');
}

function doExecWebSocket(sessionKey) {
    execWebSocket(sessionKey);
}

/**
 * DeviceOrientation
 */
function doDeviceOrientationRegist(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("deviceorientation");
    builder.setAttribute("ondeviceorientation");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.addEventListener(uri, deviceId, sessionKey, function(message) {
        // イベントメッセージが送られてくる
        var json = JSON.parse(message);
        alert("JSON=" + message);
    });

}

/**
 * DeviceOrientation
 */
function doDeviceOrientationUnregister(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("deviceorientation");
    builder.setAttribute("ondeviceorientation");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.removeEventListener(uri, deviceId, sessionKey);
}
