/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/** 
 * Media Player Profile
 */
/** 
 * media_player Profile
 */
function showMediaPlayer(deviceId) {

    initContents();
    initResult();

    setTitle("MediaPlayer Profile");

    var str = "";
    str += '<li><a href="javascript:doMediaList(\'' + deviceId + '\');" value="MediaList">MediaList</a></li>';

    var listHtml = document.getElementById('list');
    listHtml.innerHTML = str;
    $("#list").listview("refresh");

    var str = "";
    str += '<center><input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:searchSystem(\'' + deviceId + '\');" type="button" value="Device TOP"/></center>';
    $('#contents').html(str).trigger('create');
}



/**
 * MediaPlayer
 */
function doMediaList(deviceId) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("media_list");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
            var str = "";
            for (var i = 0; i < json.media.length; i++) {
                str += '<li><a href="javascript:doMediaPlayer(\'' + deviceId + '\',\'' + json.media[i].mediaId + '\');"  >' + json.media[i].title + '</a></li>';
            }

            var listHtml = document.getElementById('list');
            listHtml.innerHTML = str;
            $("#list").listview("refresh");

            var mDate = new Date();
            var sessionKey = mDate.getTime();
            doRegisterOnStatusChange(deviceId, sessionKey);
            execWebSocket(sessionKey);

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {});
}


/**
 * MusicPlayer
 */
function doRegisterOnStatusChange(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("onstatuschange");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.addEventListener(uri, deviceId, sessionKey, function(message) {
        // イベントメッセージが送られてくる
        var json = JSON.parse(message);
        alert("JSON=" + message);
    });
}


/**
 * MediaPlayer
 */
function doMediaPlayer(deviceId, id) {

    var str = "<hr>";
    str += '<form  name="mediaPlayerForm">';
    str += '<input type="text" id="mediaId" width="100%">';
    str += '<input type="text" id="mimeType" width="100%">';
    str += '<input type="text" id="volume" width="100%">';
    str += '<input type="text" id="status" width="100%">';
    str += '</form>';


    str += '<input type="text" value="' + id + '"/>';
    str += '<input data-icon="play" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerPlay(\'' + deviceId + '\');" type="button" value="Play"/>';
    str += '<input data-icon="pause" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerPause(\'' + deviceId + '\');" type="button" value="Pause"/>';
    str += '<input data-icon="stop" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerStop(\'' + deviceId + '\');" type="button" value="Stop"/>';
    str += '</center>';

    $('#contents').html(str).trigger('create');

    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("media");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("mediaId", id);
    var uri = builder.build();

    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
            setTitle("MediaPlayer");


            initListView();


        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });

}

/**
 * MediaPlayer play
 */
function doMediaPlayerPlay(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("play");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

/**
 * MediaPlayer play
 */
function doMediaPlayerStop(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("stop");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}


/**
 * MediaPlayer play
 */
function doMediaPlayerPause(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("pause");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();

    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}


/**
 * MediaPlayer
 */
function doVideoPlayer(deviceId, path) {
    var uri = BASE_URI + "/media_player/media?deviceId=" + deviceId + "&accessToken=" + accessToken + "&mediaId=" + path;

    connectHttp('PUT', uri, function(text) {
        var str = "";
        var obj = JSON.parse(text);
        if (obj.result == 0) {
            setTitle("Video Player");

            initListView();

            var str = "<hr>";
            str += '<input type="text" value="' + path + '"/>';
            str += '<input data-icon="play" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerPlay(\'' + deviceId + '\');" type="button" value="Play"/>';
            str += '<input data-icon="pause" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerPause(\'' + deviceId + '\');" type="button" value="Pause"/>';
            str += '<input data-icon="stop" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerStop(\'' + deviceId + '\');" type="button" value="Stop"/>';
            str += '</center>';

            $('#contents').html(str).trigger('create');
        } else {
            var str = getFailString();
            var phoneHtml = document.getElementById('contents');
            phoneHtml.innerHTML += str;
        }

    });
}