/** 
 * Connect Profile
 */
function showConnect(deviceId) {
    initResult();
    initListView();

    setTitle("Connect Profile");

    var str = "";
    str += 'Bluetooth:<br>';
    str += '<select name="bluetooth" id="bluetooth" data-role="slider">';
    str += '<option value="off" id="off">Off</option>';
    str += '<option value="on" id="on">On</option>';
    str += '</select><br>';
    str += 'BLE:<br>';
    str += '<select name="ble" id="ble" data-role="slider">';
    str += '<option value="off" id="off">Off</option>';
    str += '<option value="on" id="on">On</option>';
    str += '</select><br>';
    str += 'Wifi:<br>';
    str += '<select name="wifi" id="wifi" data-role="slider">';
    str += '<option value="off">Off</option>';
    str += '<option value="on">On</option>';
    str += '</select><br>';
    
    str += getProfileListLink(deviceId);
    
    $('#contents').html(str).trigger('create');


    $('#ble').bind("change", function(event, ui) {

    });

    doCheckBluetooth(deviceId);
    doCheckWifi(deviceId);
}

/** 
 * Connect Profile (Bluetooth)
 */
function doConnectBluetooth(deviceId, connect) {
    var uri = BASE_URI + "/connect/bluetooth?deviceId=" + deviceId + "&accessToken=" + accessToken + "&enabled=" + connect;

    connectHttp('PUT', uri, function(text) {
        var str = "";
        var obj = JSON.parse(text);
        if (obj.result == 0) {
            var str = getSuccessString();
        } else {
            var str = getFailString();
        }
        $('#result').html(str).trigger('create');


    });

}

/** 
 * Connect Profile (Bluetooth)
 */
function doCheckBluetooth(deviceId) {

	var builder = new dConnect.URIBuilder();
    builder.setProfile("connect");
    builder.setAttribute("bluetooth");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	if (json.enabled) {
                $('#bluetooth').prop('selectedIndex', 1);
                $('#bluetooth').slider('refresh');
            }

            $('#bluetooth').bind("change", function(event, ui) {
                if ($('#bluetooth').val() == "off") {
                    doConnectBluetooth(deviceId, false);
                } else if ($('#bluetooth').val() == "on") {
                    doConnectBluetooth(deviceId, true);
                }

            });
            //var str = getSuccessString();
            
        } else {
             //var str = getFailString();
        }
    }, function(xhr, textStatus, errorThrown) {
         //var str = getFailString();
    });
}

/** 
 * Connect Profile (Bluetooth)
 */
function doCheckWifi(deviceId) {

	var builder = new dConnect.URIBuilder();
    builder.setProfile("connect");
    builder.setAttribute("wifi");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	if (json.enabled) {
                $('#wifi').prop('selectedIndex', 1);
                $('#wifi').slider('refresh');
            }

            $('#wifi').bind("change", function(event, ui) {
                if ($('#wifi').val() == "off") {
                    doConnectBluetooth(deviceId, false);
                } else if ($('#wifi').val() == "on") {
                    doConnectBluetooth(deviceId, true);
                }

            });
            //var str = getSuccessString();
            
        } else {
             //var str = getFailString();
        }
    }, function(xhr, textStatus, errorThrown) {
         //var str = getFailString();
    });
  
}

/** 
 * Connect Profile (Wifi)
 */
function doConnectWifi(deviceId, connect) {
    var uri = BASE_URI + "/connect/wifi?deviceId=" + deviceId + "&accessToken=" + accessToken + "&enabled=" + connect;

    connectHttp('PUT', uri, function(text) {
        var str = "";
        var obj = JSON.parse(text);
        if (obj.result == 0) {
            var str = getSuccessString();
        } else {
            var str = getFailString();
        }

        $('#result').html(str).trigger('create');

    });

}