/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
function searchDevice() {
    
    initCommand();
    initContents();
    initResult();
    
	dConnect.setHost(ip);
    dConnect.discoverDevices(function(status, headerMap, responseText){
        var str = "";
        var obj = JSON.parse(responseText);
        if (obj.result == 0) {
            for (var i = 0; i < obj.services.length; i++) {
                str += '<li><a href="javascript:searchSystem(\'' + obj.services[i].id + '\');" value="' + obj.services[i].name + '">' + obj.services[i].name + '</a></li>';
            }
        }

        setTitle("Device List", "black");
        deleteMode = false;

        var listHtml = document.getElementById('list');
        listHtml.innerHTML = str;
        $("ul.list").listview("refresh");

    }, function(readyState, status) {

    });
}
