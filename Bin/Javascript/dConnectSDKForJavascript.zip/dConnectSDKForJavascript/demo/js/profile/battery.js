/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

/**
 Battery Profile
 */
 
/**
  Show Battery
 */
function showBattery(deviceId) {

    initListView();
    setTitle("Battery Profile");

    doBatteryAll(deviceId);
}

/**
 * Battery Profile
 */
function doBatteryAll(deviceId) {


	var builder = new dConnect.URIBuilder();
    builder.setProfile("battery");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		
        if (json.result == 0) {
        	var level = json.level * 100;
            var str = "";
            str += '<label for="slider-0">LEVEL:</label>';
            str += '<input type="range" name="slider" id="volume" value="' + level + '" min="0" max="100"  />';


            if (json.charging) {
                str += '<input type="button" value="Charging"/>';
            } else {
                str += '<input type="button" value="Not charging"/>';
            }
            str += getProfileListLink(deviceId);
            
            $('#contents').html(str).trigger('create');

           
        } else {
           
        }
       
    }, function(xhr, textStatus, errorThrown) {
        
    });

   


}