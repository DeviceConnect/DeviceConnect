/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * File Descriptor Profile
 */
function showFileDescriptor(deviceId) {

    initContents();
    initListView();
	initCommand();
    setTitle("File Descriptor Profile");

    var str = "";
    str += '<form  name="fileDescriptorForm">';

    str += '<div class="ui-field-contain">';
    str += '<label for="path">Path:</label>';
    str += '<input type="text" data-mini="true" name="path" id="path" value="">';
    str += '</div>';
    str += '<SELECT name="flag">';
    str += '<OPTION value="rw">Read/Write</OPTION>';
    str += '<OPTION value="r">Read</OPTION>';
    str += '</SELECT>';
    str += '</form>';
    str += '<input type="button" onclick="doOpenFile(\'' + deviceId + '\');" id="openFile" value="Open file"  />';
    str += getProfileListLink(deviceId);

    $('#contents').html(str).trigger('create');
}

/**
 * Open
 */
function doOpenFile(deviceId) {
    var flag = document.fileDescriptorForm.flag.value;
    var path = document.fileDescriptorForm.path.value;
    
	var mDate = new Date();
    var sessionKey = mDate.getTime();
            
    console.log("sessionKey:" + sessionKey);
	
	var builder = new dConnect.URIBuilder();
    builder.setProfile("file_descriptor");
    builder.setAttribute("onwatchfile");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var eventUri = builder.build();

    dConnect.addEventListener(eventUri, deviceId, sessionKey, function(message) {
        // イベントメッセージが送られてくる
        var json = JSON.parse(message);
    });
    console.log("addEventListener");
    doExecWebSocket(sessionKey);
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("file_descriptor");
    builder.setAttribute("open");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("path", path);
    builder.addParameter("flag", flag);
    var uri = builder.build();

    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		alert(responseText);
        if (json.result == 0) {
            initContents();
            var str = "";
            str += '<form  name="fileDescriptorForm">';
            str += '<center>';
            str += '<div class="ui-grid-a">';
            str += '<div class="ui-block-a"><div class="ui-bar ui-bar-a">Path: ' + path + '</div></div>';
            str += '<div class="ui-block-b"><div class="ui-bar ui-bar-a">Flag: ' + flag + '</div></div>';
            str += '</div>'
            str += '<input type="text" name="event" id="event" value="">';
            str += '</center>';

            $('#command').html(str).trigger('create');

            var str = "";
            str += getFileWriteHtml(deviceId, path, flag, sessionKey);
            str += getFileReadHtml(deviceId, path, flag, sessionKey);
            str += getCloseHtml(deviceId, sessionKey);
            str += getProfileListLink(deviceId);

            $('#contents').html(str).trigger('create');

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

/**
 * file/send
 */
function doWriteFile(deviceId, sessionKey) {
    var position = document.fileDescriptorWriteForm.position.value;
    var path = document.fileDescriptorWriteForm.path.value;
    var flag = document.fileDescriptorWriteForm.flag.value;
    
    console.log("sessionKey:" + sessionKey);


    var form = document.getElementById("fileDescriptorWriteForm");
    var form_data = new FormData(form);
    var xhr = new XMLHttpRequest();
    xhr.open("PUT", form.action, false);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status == 0) {
                var str = "";
                var obj = JSON.parse(xhr.responseText);
                if (obj.result == 0) {

                    var str = "";
                    str += getFileWriteHtml(deviceId, path, flag, sessionKey);
                    str += getFileReadHtml(deviceId, path, flag, sessionKey);
					str += getCloseHtml(deviceId, sessionKey);
                    str += getProfileListLink(deviceId);

                    $('#contents').html(str).trigger('create');

                    alert("Success of writiting");
                }

            } else {

            }
        }
    };
    xhr.send(form_data);
}

/**
 * Open
 */
function doReadFile(deviceId, sessionKey) {

    var length = document.fileDescriptorReadForm.length.value;
    var position = document.fileDescriptorReadForm.position.value;
    var path = document.fileDescriptorReadForm.path.value;
    var flag = document.fileDescriptorReadForm.flag.value;

    console.log("sessionKey:" + sessionKey);

    initResult();

    var builder = new dConnect.URIBuilder();
    builder.setProfile("file_descriptor");
    builder.setAttribute("read");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("path", path);
    builder.addParameter("position", position);
    builder.addParameter("length", length);

    var uri = builder.build();

    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
        console.log(responseText);
        if (json.result == 0) {
            setTitle("Read");
            var result = json.fileData;
            //result = result.replace("<", "&lt;");

            var str = "";
            str += getFileWriteHtml(deviceId, path, flag, sessionKey);
            str += getFileReadHtml(deviceId, path, flag, sessionKey);

            str += '<textarea cols="40" rows="10" name="textarea-8" id="textarea-8">';
            str += result;
            str += '</textarea>';
			str += getCloseHtml(deviceId, sessionKey);
            str += getProfileListLink(deviceId);

            $('#contents').html(str).trigger('create');


        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

/**
 * Open
 */
function doCloseFile(deviceId, sessionKey) {
   
    var path = document.fileDescriptorReadForm.path.value;
   
    console.log(sessionKey);


    initResult();
	var builder = new dConnect.URIBuilder();
    builder.setProfile("file_descriptor");
    builder.setAttribute("onwatchfile");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var eventUri = builder.build();

    dConnect.removeEventListener(eventUri, deviceId, sessionKey);
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("file_descriptor");
    builder.setAttribute("close");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("path", path);
    var uri = builder.build();

    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
        console.log(responseText);
        if (json.result == 0) {
            setTitle("Close");
            showFileDescriptor(deviceId, sessionKey);
        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

function getFileWriteHtml(deviceId, path, flag, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("file_descriptor");
    builder.setAttribute("write");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);

    var actionUri = builder.build();
    var str = "";
    str += '<form  action="' + actionUri + '" method="PUT" enctype="multipart/form-data" name="fileDescriptorWriteForm" id="fileDescriptorWriteForm"><br>';
    str += '<div class="ui-field-contain">';
    str += '<label for="media">File:</label>';
    str += '<input type="file" name="media" id="media" value="">';
    str += '<label>Position:</label>';
    str += '<input type="text" data-mini="true" name="position" id="position" value="">';
    str += '</div>';

    str += '<input type="hidden" name="path" id="path" value="' + path + '">';
    str += '<input type="hidden" name="flag" id="flag" value="' + flag + '">';

    str += '<input type="button" onclick="doWriteFile(\'' + deviceId + '\',\'' + sessionKey + '\');" id="writeFile" value="Write file"  />';
    str += '</form>';
    return str;
}

function getFileReadHtml(deviceId, path, flag, sessionKey) {

    var str = "";
    str += '<form  name="fileDescriptorReadForm">';
    str += '<div class="ui-field-contain">';
    str += '<label>Position:</label>';
    str += '<input type="text" data-mini="true" name="position" id="position" value="">';
    str += '<input type="hidden" name="path" id="path" value="' + path + '">';
    str += '<input type="hidden" name="flag" id="flag" value="' + flag + '">';
    str += '<label for="length">Length:</label>';
    str += '<input type="text" data-mini="true" name="length" id="length" value="">';
    str += '</div>';
    str += '<input type="button" onclick="doReadFile(\'' + deviceId + '\',\'' + sessionKey + '\');" id="readFile" value="Read file"  />';
    str += '</form>';
    
    return str;
}

function getCloseHtml(deviceId, sessionKey){

	var str = "";
	str += '<input type="button" onclick="doCloseFile(\'' + deviceId + '\', \'' + sessionKey + '\');" value="Close file"  />';
	return str;
}