/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

/**
 * @preserve
 * d-Connect SDK Library.
 * @todo ドキュメントをJSDocに更新する。
 */

var dConnect = (function(parent, global) {
    "use strict";
    var XMLHttpRequest;

    if (global.self) {
        XMLHttpRequest = global.XMLHttpRequest;
    } else if (global.process) {
        XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
    }

    // このウェブコンテンツがd-Connect Managerとやり取りする為に用いるトークン。
    var webAppAccessToken;
    /**
     * ホスト名.
     * @private
     * @default localhost
     * @see setHost
     */
    var host = "localhost";
    /**
     * ポート番号.
     * @private
     * @default 8080
     * @see setPort
     */
    var port = "8080";
    /**
     * イベント通知用のリスナーを格納するオブジェクト.
     * @private
     * @see addEventListener
     * @see removeEventListener
     */
    var eventListener = {};

    /**
     * Websocketのインスタンス.
     */
    var websocket;

    /** Signature生成処理種別(SHA512) */
    var SHA512 = "SHA512";
    /** グラントタイプ(authorization_code). */
    var AUTHORIZATION_CODE = "authorization_code";

    /**
     * Signature生成処理(SHA512).
     */
    var AuthSignatureProcSHA512 = {
        /**
         * Signature生成.
         * @param inputMaps 入力文字列(key,valueの連想配列)
         * @param clientSecret クライアントシークレット
         * @return 生成したSignature文字列
         */
        generateSignature : function(inputMaps, clientSecret) {

            /* key昇順にソート */
            inputMaps.sort(function(a, b) {
                return (a.key < b.key) ? -1 : 1;
            });

            /* 連結 */
            var str = "";
            for (var i = 0; i < inputMaps.length; i++) {
                str += inputMaps[i].key;
                str += inputMaps[i].value;
            }

            /* clientSecretを連結 */
            str += "clientSecret";
            str += clientSecret;

            var shaObj = new jsSHA(str, "TEXT");
            var signature = shaObj.getHash("SHA-512", "HEX");
            return signature;
        }
    };

    /**
     * Signature生成処理ファクトリークラス.
     */
    var AuthSignatureProcFactory = {

        /**
         * Signature生成処理を返す.
         * @param kind Signature生成処理種別
         * @return Signature生成処理オブジェクト
         */
        getProc : function(kind) {
            if (kind == SHA512) {
                return AuthSignatureProcSHA512;
            } else {
                return null;
            }
        }
    };

    /**
     * Signatureクラス.
     */
    var AuthSignature = {

        /**
         * アクセストークン発行リクエスト用のSignatureを生成する.
         * @param {String} clientId クライアントID
         * @param {String} grantType グラントタイプ(AUTHORIZATION_CODEを指定する)
         * @param {String} deviceId デバイスID(UIアプリの場合はnullまたは""(空の文字列)を設定する)
         * @param {String} scopes スコープ(カンマ区切りで複数指定可能。(例)"bivration,file,notification")
         * @param {String} clientSecret クライアントシークレット
         * @return {String} 生成したSignature
         */
        generateSignatureForAccessTokenRequest : function(clientId, grantType, deviceId, scopes, clientSecret) {
            var inputMaps = [];
            inputMaps.push({
                key : "clientId",
                value : clientId
            });
            inputMaps.push({
                key : "grantType",
                value : grantType
            });
            if (deviceId != null && deviceId != "") {
                inputMaps.push({
                    key : "deviceId",
                    value : deviceId
                });
            }

            var strScopes = "";
            scopes.sort();
            for (var i = 0; i < scopes.length; i++) {
                if (i > 0) {
                    strScopes += ",";
                }
                strScopes += scopes[i];
            }
            inputMaps.push({
                key : "scopes",
                value : strScopes
            });

            var authSignatureProc = AuthSignatureProcFactory.getProc(SHA512);
            var signature = authSignatureProc.generateSignature(inputMaps, clientSecret);
            return signature;
        },

        /**
         * アクセストークン受信用のSignatureを生成する.
         * @param {String} accessToken アクセストークン
         * @param {String} clientSecret クライアントシークレット
         * @return {String} 生成したSignature
         */
        generateSignatureForAccessTokenResponse : function(accessToken, clientSecret) {
            var inputMaps = [];
            inputMaps.push({
                key : "accessToken",
                value : accessToken
            });

            var authSignatureProc = AuthSignatureProcFactory.getProc(SHA512);
            var signature = authSignatureProc.generateSignature(inputMaps, clientSecret);
            return signature;
        },

        /**
         * アクセストークン発行リクエスト用のSignatureを生成する(引数パラメータの数により内部処理が切り替わる).
         * @param {String} arg1 arg1
         * @param {String} arg2 arg2
         * @param {String} arg3 arg3
         * @param {String} arg4 arg4
         * @param {String} arg5 arg5
         */
        generateSignature : function(arg1, arg2, arg3, arg4, arg5) {
            if (arguments.length == 5) {
                return AuthSignature.generateSignatureForAccessTokenRequest(arg1, arg2, arg3, arg4, arg5);
            } else if (arguments.length == 2) {
                return AuthSignature.generateSignatureForAccessTokenResponse(arg1, arg2);
            } else {
                return null;
            }
        }
    };

    // ============================================
    //             Public
    // ============================================

    parent.constants = {
        /**
         * @constant
         * dConnectからの処理結果で成功を表す定数.
         */
        RESULT_OK : 0,
        /**
         * @constant
         * dConnectからの処理結果で失敗を表す定数.
         */
        RESULT_ERROR : 1,

        common : {
            PARAM_ACTION : 'action',
            PARAM_DEVICE_ID : 'deviceId',
            PARAM_PLUGIN_ID : 'pluginId',
            PARAM_PROFILE : 'profile',
            PARAM_INTERFACE : 'interface',
            PARAM_ATTRIBUTE : 'attribute',
            PARAM_SESSION_KEY : 'sessionKey',
            PARAM_ACCESS_TOKEN : 'accessToken',
            PARAM_WEB_SOCKET : 'websocket',
            PARAM_RESULT : 'result',
            PARAM_ERROR_CODE : 'errorCode',
            PARAM_ERROR_MESSAGE : 'errorMessage'
        },

        authorization : {
            // Profile name
            PROFILE_NAME : 'authorization',

            // Atttribute
            ATTR_CREATE_CLIENT : 'create_client',
            ATTR_REQUEST_ACCESS_TOKEN : 'request_accesstoken',

            // Parameter
            PARAM_PACKAGE : 'package',
            PARAM_CLIENT_ID : 'clientId',
            PARAM_CLIENT_SECRET : 'clientSecret',
            PARAM_GRANT_TYPE : 'grantType',
            PARAM_SCOPE : "scope",
            PARAM_SCOPES : "scopes",
            PARAM_APPLICATION_NAME : "applicationName",
            PARAM_SIGNATURE : "signature",
            PARAM_ACCESS_TOKEN : "accessToken",
            PARAM_EXPIRE_PERIOD : "expirePeriod",

            /**
             * Defined in 4.1 Authorization Code Grant.
             */
            GRANT_TYPE_AUTHORIZATION_CODE : AUTHORIZATION_CODE,
            /**
             * Defined in 4.3 Resource Owner Password Credentials Grant.
             */
            GRANT_TYPE_PASSWORD : "password",
            /**
             * Defined in 4.4 Client Credentials Grant.
             */
            GRANT_TYPE_CLIENT_CREDENTIALS : "client_credentials",
            /**
             * Defined in 6 Refreshing an Access Token.
             */
            GRANT_TYPE_REFRESH_TOKEN : "refresh_token"
        },

        battery : {
            // Profile name
            PROFILE_NAME : "battery",

            // Atttribute
            ATTR_CHARGING : "charging",
            ATTR_CHARGING_TIME : "chargingTime",
            ATTR_DISCHARGING_TIME : "dischargingTime",
            ATTR_LEVEL : "level",
            ATTR_ON_CHARGING_CHANGE : "onchargingchange",
            ATTR_ON_BATTERY_CHANGE : "onbatterychange",

            // Parameter
            PARAM_CHARGING : "charging",
            PARAM_CHARGING_TIME : "chargingTime",
            PARAM_DISCHARGING_TIME : "dischargingTime",
            PARAM_LEVEL : "level",
            PARAM_BATTERY : "battery",
        },

        connect : {
            // Profile Name
            PROFILE_NAME : "connect",

            // Interface
            INTERFACE_BLUETOOTH : "bluetooth",

            // Attribute
            ATTR_WIFI : "wifi",
            ATTR_BLUETOOTH : "bluetooth",
            ATTR_DISCOVERABLE : "discoverable",
            ATTR_BLE : "ble",
            ATTR_NFC : "nfc",
            ATTR_ON_WIFI_CHANGE : "onwifichange",
            ATTR_ON_BLUETOOTH_CHANGE : "onbluetoothchange",
            ATTR_ON_BLE_CHANGE : "onblechange",
            ATTR_ON_NFC_CHANGE : "onnfcchange",

            // Parameter
            PARAM_ENABLE : "enable",
            PARAM_CONNECT_STATUS : "connectStatus",
        },

        device_orientation : {
            // Profile name
            PROFILE_NAME : "deviceorientation",

            // Attribute
            ATTR_ON_DEVICE_ORIENTATION : "ondeviceorientation",

            // Parameter
            PARAM_ORIENTATION : "orientation",
            PARAM_ACCELERATION : "acceleration",
            PARAM_X : "x",
            PARAM_Y : "y",
            PARAM_Z : "z",
            PARAM_ROTATION_RATE : "rotationRate",
            PARAM_ALPHA : "alpha",
            PARAM_BETA : "beta",
            PARAM_GAMMA : "gamma",
            PARAM_INTERVAL : "interval",
            PARAM_ACCELERATION_INCLUDEING_GRAVITY : "accelerationIncludingGravity",
        },

        file_descriptor : {
            // Profile name
            PROFILE_NAME : "file_descriptor",

            // Attribute
            ATTR_OPEN : "open",
            ATTR_CLOSE : "close",
            ATTR_READ : "read",
            ATTR_WRITE : "write",
            ATTR_ON_WATCH_FILE : "onwatchfile",

            // Parameter
            PARAM_FLAG : "flag",
            PARAM_POSITION : "position",
            PARAM_LENGTH : "length",
            PARAM_SIZE : "size",
            PARAM_FILE : "file",
            PARAM_CURR : "curr",
            PARAM_PREV : "prev",
            PARAM_FILE_DATA : "fileData",
            PARAM_PATH : "path",
            PARAM_MEDIA : "media",

            // ===== ファイルフラグ =====
            // 読み込みのみ.
            FLAG_R : "r",
            // 読み込み書き込み.
            FLAG_RW : "rw",
        },

        file : {
            // Profile name
            PROFILE_NAME : "file",

            // Attribute
            ATTR_RECEIVE : "receive",
            ATTR_SEND : "send",
            ATTR_LIST : "list",
            ATTR_UPDATE : "update",
            ATTR_REMOVE : "remove",

            // Parameter
            PARAM_MIME_TYPE : "mimeType",
            PARAM_FILE_NAME : "fileName",
            PARAM_FILE_SIZE : "fileSize",
            PARAM_MEDIA : "media",
            PARAM_PATH : "path",
            PARAM_FILE_TYPE : "fileType",
            PARAM_ORDER : "order",
            PARAM_OFFSET : "offset",
            PARAM_LIMIT : "limit",
            PARAM_COUNT : "count",
            PARAM_UPDATE_DATE : "updateDate",
            PARAM_FILES : "files",
        },

        media_player : {
            // Profile name
            PROFILE_NAME : "media_player",

            // Attribute
            ATTR_MEDIA : "media",
            ATTR_MEDIA_LIST : "media_list",
            ATTR_PLAY_STATUS : "play_status",
            ATTR_PLAY : "play",
            ATTR_STOP : "stop",
            ATTR_PAUSE : "pause",
            ATTR_RESUME : "resume",
            ATTR_SEEK : "seek",
            ATTR_VOLUME : "volume",
            ATTR_MUTE : "mute",
            ATTR_ON_STATUS_CHANGE : "onstatuschange",

            // Parameter
            PARAM_MEDIA : "media",
            PARAM_MEDIA_ID : "mediaId",
            PARAM_MEDIA_PLAYER : "mediaPlayer",
            PARAM_MIME_TYPE : "mimeType",
            PARAM_TITLE : ",title",
            PARAM_TYPE : "type",
            PARAM_LANGUAGE : "language",
            PARAM_DESCRIPTION : "description",
            PARAM_IMAGE_URI : "imageUri",
            PARAM_DURATION : "duration",
            PARAM_CREATORS : "creators",
            PARAM_CREATOR : "creator",
            PARAM_ROLE : "role",
            PARAM_KEYWORDS : "keywords",
            PARAM_GENRES : "genres",
            PARAM_QUERY : "query",
            PARAM_ORDER : "order",
            PARAM_OFFSET : "offset",
            PARAM_LIMIT : "limit",
            PARAM_COUNT : "count",
            PARAM_STATUS : "status",
            PARAM_POS : "pos",
            PARAM_VOLUME : "volume",
            PARAM_MUTE : "mute",

            // ===== play_statusで指定するステータスを定義 =====
            // Play.
            PLAY_STATUS_PLAY : "play",
            // Stop.
            PLAY_STATUS_STOP : "stop",
            // Pause.
            PLAY_STATUS_PAUSE : "pause",

            // ===== onstatuschangeで受け取るステータス =====
            // Play.
            ON_STATUS_CHANGE_PLAY : "play",
            // Stop.
            ON_STATUS_CHANGE_STOP : "stop",
            // Pause.
            ON_STATUS_CHANGE_PAUSE : "pause",
            // Resume.
            ON_STATUS_CHANGE_RESUME : "resume",
            // Mute.
            ON_STATUS_CHANGE_MUTE : "mute",
            // Unmute.
            ON_STATUS_CHNAGE_UNMUTE : "unmute",
            // Media.
            ON_STATUS_CHANGE_MEDIA : "media",
            // Volume.
            ON_STATUS_CHANGE_VOLUME : "volume",
            // complete.
            ON_STATUS_CHANGE_COMPLETE : "complete",

            // ===== 並び順 =====
            // 昇順.
            ORDER_ASC : "asc",
            // 降順.
            ORDER_DSEC : "desc",
        },

        media_stream_recording : {
            // Profile name
            PROFILE_NAME : "mediastream_recording",

            // Attribute
            ATTR_MEDIARECORDER : "mediarecorder",
            ATTR_TAKE_PHOTO : "takephoto",
            ATTR_RECORD : "record",
            ATTR_PAUSE : "pause",
            ATTR_RESUME : "resume",
            ATTR_STOP : "stop",
            ATTR_MUTETRACK : "mutetrack",
            ATTR_UNMUTETRACK : "unmutetrack",
            ATTR_OPTIONS : "options",
            ATTR_ON_PHOTO : "onphoto",
            ATTR_ON_DATA_AVAILABLE : "ondataavailable",
            ATTR_ON_RECORDING_CHANGE : "onrecordingchange",

            PARAM_TARGET : "target",
            PARAM_RECORDERS : "recorders",
            PARAM_ID : "id",
            PARAM_NAME : "name",
            PARAM_STATE : "state",
            PARAM_IMAGE_WIDTH : "imageWidth",
            PARAM_IMAGE_HEIGHT : "imageHeight",
            PARAM_MIME_TYPE : "mimeType",
            PARAM_CONFIG : "config",
            PARAM_TIME_SLICE : "timeslice",
            PARAM_SETTINGS : "settings",
            PARAM_PHOTO : "photo",
            PARAM_MEDIA : "media",
            PARAM_STATUS : "status",
            PARAM_ERROR_MESSAGE : "errorMessage",
            PARAM_PATH : "path",
            PARAM_MIN : "min",
            PARAM_MAX : "max",

            // ===== カメラの状態定数 =====
            // 停止中
            RECORDER_STATE_INACTIVE : "inactive",
            // レコーディング中
            RECORDER_STATE_RECORDING : "recording",
            // 一時停止中
            RECORDER_STATE_PAUSED : "paused",

            // ===== 動画撮影、音声録音の状態定数 =====
            // 開始
            RECORDING_STATE_RECORDING : "recording",
            // 終了
            RECORDING_STATE_STOP : "stop",
            // 一時停止
            RECORDING_STATE_PAUSE : "pause",
            // 再開
            RECORDING_STATE_RESUME : "resume",
            // ミュート
            RECORDING_STATE_MUTETRACK : "mutetrack",
            // ミュート解除
            RECORDING_STATE_UNMUTETRACK : "unmutetrack",
            // エラー発生
            RECORDING_STATE_ERROR : "error",
            // 警告発生
            RECORDING_STATE_WARNING : "warning",
        },

        network_service_discovery : {
            // Profile name
            PROFILE_NAME : "network_service_discovery",

            // Attribute
            ATTR_GET_NETWORK_SERVICES : "getnetworkservices",
            ATTR_ON_SERVICE_CHANGE : "onservicechange",

            // Parameter
            PARAM_NETWORK_SERVICE : "networkService",
            PARAM_SERVICES : "services",
            PARAM_STATE : "state",
            PARAM_ID : "id",
            PARAM_NAME : "name",
            PARAM_TYPE : "type",
            PARAM_ONLINE : "online",
            PARAM_CONFIG : "config",

            // ===== ネットワークタイプ =====
            // WiFi
            NETWORK_TYPE_WIFI : "WiFi",
            // BLE
            NETWORK_TYPE_BLE : "BLE",
            // NFC
            NETWORK_TYPE_NFC : "NFC",
            // Bluetooth
            NETWORK_TYPE_BLUETOOTH : "Bluetooth",
        },

        notification : {
            // Profile name
            PROFILE_NAME : "notification",

            // Attribute
            ATTR_NOTIFY : "notify",
            ATTR_ON_CLICK : "onclick",
            ATTR_ON_CLOSE : "onclose",
            ATTR_ON_ERROR : "onerror",
            ATTR_ON_SHOW : "onshow",

            // Parameter
            PARAM_BODY : "body",
            PARAM_TYPE : "type",
            PARAM_DIR : "dir",
            PARAM_LANG : "lang",
            PARAM_TAG : "tag",
            PARAM_ICON : "icon",
            PARAM_NOTIFICATION_ID : "notificationId",

            // ===== 通知タイプ定数 =====
            // 音声通話着信
            NOTIFICATION_TYPE_PHONE : 0,
            // メール着信
            NOTIFICATION_TYPE_MAIL : 1,
            // SMS着信
            NOTIFICATION_TYPE_SMS : 2,
            // イベント
            NOTIFICATION_TYPE_EVENT : 3,

            // ===== 向き =====
            // 自動
            DIRECTION_AUTO : "auto",
            // 右から左
            DIRECTION_RIGHT_TO_LEFT : "rtl",
            // 左から右
            DIRECTION_LEFT_TO_RIGHT : "ltr",
        },

        phone : {
            // Profile name
            PROFILE_NAME : "phone",

            // Attribute
            ATTR_CALL : "call",
            ATTR_SET : "set",
            ATTR_ON_CONNECT : "onconnect",

            // Parameter
            PARAM_PHONE_NUMBER : "phoneNumber",
            PARAM_MODE : "mode",
            PARAM_PHONE_STATUS : "phoneStatus",
            PARAM_STATE : "state",

            // ===== 電話のモード定数 =====
            // サイレントモード
            PHONE_MODE_SILENT : 0,
            // マナーモード
            PHONE_MODE_MANNER : 1,
            // 音あり
            PHONE_MODE_SOUND : 2,

            // ===== 通話状態定数 =====
            // 通話開始
            CALL_STATE_START : 0,
            // 通話失敗
            CALL_STATE_FAILED : 1,
            // 通話終了
            CALL_STATE_FINISHED : 2,
        },

        proximity : {
            // Profile name
            PROFILE_NAME : "proximity",

            // Attribute
            ATTR_ON_DEVICE_PROXIMITY : "ondeviceproximity",
            ATTR_ON_USER_PROXIMITY : "onuserproximity",

            // Parameter
            PARAM_VALUE : "value",
            PARAM_MIN : "min",
            PARAM_MAX : "max",
            PARAM_THRESHOLD : "threshold",
            PARAM_PROXIMITY : "proximity",
            PARAM_NEAR : "near",
        },

        settings : {
            // Profile name
            PROFILE_NAME : "settings",

            // Interface
            INTERFACE_SOUND : "sound",
            INTERFACE_DISPLAY : "display",

            // Attribute
            ATTR_VOLUME : "volume",
            ATTR_DATE : "date",
            ATTR_LIGHT : "light",
            ATTR_SLEEP : "sleep",

            // Parameter
            PARAM_KIND : "kind",
            PARAM_LEVEL : "level",
            PARAM_DATE : "date",
            PARAM_TIME : "time",

            // ===== 最大最小 =====
            // 最大Level
            MAX_LEVEL : 1.0,
            // 最小Level
            MIN_LEVEL : 0,

            // ===== 音量の種別定数 =====
            // アラーム
            VOLUME_KIND_ALARM : 1,
            // 通話音
            VOLUME_KIND_CALL : 2,
            // 着信音
            VOLUME_KIND_RINGTONE : 3,
            // メール着信音
            VOLUME_KIND_MAIL : 4,
            // その他SNS等の着信音
            VOLUME_KIND_OTHER : 5,
            // メディアプレーヤーの音量
            VOLUME_KIND_MEDIA_PLAYER : 6,
        },

        system : {
            // Profile name
            PROFILE_NAME : "system",

            // Interface
            INTERFACE_DEVICE : "device",

            // Attribute
            ATTRI_DEVICE : "device",
            ATTRI_EVENTS : "events",
            ATTRI_KEYWORD : "keyword",
            ATTRI_WAKEUP : "wakeup",

            // Parameter
            PARAM_SUPPORTS : "supports",
            PARAM_VERSION : "version",
            PARAM_CONNECT : "connect",
            PARAM_WIFI : "wifi",
            PARAM_BLUETOOTH : "bluetooth",
            PARAM_NFC : "nfc",
            PARAM_BLE : "ble",
            PARAM_ID : "id",
            PARAM_NAME : "name",
            PARAM_PLUGINS : "plugins",
            PARAM_PLUGIN_ID : "pluginId",
        },

        vibration : {
            // Profile name
            PROFILE_NAME : "vibration",

            // Attribute
            ATTR_VIBRATE : "vibrate",

            // Parameter
            PARAM_PATTERN : "pattern",
        },
    };

    /**
     * REST API呼び出し.
     *
     * @param method HTTPメソッド
     * @param uri URI
     * @param header ヘッダー。Key-Valueマップで渡す。
     * @param data コンテンツデータ
     * @param success_cb 成功時コールバック。xhr.status、ヘッダー、xhr.responseTextが渡される。
     * @param error_cb 失敗時コールバック。xhr.readyStateとxhr.status（null有り）が渡される。
     */
    parent.execute = function(method, uri, header, data, success_cb, error_cb) {
        // TODO [2014/06/05 福井] method,uri等の妥当性チェックは必要？d-Connect側でやるなら必要ないと思うけれど
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            // OPENED: open()が呼び出されて、まだsend()が呼び出されてない。
            if (xhr.readyState === 1) {
                for (var key in header) {
                    xhr.setRequestHeader(key.toLowerCase(), header[key]);
                }

                xhr.send(data);
            }
            // HEADERS_RECEIVED: send() が呼び出され、ヘッダーとステータスが通った。
            else if (xhr.readyState === 2) {
                // console.log("### 2");
            }
            // LOADING: ダウンロード中
            else if (xhr.readyState === 3) {
                // console.log("### 3");
            }
            // DONE: 一連の動作が完了した。
            else if (xhr.readyState === 4) {
                if (xhr.status === 200 || xhr.status === 0) {
                    if ( typeof success_cb === "function") {
                        var headerMap = {};
                        var headerArr = xhr.getAllResponseHeaders().split('\r\n');
                        for (var key in headerArr) {
                            var delim_idx = headerArr[key].indexOf(':');
                            var hKey = headerArr[key].substr(0, delim_idx).toLowerCase();
                            var hVal = headerArr[key].substr(delim_idx + 1).trim();
                            if (hKey.length != 0) {
                                headerMap[hKey] = hVal;
                            }
                        }
                        success_cb(xhr.status, headerMap, xhr.responseText);
                    }
                } else {
                    error_cb(xhr.readyState, xhr.status);
                }
            }
        };
        xhr.onerror = function() {
            console.log("### error");
        };
        xhr.open(method, uri, true);
    };

    /**
     * Network Service Discovery APIへの簡易アクセスを提供する。
     *
     * @param success_cb 成功時コールバック。xhr.status、ヘッダー、xhr.responseTextが渡される。
     * @param success_cb 失敗時コールバック。xhr.readyState、xhr.status（null有り）が渡される。
     *
     * @example
     * // デバイスの検索
     * dConnect.discoverDevices(
     *     function(status, headerMap, responseText) {
     *         var json = JSON.parse(responseText);
     *     },
     *     function(readyState, status) {
     *     });
     */
    parent.discoverDevices = function(success_cb, error_cb) {
        parent.execute('GET', parent.getBaseDomain() + '/network_service_discovery/getnetworkservices', null, null, success_cb, error_cb);
    };

    /**
     * System APIへの簡易アクセスを提供する。
     *
     * @param success_cb 成功時コールバック。xhr.status、ヘッダー、xhr.responseTextが渡される。
     * @param success_cb 失敗時コールバック。xhr.readyState、xhr.status（null有り）が渡される。
     */
    parent.getSystemInfo = function(success_cb, error_cb) {
        parent.execute('GET', parent.getBaseDomain() + '/system', null, null, success_cb, error_cb);
    };

    /**
     * d-Connect Managerが起動しているチェックする。そもそもインストールされていなければ、インストール
     * 画面へと進ませる。
     */
    parent.checkDConnect = function() {
        this.getSystemInfo(function(status, headers, data) {
            var userAgent = navigator.userAgent.toLowerCase();
            if (status === 200) {
                var obj = JSON.parse(data);
                if (obj.result == 0) {
                    // localhost:8080でGotAPIが利用可能
                    alert("d-Connect API version:" + obj.version);
                } else {
                    // localhost:8080にサーバが起動しているがGotAPIではない何かが起動
                    alert("d-Connect was not found; it seems another server is running instead.");
                }
            } else if (status === 0) {
                // localhost:8080にはサーバが起動していない状態
                alert("d-Connect was not found.");
                if (userAgent.indexOf("android") > -1) {
                    // URLスキーム経由でdConnectを起動(Android)
                    location.href = "intent://start/#Intent;scheme=dconnect;package=com.nttdocomo.android.dconnect;end";
                }
                // iOS
                else if (userAgent.search(/iphone|ipad|ipod/) > -1) {
                    // URLスキーム経由でdConnectを起動(iOS)
                    var div = $("<div/>").css({
                        width : "0",
                        height : "0",
                        overflow : "hidden"
                    }).appendTo($(document.body));
                    $("<iframe/>").attr("id", "launch_frame").attr("name", "launch_frame").appendTo(div);
                    launch_frame.location.href = "dconnect://";
                    setTimeout(function() {
                        $("#launch_frame").remove();
                        // TODO [2014/06/06 福井] iTunes App Storeのd-Connect Browserダウンロード・ページを開く
                        location.href = "itmss://itunes.apple.com/us/app/dconnect/id123456789?ls=1&mt=8";
                    }, 500);
                }
            }
        }, null);
    };

    /**
     * 指定されたd-Connect Event APIにイベントリスナーを登録する。
     *
     * @param uri 特定のd-Connect Event APIを表すURI
     * @param deviceId デバイスID
     * @param sessionKey セッションキー
     * @param cb 登録したいイベント受領用コールバック。
     *
     * @example
     * var uri = "http://localhost:8080/battery/onchargingchange";
     * dConnect.addEventListener(uri, deviceid, sessionKey, function(message) {
     *     // イベントメッセージが送られてくる
     *     var json = JSON.parse(message);
     * });
     */
    parent.addEventListener = function(uri, deviceId, sessionKey, cb) {
        // TODO [2014/06/06 福井] uriに既にパラメータが指定してある場合はどうする？
        var data = "";
        if (sessionKey) {
            data += "sessionKey=" + sessionKey;
        }
        if (deviceId) {
            data += "&deviceId=" + deviceId;
        }

        parent.execute('PUT', uri, null, data, function(status, headerMap, responseText) {
            var json = JSON.parse(responseText);
            if (json.result == parent.constants.RESULT_OK) {
                eventListener[uri] = cb;
            } else {
                alert("add erroro");
            }
        }, function(readyState, status) {
            alert("error");
        });
    };

    /**
     * 指定されたd-Connect Event APIからイベントリスナーを削除する。
     *
     * @param uri 特定のd-Connect Event APIを表すURI
     * @param deviceId デバイスID
     * @param sessionKey セッションキー
     *
     * @example
     * var uri = "http://localhost:8080/battery/onchargingchange";
     * dConnect.removeEventListener(uri, deviceId, sessionKey);
     */
    parent.removeEventListener = function(uri, deviceId, sessionKey) {
        // TODO [2014/06/06 福井] uriに既にパラメータが指定してある場合はどうする？
        parent.execute('DELETE', uri + "?deviceId=" + deviceId + "&sessionKey=" + sessionKey, null, null, function(status, headerMap, responseText) {
            var json = JSON.parse(responseText);
            if (json.result == parent.constants.RESULT_OK) {
                eventListener[uri] = null;
            } else {
                alert("remove erroro");
            }
        }, function(readyState, status) {
            alert("error");
        });
    };

    /**
     * dConnectManagnerに認可を求める.
     *
     * @param packageName アプリを識別するためのURI
     * @param scopes 使用するスコープの配列
     * @param applicationName アプリ名
     * @param success_cb 成功時のコールバック
     * @param error_cb 失敗時のコールバック
     *
     * @example
     * // アクセスするプロファイル一覧を定義
     * var scopes = Array('network_service_discovery', 'sysytem', 'battery');
     * // 認可を実行
     * dConnect.authorization('http://hogehoge.com/index.html', scopes, 'サンプル',
     *     function(clientId, clientSecret, accessToken) {
     *         // clientId, clientSecret, accessTokenを保存して、プロファイルにアクセス
     *     },
     *     function(errorCode, errorMessage) {
     *         alert("Failed to get accessToken.");
     *     });
     */
    parent.authorization = function(packageName, scopes, applicationName, success_cb, error_cb) {
        parent.createClient(packageName, function(clientId, clientSecret) {
            parent.requestAccessToken(clientId, clientSecret, scopes, applicationName, function(accessToken) {
                if (success_cb) {
                    success_cb(clientId, clientSecret, accessToken);
                }
            }, error_cb);
        }, error_cb);
    };

    /**
     * クライアントを作成する.
     *
     * @param pakcageName ヘージを識別するための名前
     * @param success_cb クライアント作成に成功した場合のコールバック
     * @param error_cb クライアント作成に失敗した場合のコールバック
     *
     * @example
     * dConnect.createClient(packageName,
     *     function(clientId, clientSecret) {
     *         // clientId, clientSecretを保存して、アクセストークンの取得に使用する
     *     },
     *     function(errorCode, errorMessage) {
     *     }
     * );
     */
    parent.createClient = function(packageName, success_cb, error_cb) {
        var uri = parent.getBaseDomain() + '/authorization/create_client?package=' + packageName;
        parent.execute('GET', uri, null, null, function(status, headerMap, responseText) {
            var json = JSON.parse(responseText);
            // TODO 定数を用意すること！！！
            if (json.result == 0) {
                var clientId = json.clientId;
                var clientSecret = json.clientSecret;
                if (success_cb) {
                    success_cb(clientId, clientSecret);
                }
            } else {
                var errorCode = json.errorCode;
                var errorMessage = json.errorMessage;
                if (error_cb) {
                    error_cb(errorCode, errorMessage);
                }
            }
        }, function(xhr, textStatus, errorThrown) {
            if (error_cb) {
                error_cb(0, "Failed to create client.");
            }
        });
    };

    /**
     * アクセストークンを要求する.
     *
     * @param clientId クライアントID
     * @param clientSecret クライアントシークレット
     * @param scopes スコープ一覧(配列)
     * @param applicationName アプリ名
     * @param success_cb アクセストークン取得に成功した場合のコールバック
     * @param error_cb アクセストークン取得に失敗した場合のコールバック
     *
     * @example
     * dConnect.requestAccessToken(clientId, clientSecret, scopes, 'アプリ名',
     *     function(accessToken) {
     *         // アクセストークンの保存して、プロファイルのアクセスを行う
     *     },
     *     function(errorCode, errorMessage) {
     *     }
     * );
     */
    parent.requestAccessToken = function(clientId, clientSecret, scopes, applicatonName, success_cb, error_cb) {
        // パラメータ作成
        var sig = dConnect.oauth.generateSignatureForAccessTokenRequest(clientId, AUTHORIZATION_CODE, undefined, scopes, clientSecret);
        // uri作成
        // TODO 定数を用意すること！！！
        var uri = parent.getBaseDomain() + '/authorization/request_accesstoken';
        uri += '?clientId=' + clientId;
        uri += '&grantType=' + AUTHORIZATION_CODE;
        uri += '&scope=' + parent.combineScope(scopes);
        uri += '&signature=' + sig;
        uri += '&applicationName=' + applicatonName;
        parent.execute('GET', uri, null, null, function(status, headerMap, responseText) {
            var json = JSON.parse(responseText);
            if (json.result == 0) {
                webAppAccessToken = json.accessToken;
                if (success_cb) {
                    success_cb(webAppAccessToken);
                }
            } else {
                var errorCode = json.errorCode;
                var errorMessage = json.errorMessage;
                if (error_cb) {
                    error_cb(errorCode, errorMessage);
                }
            }
        }, function(xhr, textStatus, errorThrown) {
            if (error_cb) {
                error_cb(0, "Failed to get access token.");
            }
        });
    };

    /**
     * スコープの配列を文字列に置換する.
     * @param scopes スコープ一覧
     * @return 連結されたスコープ一覧
     */
    parent.combineScope = function(scopes) {
        var scope = '';
        for (var i = 0; i < scopes.length; i++) {
            if (i > 0) {
                scope += ',';
            }
            scope += scopes[i];
        }
        return scope;
    };

    /**
     * ホスト名を設定する.
     * @param h ホスト名
     */
    parent.setHost = function(h) {
        host = h;
    };

    /**
     * ポート番号を設定する.
     * @param p ポート番号
     */
    parent.setPort = function(p) {
        port = p;
    };

    /**
     * ベースとなるドメイン名を取得する.
     * @return ドメイン名
     */
    parent.getBaseDomain = function() {
        return 'http://' + host + ':' + port;
    };

    /**
     * WebSocketを開く.
     * @param {!string} sessionKey d-Connect側に要求したいイベント用WebSocketの識別子
     * @param {!MessageCallback} cb dConnect Managerから送られてくるイベントを全て受け取るコールバック関数
     *
     * @example
     * // Websocketを開く
     * dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {
     * });
     *
     */
    parent.connectWebSocket = function(sessionKey, cb) {
        websocket = new WebSocket('ws://' + host + ':' + port + '/websocket');
        websocket.onopen = function(e) {
            // 本アプリのイベント用WebSocketと1対1で紐づいたセッションキーをd-Connect Managerに登録してもらう。
            websocket.send('{"sessionKey":"' + sessionKey + '"}');
            if (cb) {
                cb(0, "open");
            }
            alert("open");
        };
        websocket.onmessage = function(msg) {
            var json = JSON.parse(msg.data);
            var uri = "/";
            if (json.profile) {
                uri += json.profile;
            }
            if (json.interface) {
                uri += "/";
                uri += json.interface;
            }
            if (json.attribute) {
                uri += "/";
                uri += json.attribute;
            }
            for (var key in eventListener) {
                if (key.lastIndexOf(uri) > 0) {
                    eventListener[key](msg.data);
                }
            }
        };
        websocket.onclose = function(e) {
            if (cb) {
                cb(1, "close");
            }
        };
    };

    /**
     * WebSocketを切断する.
     */
    parent.disconnectWebSocket = function() {
        if (websocket) {
            websocket.close();
            websocket = undefined;
        }
    }
    /**
     * URIを作成するためのユーティリティクラス。
     * <p>
     * ホスト名やポート番号は、省略された場合にはdConnect.setHost()、
     * dConnect.setPort()で指定された値が設定される。
     * </p>
     * @example
     * var builder = new dConnect.URIBuilder();
     * builder.setProfile("battery");
     * builder.setAttribute("level");
     * builder.setDeviceId(deviceId);
     * builder.setAccessToken(accessToken);
     * builder.addParameter("key", "value");
     *
     * var uri = builder.build();
     *
     * uriは"http://localhost:8080/battery/level?deviceId=deviceId&accessToken=accessToken&key=value"に変換される。
     */
    parent.URIBuilder = function() {
        this.scheme = "http://";
        this.host = host;
        this.port = port;
        this.profile = null;
        this.inter = null;
        this.attribute = null;
        this.params = {};
    }
    /**
     * スキーマを設定する。
     * <p>
     * デフォルトでは、「http://」が設定されている。
     * </p>
     * @param scheme スキーマ
     */
    parent.URIBuilder.prototype.setScheme = function(scheme) {
        this.scheme = scheme;
    }
    /**
     * スキーマを取得する。
     * @return スキーマ
     */
    parent.URIBuilder.prototype.getScheme = function() {
        return this.scheme;
    }
    /**
     * ホスト名を設定する。
     * <p>
     * デフォルトでは、dConnect.setHost()で設定された値が設定される。<br/>
     * 何も設定していない場合にはlocalhostが設定される。
     * </p>
     * @param host ホスト名
     */
    parent.URIBuilder.prototype.setHost = function(host) {
        this.host = host;
    }
    /**
     * ホスト名を取得する。
     * @return ホスト名
     */
    parent.URIBuilder.prototype.getHost = function() {
        return this.host;
    }
    /**
     * ポート番号を設定する。
     * <p>
     * デフォルトでは、dConnect.setPort()で設定された値が設定される。<br/>
     * 何も設定していない場合には8080が設定される。
     * </p>
     */
    parent.URIBuilder.prototype.setPort = function(port) {
        this.port = port;
    }
    /**
     * ポート番号を取得する。
     * @return ポート番号
     */
    parent.URIBuilder.prototype.getPort = function() {
        return this.port;
    }
    /**
     * プロファイル名を設定する。
     * <p>
     * dConnectで定義してあるプロファイル名を指定すること。<br/>
     * <ul>
     * <li>network_service_discovery</li>
     * <li>system</li>
     * <li>battery</li>
     * <li>mediastream_recording</li>
     * </ul>
     * などなど。
     * </p>
     * @param profile プロファイル名
     */
    parent.URIBuilder.prototype.setProfile = function(profile) {
        this.profile = profile;
    }
    /**
     * プロファイル名を取得する。
     * @return プロファイル名
     */
    parent.URIBuilder.prototype.getProfile = function() {
        return this.profile;
    }
    /**
     * インターフェース名を設定する。
     * @param inter インターフェース名
     */
    parent.URIBuilder.prototype.setInterface = function(inter) {
        this.inter = inter;
    }
    /**
     * インターフェース名を取得する。
     * @return インターフェース名
     */
    parent.URIBuilder.prototype.getInterface = function() {
        return this.inter;
    }
    /**
     * アトリビュート名を設定する。
     * @param attribute アトリビュート名
     */
    parent.URIBuilder.prototype.setAttribute = function(attribute) {
        this.attribute = attribute;
    }
    /**
     * アトリビュート名を取得する。
     * @return アトリビュート名
     */
    parent.URIBuilder.prototype.getAttribute = function() {
        return this.attribute;
    }
    /**
     * デバイスIDを設定する。
     * @param deviceId デバイスID
     */
    parent.URIBuilder.prototype.setDeviceId = function(deviceId) {
        this.params['deviceId'] = deviceId
    }
    /**
     * アクセストークンを設定する。
     * @param accessToken アクセストークン
     */
    parent.URIBuilder.prototype.setAccessToken = function(accessToken) {
        this.params['accessToken'] = accessToken
    }
    /**
     * セッションキーを設定する。
     * @param sessionKey セッションキー
     */
    parent.URIBuilder.prototype.setSessionKey = function(sessionKey) {
        this.params['sessionKey'] = sessionKey
    }
    /**
     * パラメータを追加する。
     * @param key キー
     * @param value バリュー
     */
    parent.URIBuilder.prototype.addParameter = function(key, value) {
        this.params[key] = value
    }
    /**
     * URIに変換する。
     * @return uri
     */
    parent.URIBuilder.prototype.build = function() {
        var uri = this.scheme + this.host + ":" + this.port;
        if (this.profile) {
            uri += "/" + this.profile
        }
        if (this.inter) {
            uri += "/" + this.inter;
        }
        if (this.attribute) {
            uri += "/" + this.attribute
        }
        if (this.params) {
            var p = "";
            for (var key in this.params) {
                p += (p.length == 0) ? "?" : "&";
                p += (key + "=" + this.params[key]);
            }
            uri += p;
        }
        return uri;
    }
    /**
     Local OAuth用インターフェース。
     */
    parent.oauth = AuthSignature;

    if (global.process) {
        exports.dConnect = dConnect;
    }
    // global.dConnect = dConnect;

    $(document).ready(function() {
        // parent.checkDConnect();
    });

    return parent;
})(dConnect || {}, this.self || global);

/*
 A JavaScript implementation of the SHA family of hashes, as
 defined in FIPS PUB 180-2 as well as the corresponding HMAC implementation
 as defined in FIPS PUB 198a

 Copyright Brian Turek 2008-2013
 Distributed under the BSD License
 See http://caligatio.github.com/jsSHA/ for more information

 Several functions taken from Paul Johnston
 */
(function(T) {
    function z(a, c, b) {
        var g = 0, f = [0], h = "", l = null, h = b || "UTF8";
        if ("UTF8" !== h && "UTF16" !== h)
            throw "encoding must be UTF8 or UTF16";
        if ("HEX" === c) {
            if (0 !== a.length % 2)
                throw "srcString of HEX type must be in byte increments";
            l = B(a);
            g = l.binLen;
            f = l.value
        } else if ("ASCII" === c || "TEXT" === c)
            l = J(a, h), g = l.binLen, f = l.value;
        else if ("B64" === c)
            l = K(a), g = l.binLen, f = l.value;
        else
            throw "inputFormat must be HEX, TEXT, ASCII, or B64";
        this.getHash = function(a, c, b, h) {
            var l = null, d = f.slice(), n = g, p;
            3 === arguments.length ? "number" !== typeof b && ( h = b, b = 1) : 2 === arguments.length && ( b = 1);
            if (b !== parseInt(b, 10) || 1 > b)
                throw "numRounds must a integer >= 1";
            switch(c) {
            case "HEX":
                l = L;
                break;
            case "B64":
                l = M;
                break;
            default:
                throw "format must be HEX or B64";
            }
            if ("SHA-1" === a)
                for ( p = 0; p < b; p++)
                    d = y(d, n), n = 160;
            else if ("SHA-224" === a)
                for ( p = 0; p < b; p++)
                    d = v(d, n, a), n = 224;
            else if ("SHA-256" === a)
                for ( p = 0; p < b; p++)
                    d = v(d, n, a), n = 256;
            else if ("SHA-384" === a)
                for ( p = 0; p < b; p++)
                    d = v(d, n, a), n = 384;
            else if ("SHA-512" === a)
                for ( p = 0; p < b; p++)
                    d = v(d, n, a), n = 512;
            else
                throw "Chosen SHA variant is not supported";
            return l(d, N(h))
        };
        this.getHMAC = function(a, b, c, l, s) {
            var d, n, p, m, w = [], x = [];
            d = null;
            switch(l) {
            case "HEX":
                l = L;
                break;
            case "B64":
                l = M;
                break;
            default:
                throw "outputFormat must be HEX or B64";
            }
            if ("SHA-1" === c)
                n = 64, m = 160;
            else if ("SHA-224" === c)
                n = 64, m = 224;
            else if ("SHA-256" === c)
                n = 64, m = 256;
            else if ("SHA-384" === c)
                n = 128, m = 384;
            else if ("SHA-512" === c)
                n = 128, m = 512;
            else
                throw "Chosen SHA variant is not supported";
            if ("HEX" === b)
                d = B(a), p = d.binLen, d = d.value;
            else if ("ASCII" === b || "TEXT" === b)
                d = J(a, h), p = d.binLen, d = d.value;
            else if ("B64" === b)
                d = K(a), p = d.binLen, d = d.value;
            else
                throw "inputFormat must be HEX, TEXT, ASCII, or B64";
            a = 8 * n;
            b = n / 4 - 1;
            n < p / 8 ? ( d = "SHA-1" === c ? y(d, p) : v(d, p, c), d[b] &= 4294967040) : n > p / 8 && (d[b] &= 4294967040);
            for ( n = 0; n <= b; n += 1)
                w[n] = d[n] ^ 909522486, x[n] = d[n] ^ 1549556828;
            c = "SHA-1" === c ? y(x.concat(y(w.concat(f), a + g)), a + m) : v(x.concat(v(w.concat(f), a + g, c)), a + m, c);
            return l(c, N(s))
        }
    }

    function s(a, c) {
        this.a = a;
        this.b = c
    }

    function J(a, c) {
        var b = [], g, f = [], h = 0, l;
        if ("UTF8" === c)
            for ( l = 0; l < a.length; l += 1)
                for ( g = a.charCodeAt(l), f = [], 2048 < g ? (f[0] = 224 | (g & 61440) >>> 12, f[1] = 128 | (g & 4032) >>> 6, f[2] = 128 | g & 63) : 128 < g ? (f[0] = 192 | (g & 1984) >>> 6, f[1] = 128 | g & 63) : f[0] = g, g = 0; g < f.length; g += 1)
                    b[h >>> 2] |= f[g] << 24 - h % 4 * 8, h += 1;
        else if ("UTF16" === c)
            for ( l = 0; l < a.length; l += 1)
                b[h >>> 2] |= a.charCodeAt(l) << 16 - h % 4 * 8, h += 2;
        return {
            value : b,
            binLen : 8 * h
        }
    }

    function B(a) {
        var c = [], b = a.length, g, f;
        if (0 !== b % 2)
            throw "String of HEX type must be in byte increments";
        for ( g = 0; g < b; g += 2) {
            f = parseInt(a.substr(g, 2), 16);
            if (isNaN(f))
                throw "String of HEX type contains invalid characters";
            c[g >>> 3] |= f << 24 - g % 8 * 4
        }
        return {
            value : c,
            binLen : 4 * b
        }
    }

    function K(a) {
        var c = [], b = 0, g, f, h, l, r;
        if (-1 === a.search(/^[a-zA-Z0-9=+\/]+$/))
            throw "Invalid character in base-64 string";
        g = a.indexOf("=");
        a = a.replace(/\=/g, "");
        if (-1 !== g && g < a.length)
            throw "Invalid '=' found in base-64 string";
        for ( f = 0; f < a.length; f += 4) {
            r = a.substr(f, 4);
            for ( h = l = 0; h < r.length; h += 1)
                g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".indexOf(r[h]), l |= g << 18 - 6 * h;
            for ( h = 0; h < r.length - 1; h += 1)
                c[b >> 2] |= (l >>> 16 - 8 * h & 255) << 24 - b % 4 * 8, b += 1
        }
        return {
            value : c,
            binLen : 8 * b
        }
    }

    function L(a, c) {
        var b = "", g = 4 * a.length, f, h;
        for ( f = 0; f < g; f += 1)
            h = a[f >>> 2] >>> 8 * (3 - f % 4), b += "0123456789abcdef".charAt(h >>> 4 & 15) + "0123456789abcdef".charAt(h & 15);
        return c.outputUpper ? b.toUpperCase() : b
    }

    function M(a, c) {
        var b = "", g = 4 * a.length, f, h, l;
        for ( f = 0; f < g; f += 3)
            for ( l = (a[f >>> 2] >>> 8 * (3 - f % 4) & 255) << 16 | (a[f + 1 >>> 2] >>> 8 * (3 - (f + 1) % 4) & 255) << 8 | a[f + 2 >>> 2] >>> 8 * (3 - (f + 2) % 4) & 255, h = 0; 4 > h; h += 1)
                b = 8 * f + 6 * h <= 32 * a.length ? b + "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(l >>> 6 * (3 - h) & 63) : b + c.b64Pad;
        return b
    }

    function N(a) {
        var c = {
            outputUpper : !1,
            b64Pad : "="
        };
        try {
            a.hasOwnProperty("outputUpper") && (c.outputUpper = a.outputUpper), a.hasOwnProperty("b64Pad") && (c.b64Pad = a.b64Pad)
        } catch(b) {
        }
        if ("boolean" !== typeof c.outputUpper)
            throw "Invalid outputUpper formatting option";
        if ("string" !== typeof c.b64Pad)
            throw "Invalid b64Pad formatting option";
        return c
    }

    function U(a, c) {
        return a << c | a >>> 32 - c
    }

    function u(a, c) {
        return a >>> c | a << 32 - c
    }

    function t(a, c) {
        var b = null, b = new s(a.a, a.b);
        return b = 32 >= c ? new s(b.a >>> c | b.b << 32 - c & 4294967295, b.b >>> c | b.a << 32 - c & 4294967295) : new s(b.b >>> c - 32 | b.a << 64 - c & 4294967295, b.a >>> c - 32 | b.b << 64 - c & 4294967295)
    }

    function O(a, c) {
        var b = null;
        return b = 32 >= c ? new s(a.a >>> c, a.b >>> c | a.a << 32 - c & 4294967295) : new s(0, a.a >>> c - 32)
    }

    function V(a, c, b) {
        return a ^ c ^ b
    }

    function P(a, c, b) {
        return a & c ^ ~a & b
    }

    function W(a, c, b) {
        return new s(a.a & c.a ^ ~a.a & b.a, a.b & c.b ^ ~a.b & b.b)
    }

    function Q(a, c, b) {
        return a & c ^ a & b ^ c & b
    }

    function X(a, c, b) {
        return new s(a.a & c.a ^ a.a & b.a ^ c.a & b.a, a.b & c.b ^ a.b & b.b ^ c.b & b.b)
    }

    function Y(a) {
        return u(a, 2) ^ u(a, 13) ^ u(a, 22)
    }

    function Z(a) {
        var c = t(a, 28), b = t(a, 34);
        a = t(a, 39);
        return new s(c.a ^ b.a ^ a.a, c.b ^ b.b ^ a.b)
    }

    function $(a) {
        return u(a, 6) ^ u(a, 11) ^ u(a, 25)
    }

    function aa(a) {
        var c = t(a, 14), b = t(a, 18);
        a = t(a, 41);
        return new s(c.a ^ b.a ^ a.a, c.b ^ b.b ^ a.b)
    }

    function ba(a) {
        return u(a, 7) ^ u(a, 18) ^ a >>> 3
    }

    function ca(a) {
        var c = t(a, 1), b = t(a, 8);
        a = O(a, 7);
        return new s(c.a ^ b.a ^ a.a, c.b ^ b.b ^ a.b)
    }

    function da(a) {
        return u(a, 17) ^ u(a, 19) ^ a >>> 10
    }

    function ea(a) {
        var c = t(a, 19), b = t(a, 61);
        a = O(a, 6);
        return new s(c.a ^ b.a ^ a.a, c.b ^ b.b ^ a.b)
    }

    function R(a, c) {
        var b = (a & 65535) + (c & 65535);
        return ((a >>> 16) + (c >>> 16) + (b >>> 16) & 65535) << 16 | b & 65535
    }

    function fa(a, c, b, g) {
        var f = (a & 65535) + (c & 65535) + (b & 65535) + (g & 65535);
        return ((a >>> 16) + (c >>> 16) + (b >>> 16) + (g >>> 16) + (f >>> 16) & 65535) << 16 | f & 65535
    }

    function S(a, c, b, g, f) {
        var h = (a & 65535) + (c & 65535) + (b & 65535) + (g & 65535) + (f & 65535);
        return ((a >>> 16) + (c >>> 16) + (b >>> 16) + (g >>> 16) + (f >>> 16) + (h >>> 16) & 65535) << 16 | h & 65535
    }

    function ga(a, c) {
        var b, g, f;
        b = (a.b & 65535) + (c.b & 65535);
        g = (a.b >>> 16) + (c.b >>> 16) + (b >>> 16);
        f = (g & 65535) << 16 | b & 65535;
        b = (a.a & 65535) + (c.a & 65535) + (g >>> 16);
        g = (a.a >>> 16) + (c.a >>> 16) + (b >>> 16);
        return new s((g & 65535) << 16 | b & 65535, f)
    }

    function ha(a, c, b, g) {
        var f, h, l;
        f = (a.b & 65535) + (c.b & 65535) + (b.b & 65535) + (g.b & 65535);
        h = (a.b >>> 16) + (c.b >>> 16) + (b.b >>> 16) + (g.b >>> 16) + (f >>> 16);
        l = (h & 65535) << 16 | f & 65535;
        f = (a.a & 65535) + (c.a & 65535) + (b.a & 65535) + (g.a & 65535) + (h >>> 16);
        h = (a.a >>> 16) + (c.a >>> 16) + (b.a >>> 16) + (g.a >>> 16) + (f >>> 16);
        return new s((h & 65535) << 16 | f & 65535, l)
    }

    function ia(a, c, b, g, f) {
        var h, l, r;
        h = (a.b & 65535) + (c.b & 65535) + (b.b & 65535) + (g.b & 65535) + (f.b & 65535);
        l = (a.b >>> 16) + (c.b >>> 16) + (b.b >>> 16) + (g.b >>> 16) + (f.b >>> 16) + (h >>> 16);
        r = (l & 65535) << 16 | h & 65535;
        h = (a.a & 65535) + (c.a & 65535) + (b.a & 65535) + (g.a & 65535) + (f.a & 65535) + (l >>> 16);
        l = (a.a >>> 16) + (c.a >>> 16) + (b.a >>> 16) + (g.a >>> 16) + (f.a >>> 16) + (h >>> 16);
        return new s((l & 65535) << 16 | h & 65535, r)
    }

    function y(a, c) {
        var b = [], g, f, h, l, r, s, u = P, t = V, v = Q, d = U, n = R, p, m, w = S, x, q = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
        a[c >>> 5] |= 128 << 24 - c % 32;
        a[(c + 65 >>> 9 << 4) + 15] = c;
        x = a.length;
        for ( p = 0; p < x; p += 16) {
            g = q[0];
            f = q[1];
            h = q[2];
            l = q[3];
            r = q[4];
            for ( m = 0; 80 > m; m += 1)
                b[m] = 16 > m ? a[m + p] : d(b[m - 3] ^ b[m - 8] ^ b[m - 14] ^ b[m - 16], 1), s = 20 > m ? w(d(g, 5), u(f, h, l), r, 1518500249, b[m]) : 40 > m ? w(d(g, 5), t(f, h, l), r, 1859775393, b[m]) : 60 > m ? w(d(g, 5), v(f, h, l), r, 2400959708, b[m]) : w(d(g, 5), t(f, h, l), r, 3395469782, b[m]), r = l, l = h, h = d(f, 30), f = g, g = s;
            q[0] = n(g, q[0]);
            q[1] = n(f, q[1]);
            q[2] = n(h, q[2]);
            q[3] = n(l, q[3]);
            q[4] = n(r, q[4])
        }
        return q
    }

    function v(a, c, b) {
        var g, f, h, l, r, t, u, v, z, d, n, p, m, w, x, q, y, C, D, E, F, G, H, I, e, A = [], B, k = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];
        d = [3238371032, 914150663, 812702999, 4144912697, 4290775857, 1750603025, 1694076839, 3204075428];
        f = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
        if ("SHA-224" === b || "SHA-256" === b)
            n = 64, g = (c + 65 >>> 9 << 4) + 15, w = 16, x = 1, e = Number, q = R, y = fa, C = S, D = ba, E = da, F = Y, G = $, I = Q, H = P, d = "SHA-224" === b ? d : f;
        else if ("SHA-384" === b || "SHA-512" === b)
            n = 80, g = (c + 128 >>> 10 << 5) + 31, w = 32, x = 2, e = s, q = ga, y = ha, C = ia, D = ca, E = ea, F = Z, G = aa, I = X, H = W, k = [new e(k[0], 3609767458), new e(k[1], 602891725), new e(k[2], 3964484399), new e(k[3], 2173295548), new e(k[4], 4081628472), new e(k[5], 3053834265), new e(k[6], 2937671579), new e(k[7], 3664609560), new e(k[8], 2734883394), new e(k[9], 1164996542), new e(k[10], 1323610764), new e(k[11], 3590304994), new e(k[12], 4068182383), new e(k[13], 991336113), new e(k[14], 633803317), new e(k[15], 3479774868), new e(k[16], 2666613458), new e(k[17], 944711139), new e(k[18], 2341262773), new e(k[19], 2007800933), new e(k[20], 1495990901), new e(k[21], 1856431235), new e(k[22], 3175218132), new e(k[23], 2198950837), new e(k[24], 3999719339), new e(k[25], 766784016), new e(k[26], 2566594879), new e(k[27], 3203337956), new e(k[28], 1034457026), new e(k[29], 2466948901), new e(k[30], 3758326383), new e(k[31], 168717936), new e(k[32], 1188179964), new e(k[33], 1546045734), new e(k[34], 1522805485), new e(k[35], 2643833823), new e(k[36], 2343527390), new e(k[37], 1014477480), new e(k[38], 1206759142), new e(k[39], 344077627), new e(k[40], 1290863460), new e(k[41], 3158454273), new e(k[42], 3505952657), new e(k[43], 106217008), new e(k[44], 3606008344), new e(k[45], 1432725776), new e(k[46], 1467031594), new e(k[47], 851169720), new e(k[48], 3100823752), new e(k[49], 1363258195), new e(k[50], 3750685593), new e(k[51], 3785050280), new e(k[52], 3318307427), new e(k[53], 3812723403), new e(k[54], 2003034995), new e(k[55], 3602036899), new e(k[56], 1575990012), new e(k[57], 1125592928), new e(k[58], 2716904306), new e(k[59], 442776044), new e(k[60], 593698344), new e(k[61], 3733110249), new e(k[62], 2999351573), new e(k[63], 3815920427), new e(3391569614, 3928383900), new e(3515267271, 566280711), new e(3940187606, 3454069534), new e(4118630271, 4000239992), new e(116418474, 1914138554), new e(174292421, 2731055270), new e(289380356, 3203993006), new e(460393269, 320620315), new e(685471733, 587496836), new e(852142971, 1086792851), new e(1017036298, 365543100), new e(1126000580, 2618297676), new e(1288033470, 3409855158), new e(1501505948, 4234509866), new e(1607167915, 987167468), new e(1816402316, 1246189591)], d = "SHA-384" === b ? [new e(3418070365, d[0]), new e(1654270250, d[1]), new e(2438529370, d[2]), new e(355462360, d[3]), new e(1731405415, d[4]), new e(41048885895, d[5]), new e(3675008525, d[6]), new e(1203062813, d[7])] : [new e(f[0], 4089235720), new e(f[1], 2227873595), new e(f[2], 4271175723), new e(f[3], 1595750129), new e(f[4], 2917565137), new e(f[5], 725511199), new e(f[6], 4215389547), new e(f[7], 327033209)];
        else
            throw "Unexpected error in SHA-2 implementation";
        a[c >>> 5] |= 128 << 24 - c % 32;
        a[g] = c;
        B = a.length;
        for ( p = 0; p < B; p += w) {
            c = d[0];
            g = d[1];
            f = d[2];
            h = d[3];
            l = d[4];
            r = d[5];
            t = d[6];
            u = d[7];
            for ( m = 0; m < n; m += 1)
                A[m] = 16 > m ? new e(a[m * x + p], a[m * x + p + 1]) : y(E(A[m - 2]), A[m - 7], D(A[m - 15]), A[m - 16]), v = C(u, G(l), H(l, r, t), k[m], A[m]), z = q(F(c), I(c, g, f)), u = t, t = r, r = l, l = q(h, v), h = f, f = g, g = c, c = q(v, z);
            d[0] = q(c, d[0]);
            d[1] = q(g, d[1]);
            d[2] = q(f, d[2]);
            d[3] = q(h, d[3]);
            d[4] = q(l, d[4]);
            d[5] = q(r, d[5]);
            d[6] = q(t, d[6]);
            d[7] = q(u, d[7])
        }
        if ("SHA-224" === b)
            a = [d[0], d[1], d[2], d[3], d[4], d[5], d[6]];
        else if ("SHA-256" === b)
            a = d;
        else if ("SHA-384" === b)
            a = [d[0].a, d[0].b, d[1].a, d[1].b, d[2].a, d[2].b, d[3].a, d[3].b, d[4].a, d[4].b, d[5].a, d[5].b];
        else if ("SHA-512" === b)
            a = [d[0].a, d[0].b, d[1].a, d[1].b, d[2].a, d[2].b, d[3].a, d[3].b, d[4].a, d[4].b, d[5].a, d[5].b, d[6].a, d[6].b, d[7].a, d[7].b];
        else
            throw "Unexpected error in SHA-2 implementation";
        return a
    }


    "function" === typeof define && typeof define.amd ? define(function() {
        return z
    }) : "undefined" !== typeof exports ? "undefined" !== typeof module && module.exports ? module.exports = exports = z : exports = z : T.jsSHA = z
})(this);
