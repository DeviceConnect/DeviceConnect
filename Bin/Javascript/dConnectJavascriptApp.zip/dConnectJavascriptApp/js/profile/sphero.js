/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
/** 
 * Sphero Menu
 *
 * @param deviceId デバイスID
 */
function showSphero(deviceId) {
    initAll();
    setTitle("Sphero Profile(Event)");
	

    var str = "";
    var path = "/";
    str += '<li><a href="javascript:showOnQuaternion(\'' + deviceId + '\');" value="list">onQuaternion</a></li>';
    str += '<li><a href="javascript:showOnLocator(\'' + deviceId + '\');" value="send">onLocator</a></li>';
	str += '<li><a href="javascript:showOnCollision(\'' + deviceId + '\');" value="send">onCollision</a></li>';
    reloadList(str);

    reloadContent(getProfileListLink(deviceId));
}


/**
 * Quaternionの表示
 *
 * @param deviceId デバイスID
 */
function showOnQuaternion(deviceId){
	initAll();
	
    var webSocketName = "spheroOnQuaternion";
	var str = "";
    str += '<input type="button" onclick="doRegisterQuaternion(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Register Event" >';
    str += '<form  name="spheroForm">';
    str += 'Quaternion<br>';
    str += makeInputText("Q0", "q0", "q0");
    str += makeInputText("Q1", "q1", "q1");
    str += makeInputText("Q2", "q2", "q2");
    str += makeInputText("Q3", "q3", "q3");
    str += makeInputText("Interval", "interval", "interval");
    str += '</form>';
    str += '<input type="button" onclick="doUnregisterQuaternion(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Unregister Event">';
    
    str += spheroTopButton(deviceId);
    
	reloadContent(str);
}

/**
 * Locatorの表示
 *
 * @param deviceId デバイスID
 */
function showOnLocator(deviceId){
	initAll();
	
    var webSocketName = "spheroOnLocatorSocket";
	var str = "";
    str += '<input type="button" onclick="doRegisterLocator(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Register Event" >';
    str += '<form  name="spheroForm">';
    str += 'Locator<br>';
    str += makeInputText("PosX", "posx", "posx");
    str += makeInputText("PosY", "posy", "posy");
    str += makeInputText("VerX", "verx", "verx");
    str += makeInputText("VerY", "very", "very");
    str += '</form>';
    str += '<input type="button" onclick="doUnregisterLocator(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Unregister Event">';
    
    str += spheroTopButton(deviceId);
    
	reloadContent(str);
}

/**
 * Collisionの表示
 *
 * @param deviceId デバイスID
 */
function showOnCollision(deviceId){
	initAll();
	
    var webSocketName = "spheroOnCollision";
	var str = "";
    str += '<input type="button" onclick="doRegisterCollision(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Register Event" >';
    str += '<form  name="spheroForm">';
    str += 'Collision<br>';
	str += makeInputText("Timestamp", "time", "time");
	str += makeInputText("Speed", "speed", "speed");
    str += makeInputText("Power:X", "px", "px");
    str += makeInputText("Power:Y", "py", "py");
    str += makeInputText("Acceleration:X", "acx", "acx");
    str += makeInputText("Acceleration:Y", "acy", "acy");
    str += makeInputText("Acceleration:Z", "acz", "acz");
    str += makeInputText("Axis:X", "axx", "axx");
    str += makeInputText("Axis:Y", "axy", "axy");
    str += '</form>';
    str += '<input type="button" onclick="doUnregisterCollision(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Unregister Event">';
    
    str += spheroTopButton(deviceId);
    
	reloadContent(str);
}

/**
 * Quaternionイベントの登録
 *
 * @param deviceId デバイスID
 */
function doRegisterQuaternion(deviceId, sessionKey) {
 
    var builder = new dConnect.URIBuilder();
    builder.setProfile("sphero");
    builder.setInterface("quaternion");
    builder.setAttribute("onquaternion");    
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    console.log(uri);

    dConnect.addEventListener(uri, function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        var json = JSON.parse(message);
		console.log(message);
		 if (json.quaternion) {
			document.spheroForm.q0.value = json.quaternion.q0;
			document.spheroForm.q1.value = json.quaternion.q1;
			document.spheroForm.q2.value = json.quaternion.q2;
			document.spheroForm.q3.value = json.quaternion.q3;
			document.spheroForm.interval.value = json.quaternion.interval;
           
        }

    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
}

/**
 * Dice ondiceイベントの削除
 *
 * @param deviceId デバイスID
 */
function doUnregisterQuaternion(deviceId, sessionKey) {
	
    var builder = new dConnect.URIBuilder();
    builder.setProfile("sphero");
    builder.setInterface("quaternion");
    builder.setAttribute("onquaternion");    
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    
    if(DEBUG) console.log("Uri:"+uri)

    dConnect.removeEventListener(uri);
}    

/**
 * Locatorイベントの登録
 *
 * @param deviceId デバイスID
 */
function doRegisterLocator(deviceId, sessionKey) {
 
    var builder = new dConnect.URIBuilder();
    builder.setProfile("sphero");
    builder.setInterface("locator");
    builder.setAttribute("onlocator");    
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    
    if(DEBUG) console.log("Uri:"+uri)

    dConnect.addEventListener(uri, function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
		console.log(message);
		 if (json.locator) {
			document.spheroForm.posx.value = json.locator.positionX;
			document.spheroForm.posy.value = json.locator.positionY;
			document.spheroForm.verx.value = json.locator.verocityX;
			document.spheroForm.very.value = json.locator.verocityY;
           
        }

    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
}

/**
 * Dice ondiceイベントの削除
 *
 * @param deviceId デバイスID
 */
function doUnregisterLocator(deviceId, sessionKey) {
	
    var builder = new dConnect.URIBuilder();
    builder.setProfile("sphero");
    builder.setInterface("locator");
    builder.setAttribute("onlocator");      
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    
    if(DEBUG) console.log("Uri:"+uri)

    dConnect.removeEventListener(uri);
}    


/**
 * Locatorイベントの登録
 *
 * @param deviceId デバイスID
 */
function doRegisterCollision(deviceId, sessionKey) {
 
    var builder = new dConnect.URIBuilder();
    builder.setProfile("sphero");
    builder.setInterface("collision");
    builder.setAttribute("oncollision");    
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    
    if(DEBUG) console.log("Uri:"+uri)

    dConnect.addEventListener(uri, function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
		console.log(message);
		 if (json.collision) {
			document.spheroForm.time.value = json.collision.impactTimestamp;
			document.spheroForm.speed.value = json.collision.impactSpeed;
			document.spheroForm.px.value = json.collision.impactPower.x;
			document.spheroForm.py.value = json.collision.impactPower.y;
			document.spheroForm.acx.value = json.collision.impactAcceleration.x;
			document.spheroForm.acy.value = json.collision.impactAcceleration.y;
			document.spheroForm.acz.value = json.collision.impactAcceleration.z;
			document.spheroForm.axx.value = json.collision.impactAxis.y;
			document.spheroForm.axy.value = json.collision.impactAxis.x;
           
        }

    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
}

/**
 * Dice ondiceイベントの削除
 *
 * @param deviceId デバイスID
 */
function doUnregisterCollision(deviceId, sessionKey) {
	
    var builder = new dConnect.URIBuilder();
    builder.setProfile("sphero");
    builder.setInterface("collision");
    builder.setAttribute("oncollision");      
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();

	if(DEBUG) console.log("Uri:"+uri)

    dConnect.removeEventListener(uri);
}    




/**
 * Diceのメニューに戻るボタン.
 *
 * @param deviceId デバイスID
 */
function spheroTopButton(deviceId)
{
    var str = "";
    str += '<center>';
    str += '<input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showSphero(\'' + deviceId + '\');" type="button" value="Sphero Top"/>';
    str += '</center>';

    return str;

}