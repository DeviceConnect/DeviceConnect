/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
/** 
 * DeviceOrientation
 */
function showDeviceOrientation(deviceId) {
    initAll();
    
    setTitle("DeviceOrientation Profile(Event)");

    var webSocketName = "deviceOrientationSocket";
	var str = "";
	
    str += '<input type="button" onclick="doDeviceOrientationRegist(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Register Event" >';
    str += '<form  name="deviceOrientationForm">';
    str += 'Accelerometer<br>';
    str += '<input type="text" id="accelX" width="100%">';
    str += '<input type="text" id="accelY" width="100%">';
    str += '<input type="text" id="accelZ" width="100%">';
    str += 'Accelerometer(Gravity)<br>';
    str += '<input type="text" id="accelXG" width="100%">';
    str += '<input type="text" id="accelYG" width="100%">';
    str += '<input type="text" id="accelZG" width="100%">';
    str += 'Rotation<br>';
    str += '<input type="text" id="rotationBeta" width="100%">';
    str += '<input type="text" id="rotationAlpha" width="100%">';
    str += '<input type="text" id="rotationGamma" width="100%">';
    str += 'Interval<br>';
    str += '<input type="text" id="interval" width="100%">';
    str += '</form>';
    str += '<input type="button" onclick="doDeviceOrientationUnregister(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Unregister Event">';
    
    str += getProfileListLink(deviceId);

	reloadContent(str);
	

}


/**
 * DeviceOrientation
 */
function doDeviceOrientationRegist(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("deviceorientation");
    builder.setAttribute("ondeviceorientation");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
        if (json.orientation) {
	
            if (json.orientation.acceleration) {
                document.deviceOrientationForm.accelX.value = json.orientation.acceleration.x;
                document.deviceOrientationForm.accelY.value = json.orientation.acceleration.y;
                document.deviceOrientationForm.accelZ.value = json.orientation.acceleration.z;
            }

            if (json.orientation.accelerationIncludingGravity) {
                document.deviceOrientationForm.accelXG.value = json.orientation.accelerationIncludingGravity.x;
                document.deviceOrientationForm.accelYG.value = json.orientation.accelerationIncludingGravity.y;
                document.deviceOrientationForm.accelZG.value = json.orientation.accelerationIncludingGravity.z;
            }

            if (json.orientation.rotationRate) {
                document.deviceOrientationForm.rotationBeta.value = json.orientation.rotationRate.beta;
                document.deviceOrientationForm.rotationGamma.value = json.orientation.rotationRate.gamma;
                document.deviceOrientationForm.rotationAlpha.value = json.orientation.rotationRate.alpha;
            }

            if (json.orientation.interval) {
                var intervalStr = "interval ";
                intervalStr += "time: " + json.orientation.interval;
                document.deviceOrientationForm.interval.value = intervalStr;
            }
        }
    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});

}

/**
 * DeviceOrientation
 */
function doDeviceOrientationUnregister(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("deviceorientation");
    builder.setAttribute("ondeviceorientation");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}
