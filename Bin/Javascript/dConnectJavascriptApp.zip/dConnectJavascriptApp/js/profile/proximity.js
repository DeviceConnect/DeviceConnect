/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
/** 
 * Proximityの処理
 *
 * @param deviceId デバイスID
 */
function showProximity(deviceId) {
    initListView();
    setTitle("Proximity");

    var sessionKey = "proximitySocket";
	
	var str = "";
	str += 'device proximity<br>';
    str += '<input type="button" onclick="doRegisterDeviceProximity(\'' + deviceId + '\', \'' + sessionKey + '\');" value="Register Event" >';
    str += '<form  name="deviceProximityForm">';
    str += '<input type="text" id="value" width="100%">';
	str += '<input type="text" id="min" width="100%">';
    str += '<input type="text" id="max" width="100%">';
    str += '<input type="text" id="threshold" width="100%">';
    str += '</form>';
    str += '<input type="button" onclick="doUnregisterDeviceProximity(\'' + deviceId + '\', \'' + sessionKey + '\');" value="Unregister Event">';
    str += '<hr>';
    
    str += 'user proximity<br>';
    str += '<input type="button" onclick="doRegisterUserProximity(\'' + deviceId + '\', \'' + sessionKey + '\');" value="Register Event" >';
    str += '<form  name="userProximityForm">';
    str += '<input type="text" id="user" width="100%">';
    str += '</form>';
    str += '<input type="button" onclick="doUnregisterUserProximity(\'' + deviceId + '\', \'' + sessionKey + '\');" value="Unregister Event">';
    str += getProfileListLink(deviceId);


    $('#contents').html(str).trigger('create');
}


/**
 * Device Proximityイベントの登録
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doRegisterDeviceProximity(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
	builder.setProfile("proximity");
    builder.setAttribute("ondeviceproximity");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
        if (json.proximity) {
			document.deviceProximityForm.value.value = json.proximity.value;
			document.deviceProximityForm.min.value = json.proximity.min;
			document.deviceProximityForm.max.value = json.proximity.max;
			document.deviceProximityForm.threshold.value = json.proximity.threshold;
        }
    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});

}

/**
 * Device Proximityイベントの削除
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doUnregisterDeviceProximity(deviceId, sessionKey) {
   var builder = new dConnect.URIBuilder();
    builder.setProfile("proximity");
    builder.setAttribute("ondeviceproximity");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}

/**
 * Device Proximityイベントの登録
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doRegisterUserProximity(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("proximity");
    builder.setAttribute("onuserproximity");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Response:"+message)
        
        var json = JSON.parse(message);
        if (json.proximity) {
			document.userProximityForm.user.value = json.proximity.near;
        }
    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});

}

/**
 * Device Proximityイベントの削除
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doUnregisterUserProximity(deviceId, sessionKey) {
   var builder = new dConnect.URIBuilder();
    builder.setProfile("proximity");
    builder.setAttribute("onuserproximity");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}
