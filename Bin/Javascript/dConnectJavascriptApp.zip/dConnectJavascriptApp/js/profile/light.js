/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * light profile
 */
function showSearchLight(deviceId) {
    initAll();
	closeLoading();
    showLoading();

    var builder = new dConnect.URIBuilder();
    builder.setProfile("light");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    setTitle("Light List");

    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		console.log(responseText);
        if (json.result == 0) {
            var str = "";
            for (var i = 0; i < json.lights.length; i++) {
            
            	var lightName = json.lights[i].name;
            	if(lightName == "Dice+ 1"){
            		lightName = "Dice+ [1]"
            	} else if(lightName == "Dice+ 2"){
            		lightName = "Dice+ [2]"
            	} else if(lightName == "Dice+ 4"){
            		lightName = "Dice+ [3]"
            	} else if(lightName == "Dice+ 8"){
            		lightName = "Dice+ [4]"
            	} else if(lightName == "Dice+ 16"){
            		lightName = "Dice+ [5]"
            	} else if(lightName == "Dice+ 32"){
            		lightName = "Dice+ [6]"
            	} else if(lightName == "Dice+ -1"){
            		lightName = "Dice+ [All]"
            	} 
            
                str += '<li><a href="javascript:showLight(\'' + deviceId + '\', \'' + json.lights[i].lightId + '\', \'' + json.lights[i].name + '\');" value="' + json.lights[i].name + '">' + lightName + '</a></li>';
            }
			
			reloadList(str);
            
            
            reloadContent(getProfileListLink(deviceId));
            closeLoading();

        } else {
            
            alert("could not found any light"); 
            var str = "";
            
        
            reloadContent(str);
            closeLoading();
        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

/** 
 * Light pfoile
 */
function showLight(deviceId, lightId, lightName) {
    
    initAll();
    
    
    setTitle("Light Profile(Light)");
	
    var str = "";
    if(lightName == "Sphero CalibrationLED"){
    	str += '<input type="hidden" id="red" value="255" min="0" max="255"  />';
    	str += '<input type="hidden" id="green" value="255" min="0" max="255"  />';
    	str += '<input type="hidden" id="blue" value="255" min="0" max="255"  />';
    	str += '<input type="button" onclick="javascript:doLight(\'' + deviceId + '\',\'' + lightId + '\', 1);" value="on" name="On" id="On"/>';
    	str += '<input type="button" onclick="javascript:doLight(\'' + deviceId + '\',\'' + lightId + '\', 0);" value="off" name="Off" id="off"/>';
    	str += '<center><input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showSearchLight(\'' + deviceId + '\');" type="button" value="Light TOP"/></center>';
    } else{
	    str += '<label for="slider-0">Red:</label>';
   		str += '<input type="range" name="slider" id="red" value="25" min="0" max="255"  />';
    	str += '<label for="slider-0">Green:</label>';
    	str += '<input type="range" name="slider" id="green" value="25" min="0" max="255"  />';
    	str += '<label for="slider-0">Blue:</label>';
    	str += '<input type="range" name="slider" id="blue" value="25" min="0" max="255"  />';
    	str += '<input type="button" onclick="javascript:doLight(\'' + deviceId + '\',\'' + lightId + '\', 1);" value="on" name="On" id="On"/>';
    	str += '<input type="button" onclick="javascript:doLight(\'' + deviceId + '\',\'' + lightId + '\', 0);" value="off" name="Off" id="off"/>';
    	str += '<center><input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showSearchLight(\'' + deviceId + '\');" type="button" value="Light TOP"/></center>';
	}
	
	reloadContent(str);
}

/** 
 * Light pfoile
 */
function doLight(deviceId, lightId, value) {
    if (value == "1") {
        var red = document.getElementById('red').value;
        var green = document.getElementById('green').value;
        var blue = document.getElementById('blue').value;
        
       
        red = parseInt(red);
        green = parseInt(green);
        blue = parseInt(blue);
        
        red = zeroPadding(red.toString(16));
        green = zeroPadding(green.toString(16));
        blue = zeroPadding(blue.toString(16));
        
        var col = red + green + blue;
        //alert(col);

        var builder = new dConnect.URIBuilder();
        builder.setProfile("light");
        builder.setDeviceId(deviceId);
        builder.setAccessToken(accessToken);
        builder.addParameter("color", col);
        builder.addParameter("lightId", lightId);
        var uri = builder.build();
		
		if(DEBUG) console.log("Uri:"+uri)
		
        dConnect.execute('POST', uri, null, null, function(status, headerMap, responseText) {
            
            if(DEBUG) console.log("Response:"+responseText)
            
            var json = JSON.parse(responseText);
            
            var str = "";
          
            if (json.result == 0) {

            } else {

            }

        });
    } else {

        var builder = new dConnect.URIBuilder();
        builder.setProfile("light");
        builder.setDeviceId(deviceId);
        builder.setAccessToken(accessToken);
        builder.addParameter("lightId", lightId);
        var uri = builder.build();
		
		if(DEBUG) console.log("Uri:"+uri)
		
        dConnect.execute('DELETE', uri, null, null, function(status, headerMap, responseText) {
            
            if(DEBUG) console.log("Response:"+responseText)
            
            var json = JSON.parse(responseText);
        
            var str = "";

            if (json.result == 0) {

            } else {

            }

        });
    }
    
    /**
     * 1桁の場合は、0を先頭につける
     *
     * @param value 
     */
	function zeroPadding(value){
		if(value.length == 1){ 
			return "0" + value;
		} else {
			return value;
		}
		
	}
    
}