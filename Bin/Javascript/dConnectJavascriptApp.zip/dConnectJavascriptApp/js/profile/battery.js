/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

/**
 Battery Profile
 */
 
/**
  Show Battery
 */
function showBattery(deviceId) {

   	initAll();
    setTitle("Battery Profile");

    var str = "";
    str += '<li><a href="javascript:doBatteryAll(\'' + deviceId + '\');">Show battery info</a></li>';
    str += '<li><a href="javascript:doBatterEvent(\'' + deviceId + '\');" >Battery Event(onbatterychange)</a></li>';
    str += '<li><a href="javascript:doChargeEvent(\'' + deviceId + '\');" >Battery Event(onchargingchange)</a></li>';


    reloadList(str);

    reloadContent(getProfileListLink(deviceId));
}


/**
 * BatteryEvent
 *
 * @param deviceId デバイスID
 */
function doChargeEvent(deviceId){
	 initAll();
    
    setTitle("Battery Event");

    var webSocketName = "deviceOrientationSocket";
	var str = "";
    str += '<input type="button" onclick="doRegisterChargingEvent(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Register Event" >';
    str += '<form  name="batteryForm">';
    str += 'Battery<br>';
    str += makeInputText("charging", "charging", "charging"); 
    str += '</form>';
    str += '<input type="button" onclick="doUnregisterChargingEvent(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Unregister Event">';
    
	str += showBatteryButton(deviceId);
	
	reloadContent(str);
}



/**
 * Battery Event
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doRegisterChargingEvent(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("battery");
    builder.setAttribute("onchargingchange");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
    
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
       	if(json.battery){
       		document.batteryForm.charging.value = json.battery.charging;
       	}
    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});

}

/**
 * Battery Event削除
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doUnregisterChargingEvent(deviceId, sessionKey) {
	var builder = new dConnect.URIBuilder();
    builder.setProfile("battery");
    builder.setAttribute("onchargingchange");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
    if(DEBUG) console.log("Uri:"+uri)
    
    dConnect.removeEventListener(uri);
    
}

/**
 * BatteryEvent
 *
 * @param deviceId デバイスID
 */
function doBatterEvent(deviceId){
	 initAll();
    
    setTitle("Battery Event");

    var webSocketName = "deviceonchargingchangeSocket";
	var str = "";
    str += '<input type="button" onclick="doRegisterBatteryEvent(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Register Event" >';
    str += '<form  name="batteryForm">';
    str += 'Battery<br>';
    str += makeInputText("chargingTime", "chargingTime", "chargingTime"); 
    str += makeInputText("dischargintTime", "dischargintTime", "dischargintTime");
    str += makeInputText("level", "level", "level");
    str += '</form>';
    str += '<input type="button" onclick="doUnregisterBatteryEvent(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Unregister Event">';
    
    str += showBatteryButton(deviceId);

	reloadContent(str);
}




/**
 * Battery Event
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doRegisterBatteryEvent(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("battery");
    builder.setAttribute("onbatterychange");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
       	if(json.battery){
       		document.batteryForm.chargingTime.value = json.battery.chargingTime;
       		document.batteryForm.dischargintTime.value = json.battery.dischargintTime;
       		document.batteryForm.level.value = json.battery.level;
       	}
    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});

}

/**
 * Battery Event削除
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doUnregisterBatteryEvent(deviceId, sessionKey) {
	var builder = new dConnect.URIBuilder();
    builder.setProfile("battery");
    builder.setAttribute("onbatterychange");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
    if(DEBUG) console.log("Uri:"+uri)
    
    dConnect.removeEventListener(uri);
    
}

/**
 * Battery Profile
 */
function doBatteryAll(deviceId) {

	initAll();
    setTitle("Battery Info");
	
	var builder = new dConnect.URIBuilder();
    builder.setProfile("battery");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
    if(DEBUG) console.log("Uri:"+uri)
    
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		
		if(DEBUG) console.log("Response:"+responseText)
		
        if (json.result == 0) {
        	var level = json.level * 100;
            var str = "";
            str += '<label for="slider-0">LEVEL:</label>';
            str += '<input type="range" name="slider" id="volume" value="' + level + '" min="0" max="100"  />';


            if (json.charging) {
                str += 'Status: Charging"';
            } else {
                str += 'Status: Not charging';
            }
            str += showBatteryButton(deviceId);
            
            $('#contents').html(str).trigger('create');

           
        } else {
           
        }
       
    }, function(xhr, textStatus, errorThrown) {
        
    });
}

/**
 * Batteryのメニューに戻るボタン.
 *
 * @param deviceId デバイスID
 */
function showBatteryButton(deviceId)
{
    var str = "";
    str += '<center>';
    str += '<input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showBattery(\'' + deviceId + '\');" type="button" value="Battery Top"/>';
    str += '</center>';

    return str;

}
