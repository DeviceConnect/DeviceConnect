/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
 
/**
 * MediastreamRecording Menu
 *
 * @param deviceId デバイスId
 */
function showMediastreamRecording(deviceId) {
    
    initAll();
    
    
	
	if(myDeviceName.indexOf("Sony Camera") != -1){
		setTitle("MediastreamRecording (Sony Camera)");
	    var str = "";
    	str += '<li><a href="javascript:doPreviewStart(\'' + deviceId + '\');">Preview</a></li>';
    	str += '<li><a href="javascript:doTakePhoto(\'' + deviceId + '\');">Take Photo</a></li>';
    	str += '<center><img src="./css/images/waitCamera.png"></center>';
	} else {
		setTitle("MediastreamRecording");
		var str = "";
    	str += '<li><a href="javascript:doPreviewStart(\'' + deviceId + '\');">Preview</a></li>';
    	str += '<li><a href="javascript:doTakePhoto(\'' + deviceId + '\');">Take Photo</a></li>';
    	str += '<li><a href="javascript:doMediaRecord(\'' + deviceId + '\',\'video\');">Record Video</a></li>';
    	str += '<li><a href="javascript:doMediaRecord(\'' + deviceId + '\',\'audio\');">Record Audio</a></li>';
    	str += '<li></li>';
    	str += '<li><a href="javascript:doGetMediaRecorder(\'' + deviceId + '\');">MediaRecorder List</a></li>';
    	str += '<li></li>';
    	str += '<li><a href="javascript:doMediaRecord(\'' + deviceId + '\',document.getElementById(\'target\').value.toString());">Record With Target</a></li>';
    	str += '<li><input type="text" id="target" placeholder="target"></li>';
		str += '<center><img src="./css/images/waitCamera.png"></center>';
	}
    reloadList(str);

    var str = '<center><input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:searchSystem(\'' + deviceId + '\');" type="button" value="Device TOP"/></center>';
    reloadContent(str); 
}

var isPreview = false;

/**
 * onDataAvailable
 */
function doRegisterOnDataAvailable(deviceId, sessionKey) {

    initAll();
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("ondataavailable");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	isPreview = true;
    dConnect.addEventListener(uri, function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
        json.media.uri = json.media.uri.replace("localhost", ip);
        console.log("ip=" + json.media.uri);
        if(isPreview){
	        refreshImg(json.media.uri, "preview");
	    }
    });

    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});

    setTitle("takephoto preview");
    var str = '<center>';
    str += '<img src="./css/images/cameraWait.png" width="100%" id="preview">';
    str += '</center><br>';
    str +=  previewStopButton(deviceId, sessionKey);
	

    $('#result').html(str).trigger('create');

}

/**
 * onDataAvailable
 */
function doUnregisterOnDataAvailable(deviceId, sessionKey) {
    isPreview = false;
    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("ondataavailable");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
    //dConnect.disconnectWebSocket();
}


/**
 * MediaPlayer stop
 */
function doPreviewStop(deviceId, sessionKey) {

    doUnregisterOnDataAvailable(deviceId, sessionKey);
    showMediastreamRecording(deviceId);

}

/**
 * Start preview
 *
 * @param deviceId デバイスId
 */
function doPreviewStart(deviceId) {
    //var mDate = new Date();
    //var webSocketName = mDate.getTime();
    loadFlag = false;
    sessionKey = "previewSocket";

    doRegisterOnDataAvailable(deviceId, sessionKey);

    initListView();
}

/**
 * Take Photo
 *
 * @param deviceId デバイスID
 */
function doTakePhoto(deviceId) {
    
    
    
    initAll();
    
    showLoading();
    loadFlag = false;
	var sessionKey = "onPhotoSession";
	
    var str = "";
    str += '<input data-icon="onPhoto" onclick="javascript:doRegisterOnPhoto(\'' + deviceId + '\',\'' + sessionKey + '\');" type="button" value="Register onPhotoEvent"/>';
	str += '<input data-icon="onPhoto" onclick="javascript:doUnregisterOnPhoto(\'' + deviceId + '\',\'' + sessionKey + '\');" type="button" value="Unregister onPhotoEvent"/>';

    
    str += makeInputText("onPhoto", "onPhoto", "onPhoto")
    str += '<img src="./css/images/cameraWait.png" width="100%" id="photo">';
    str += '</center><br>';
    str += takePhotoButton(deviceId);
    str += mediastreamTopButton(deviceId);
    
    reloadContent(str);    
    
    
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("takephoto");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
   	
   	if(DEBUG) console.log("Uri:"+uri)
   	
	//refreshImg("./css/images/cameraWait.png", "photo");
	
    dConnect.execute('POST', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);
	    
        if (json.result == 0) {
            var myUri = json.uri;
            myUri  = myUri.replace("localhost", ip);
            refreshImg(myUri, "photo");
            closeLoading();
           
        } else {
            alert("Take Photo API failed!\n\nURI: "+uri+"\nerrorCode: " + json.errorCode + "\nerrorMessage: " + json.errorMessage + ")");
        }

    }, function(xhr, textStatus, errorThrown) {

    });
    

}


/**
 * 画像のリフレッシュ
 *
 * @param uri 画像のURI
 */
function refreshImg(uri, id) {
    if (!loadFlag) {
        loadFlag = true;
        var img = document.getElementById(id);
        if(img != null){
            img.src = uri;
            img.onload = function() {
                loadFlag = false;
            }
        }
    }
}


function doMediaRecord(deviceId, target) {
    initAll();
    
    setTitle("Recording, now");

    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("record");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("target", target);
    var uri = builder.build();
    
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('POST', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)

        var json = JSON.parse(responseText);
	    
        if (json.result == 0) {
            reloadContent(mediaStopButton(deviceId));
        } else {
            alert("Record API failed!\n\nURI: "+uri+"\nerrorCode: " + json.errorCode + "\nerrorMessage: " + json.errorMessage + ")");
        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

function doMediaStop(deviceId) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("stop");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
        
		if(DEBUG) console.log("Response:"+responseText)
	    
        if (json.result == 0) {

            showMediastreamRecording(deviceId);
        } else {
            alert("Stop API failed!\n\nURI: "+uri+"\nerrorCode: " + json.errorCode + "\nerrorMessage: " + json.errorMessage + ")");
        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

function doGetMediaRecorder(deviceId) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("mediarecorder");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
        var json = JSON.parse(responseText);
		
		if(DEBUG) console.log("Response:"+responseText)
		
        if (json.result == 0) {
            // TODO: もっとましな表示方法は無いの？
            console.log(json);
        } else {
            alert("MediaRecorder API failed!\n\nURI: "+uri+"\nerrorCode: " + json.errorCode + "\nerrorMessage: " + json.errorMessage + ")");
        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

/**
 * メディアの停止
 *
 * @param deviceId デバイスID
 */
function mediaStopButton(deviceId){
    var str = "";
    str += '<center>';
    str += '<input data-icon="stop"  ';
    str += 'onclick="javascript:doMediaStop(\'' + deviceId + '\');" type="button" value="Stop"/>';
    str += '</center>';
    return str;
}

/**
 * メディアの停止
 *
 * @param deviceId デバイスID
 */
function previewStopButton(deviceId, sessionKey){
    var str = "";
    str += '<center>';
    str += '<input data-icon="stop"  ';
    str += 'onclick="javascript:doPreviewStop(\'' + deviceId + '\', \'' + sessionKey + '\');" type="button" value="Stop"/>';
    str += '</center>';
    return str;
}

/**
 * メディアの停止
 *
 * @param deviceId デバイスID
 */
function mediastreamTopButton(deviceId){
    var str = "";
    str += '<center>';
    str += '<input data-icon="stop"  ';
    str += 'onclick="javascript:showMediastreamRecording(\'' + deviceId + '\');" type="button" value="back"/>';
    str += '</center>';
    return str;
}

/**
 * 写真の撮影
 *
 * @param deviceId デバイスID
 */
function takePhotoButton(deviceId){
    var str = "";
    str += '<center>';
    str += '<input data-icon="stop"  ';
    str += 'onclick="javascript:doTakePhoto(\'' + deviceId + '\');" type="button" value="takePhoto"/>';
    str += '</center>';
    return str;
}


/**
 * onPhotoイベントの登録
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doRegisterOnPhoto(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("onphoto");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
     
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
       	$("#onPhoto").val(json.path);
        //document.notificationForm.show.value = json.notificationId;
                
    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
}

/**
 * onPhotoイベントの解除
 *
 * @param deviceId デバイスID
 * @param sessionKey セッションキー
 */
function doUnregisterOnPhoto(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("mediastream_recording");
    builder.setAttribute("onphoto");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}
