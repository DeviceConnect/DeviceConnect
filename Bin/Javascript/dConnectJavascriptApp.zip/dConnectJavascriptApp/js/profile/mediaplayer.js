/**
 mediaplayer.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

/** 
 * media_player のメニュー
 *
 * @param {String}deviceId デバイスID
 */
function showMediaPlayer(deviceId) {

  	initAll();
	
	var btnStr = "";    
    btnStr += getBackButton('Device Top','doMediaplayerBack', deviceId, "");
	reloadHeader(btnStr);
	reloadFooter(btnStr);
	
    setTitle("MediaPlayer Profile");

    var listHtml = "";
    listHtml += '<li><a href="javascript:doMediaList(\'' + deviceId + '\');" value="MediaList">MediaList</a></li>';

    reloadList(listHtml);
}

/**
 * Backボタン
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションKEY
 */
function doMediaplayerBack(deviceId, sessionKey){
	searchSystem(deviceId);
}

/**
 * Media List
 *
 * @param {String}deviceId デバイスID
 */
function doMediaList(deviceId) {
	
	initAll();
    
    closeLoading();
    showLoading();
    
    setTitle("MediaPlayer Media List");
    
	var str = getBackButton('MediaPlayer TOP', 'doMediaListBack', deviceId, "");
    reloadContent(str);
	reloadHeader(str);
			
    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("media_list");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
    	if(DEBUG) console.log("Response:"+responseText)
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	
        	closeLoading();
            var str = "";

            for (var i = 0; i < json.media.length; i++) {
                str += '<li><a href="javascript:doMediaPlayer(\'' + deviceId + '\',\'' + json.media[i].mediaId + '\',1);"  >';
                str += json.media[i].title + '</a></li>';
            }

          	
			reloadList(str);


        } else {
       		 closeLoading();
			showError("media_player/media_list", json);
        }

    }, function(xhr, textStatus, errorThrown) {});
}

/**
 * Backボタン
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションKEY
 */
function doMediaListBack(deviceId, sessionKey){
	showMediaPlayer(deviceId);
}

/**
 * Backボタン
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションKEY
 */
function doMediaPlayerToFileBack(deviceId, sessionKey){
	showFileList(deviceId, currentPath, 1);
}

/**
 * Backボタン
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションKEY
 */
function doMediaPlayerBack(deviceId, sessionKey){
	doUnregisterOnStatusChange(deviceId, sessionKey);
	doMediaList(deviceId);
}

/**
 * MusicPlayer onStatus Eventの登録
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションKEY
 */
function doRegisterOnStatusChange(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("onstatuschange");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri, function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
        console.log(message);
        if (json.mediaPlayer) {
            document.mediaPlayerForm.status.value = json.mediaPlayer.status;
            document.mediaPlayerForm.mediaId.value = json.mediaPlayer.mediaId;
            document.mediaPlayerForm.volume.value = json.mediaPlayer.volume;
            document.mediaPlayerForm.mimeType.value = json.mediaPlayer.mimeType;
        }
    }, function(error){
    	var json = JSON.parse(error);
    	showError("PUT media_player/onstatuschange", json);
    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
}



/**
 * MusicPlayer onStatus Eventの削除
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションKEY
 */
function doUnregisterOnStatusChange(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
     builder.setProfile("media_player");
    builder.setAttribute("onstatuschange");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("******Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}

/**
 * MediaPlayer
 *
 * @param {String}deviceId デバイスID
 * @param {String}id メディアID
 * @param {String}from FileListから実行か, MediaListからの実行か
 */
function doMediaPlayer(deviceId, id, from) {
	initAll();
	
    var sessionKey = "mediaplayerSession";
	doRegisterOnStatusChange(deviceId, sessionKey);
   	
   	// back button to media player list
	if(from == 1){
		var btnStr = "";    
    	btnStr += getBackButton('Media List','doMediaPlayerBack', deviceId, sessionKey);
		reloadHeader(btnStr);
		reloadFooter(btnStr);
	} else if(from == 2){
		var btnStr = "";    
    	btnStr += getBackButton('File Manager','doMediaPlayerToFileBack', deviceId, sessionKey);
		reloadHeader(btnStr);
		reloadFooter(btnStr);
	}
	
   	var str = "";
    str += '<form  name="mediaPlayerForm">';
    str += '<input type="text" id="mediaId" width="100%">';
    str += '<input type="text" id="mimeType" width="100%">';
    str += '<input type="text" id="volume" width="100%">';
    str += '<input type="text" id="status" width="100%">';
    str += '</form>';


    str += '<input type="text" value="' + id + '"/>';
    str += '<input data-icon="play" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerPlay(\'' + deviceId + '\');" type="button" value="Play"/>';
    str += '<input data-icon="pause" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerPause(\'' + deviceId + '\');" type="button" value="Pause"/>';
    str += '<input data-icon="stop" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerStop(\'' + deviceId + '\');" type="button" value="Stop"/>';
    str += '</center>';

	
	
	reloadContent(str);
	
    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("media");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("mediaId", id);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
       
       if(DEBUG) console.log("Response:"+responseText)
       
       var json = JSON.parse(responseText);

        if (json.result == 0) {
            setTitle("MediaPlayer");


            initListView();
			
		

        } else {
			showError("PUT media_player/media", json);
        }

    }, function(xhr, textStatus, errorThrown) {

    });

}

/**
 * MediaPlayer play
 *
 * @param {String}deviceId デバイスID
 */
function doMediaPlayerPlay(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("play");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {
			showError("PUT media_player/play", json);
        }

    }, function(xhr, textStatus, errorThrown) {

    });
}




/**
 * MediaPlayer stop
 *
 * @param {String}deviceId デバイスID
 */
function doMediaPlayerStop(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("stop");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {
			showError("PUT media_player/stop", json);
        }

    }, function(xhr, textStatus, errorThrown) {

    });
}


/**
 * MediaPlayer pause
 *
 * @param {String}deviceId デバイスID
 */
function doMediaPlayerPause(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("pause");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {
			showError("PUT media_player/pause", json);
        }

    }, function(xhr, textStatus, errorThrown) {

    });
}
