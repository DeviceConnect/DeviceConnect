/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

/** 
 * media_player のメニュー
 *
 * @param deviceId デバイスID
 */
function showMediaPlayer(deviceId) {

    initContent();
    initResult();

    setTitle("MediaPlayer Profile");

    var listHtml = "";
    listHtml += '<li><a href="javascript:doMediaList(\'' + deviceId + '\');" value="MediaList">MediaList</a></li>';

    reloadList(listHtml);

	// Profile一覧に戻るボタン
    reloadContent(getProfileListLink(deviceId));
}



/**
 * MediaPlayer
 *
 * @param deviceId デバイスID
 */
function doMediaList(deviceId) {
	
	initContent();
    initResult();
    
    setTitle("MediaPlayer Media List");
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("media_list");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
    	if(DEBUG) console.log("Response:"+responseText)
        var json = JSON.parse(responseText);

        if (json.result == 0) {
            var str = "";
            for (var i = 0; i < json.media.length; i++) {
                str += '<li><a href="javascript:doMediaPlayer(\'' + deviceId + '\',\'' + json.media[i].mediaId + '\',1);"  >';
                str += json.media[i].title + '</a></li>';
            }

          
			reloadList(str);
			
           
           	// Back button of MediaPlayer menu
           	reloadContent(backMediaPlayer(deviceId));

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {});
}


/**
 * MusicPlayer
 */
function doRegisterOnStatusChange(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("onstatuschange");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri, function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
        console.log(message);
        if (json.mediaPlayer) {
            document.mediaPlayerForm.status.value = json.mediaPlayer.status;
            document.mediaPlayerForm.mediaId.value = json.mediaPlayer.mediaId;
            document.mediaPlayerForm.volume.value = json.mediaPlayer.volume;
            document.mediaPlayerForm.mimeType.value = json.mediaPlayer.mimeType;
        }
    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
}


/**
 * MediaPlayer
 */
function doMediaPlayer(deviceId, id, from) {
	
	
    var sessionKey = "mediaPlayerSocket";
	doRegisterOnStatusChange(deviceId, sessionKey);
            
    var str = "<hr>";
    str += '<form  name="mediaPlayerForm">';
    str += '<input type="text" id="mediaId" width="100%">';
    str += '<input type="text" id="mimeType" width="100%">';
    str += '<input type="text" id="volume" width="100%">';
    str += '<input type="text" id="status" width="100%">';
    str += '</form>';


    str += '<input type="text" value="' + id + '"/>';
    str += '<input data-icon="play" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerPlay(\'' + deviceId + '\');" type="button" value="Play"/>';
    str += '<input data-icon="pause" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerPause(\'' + deviceId + '\');" type="button" value="Pause"/>';
    str += '<input data-icon="stop" data-inline="true" data-mini="true" onclick="javascript:doMediaPlayerStop(\'' + deviceId + '\');" type="button" value="Stop"/>';
    str += '</center>';

	// back button to media player list
	if(from == 1){
		str += backMediaPlayerList(deviceId);
	} else if(from == 2){
		str += backToFileList(deviceId);
	}
	
	reloadContent(str);
	
    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("media");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("mediaId", id);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
       
       if(DEBUG) console.log("Response:"+responseText)
       
       var json = JSON.parse(responseText);

        if (json.result == 0) {
            setTitle("MediaPlayer");


            initListView();
			
		

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });

}

/**
 * MediaPlayer play
 */
function doMediaPlayerPlay(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("play");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}

/**
 * MediaPlayer play
 */
function doMediaPlayerStop(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("stop");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}


/**
 * MediaPlayer play
 */
function doMediaPlayerPause(deviceId) {


    var builder = new dConnect.URIBuilder();
    builder.setProfile("media_player");
    builder.setAttribute("pause");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('PUT', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);

        if (json.result == 0) {

        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}


/**
 * MediaPlayerトップへの戻るボタン.
 * 
 * @param deviceId デバイスID
 */
function backMediaPlayer(deviceId){
	var str = "";
 	str += '<center>';
 	str += '<input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showMediaPlayer(\'' + deviceId + '\');" type="button" value="MediaPlayer TOP"/>';
 	str += '</center>';
	return str;
}


/**
 * MediaPlayer Listへの戻るボタン.
 * 
 * @param deviceId デバイスID
 */
function backMediaPlayerList(deviceId){
	var str = "";
 	str += '<center>';
 	str += '<input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:doMediaList(\'' + deviceId + '\');" type="button" value="MediaPlayer List"/>';
 	str += '</center>';
	return str;
}