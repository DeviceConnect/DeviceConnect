/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/** 
 * Dice
 *
 * @param deviceId デバイスID
 */
function showDice(deviceId) {
    initListView();
    setTitle("Dice Profile(Event)");
	
	initAll();
    setTitle("File Top", "black");

    var str = "";
    var path = "/";
    str += '<li><a href="javascript:showOnRoll(\'' + deviceId + '\',\'' + path + '\');" value="list">onRoll</a></li>';
    str += '<li><a href="javascript:showOnMagnetometer(\'' + deviceId + '\');" value="send">onMagnetometer</a></li>';

    reloadList(str);

    reloadContent(getProfileListLink(deviceId));
}

/**
 * サイコロの目イベント
 *
 * @param deviceId デバイスID
 */
function showOnRoll(deviceId){
	initAll();
	
    var sessionKey = "diceOnRoll";
    
    var str = "";

    str += '<input type="button" onclick="doRegisterDice(\'' + deviceId + '\',\'' + sessionKey  + '\');" value="Register Event" >';
    str += '<form  name="diceForm">';
    str += '<center><img src="./css/images/dice_x.png" id="dice" name="dice"></center>';
    str += '<input type="button" onclick="doUnregisterDice(\'' + deviceId + '\',\'' + sessionKey  + '\');" value="Unregister Event" >';
    str += '</form>';
	str += showDiceButton(deviceId);
	
	reloadContent(str);
}

/**
 * Magnetometerの表示
 *
 * @param deviceId デバイスID
 */
function showOnMagnetometer(deviceId){
	initAll();

    var webSocketName = "diceOnMagnet";
	var str = "";
    str += '<input type="button" onclick="doRegisterMagnetometer(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Register Event" >';
    str += '<form  name="diceForm">';
    str += 'Magnetometer<br>';
    str += makeInputText("X", "x", "x");
    str += makeInputText("Y", "y", "y");
    str += makeInputText("Z", "z", "z");
    str += makeInputText("Filter", "filter", "filter");
    str += makeInputText("Interval", "interval", "interval");
    str += '</form>';
    str += '<input type="button" onclick="doUnregisterMagnetometer(\'' + deviceId + '\', \'' + webSocketName + '\');" value="Unregister Event">';
    
    str += showDiceButton(deviceId);
    
	reloadContent(str);
}


/**
 * Dice ondiceイベントの登録
 *
 * @param deviceId デバイスID
 */
function doRegisterDice(deviceId, sessionKey) {
 
    var builder = new dConnect.URIBuilder();
    builder.setProfile("dice");
    builder.setAttribute("ondice");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    if(DEBUG) console.log("Uri:"+uri)

    dConnect.addEventListener(uri, function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
		
		
        var json = JSON.parse(message);
		
		
		if (json.dice) {
			//document.diceForm.roll.value = json.dice.pip;
			
			var img = document.getElementById('dice');
        	img.src = "./css/images/dice_"+ json.dice.pip + ".png";
        }

    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
}

/**
 * Dice ondiceイベントの削除
 *
 * @param deviceId デバイスID
 */
function doUnregisterDice(deviceId, sessionKey) {
	
    var builder = new dConnect.URIBuilder();
    builder.setProfile("dice");
    builder.setAttribute("ondice");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    if(DEBUG) console.log("Uri:"+uri)

    dConnect.removeEventListener(uri);
}    

/**
 * Dice ondiceイベントの登録
 *
 * @param deviceId デバイスID
 */
function doRegisterMagnetometer(deviceId, sessionKey) {
 
    var builder = new dConnect.URIBuilder();
    builder.setProfile("dice");
    builder.setInterface("magnetometer");
    builder.setAttribute("onmagnetometer");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    if(DEBUG) console.log("Uri:"+uri)

    dConnect.addEventListener(uri, function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
		
        var json = JSON.parse(message);
		
		 if (json.magnetometer) {
			document.diceForm.x.value = json.magnetometer.x;
			document.diceForm.y.value = json.magnetometer.y;
			document.diceForm.z.value = json.magnetometer.z;
			document.diceForm.filter.value = json.magnetometer.filter;
			document.diceForm.interval.value = json.magnetometer.interval;
           
        }

    });
    
    dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
}

/**
 * Dice ondiceイベントの削除
 *
 * @param deviceId デバイスID
 */
function doUnregisterMagnetometer(deviceId, sessionKey) {
	
    var builder = new dConnect.URIBuilder();
    builder.setProfile("dice");
    builder.setInterface("magnetometer");
    builder.setAttribute("onmagnetometer");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey", sessionKey);
    var uri = builder.build();
    if(DEBUG) console.log("Uri:"+uri)

    dConnect.removeEventListener(uri);
}    


/**
 * Diceのメニューに戻るボタン.
 *
 * @param deviceId デバイスID
 */
function showDiceButton(deviceId)
{
    var str = "";
    str += '<center>';
    str += '<input data-icon="home" data-inline="true" data-mini="true" onclick="javascript:showDice(\'' + deviceId +
        '\',\'/\',\'1\');" type="button" value="Dice Top"/>';
    str += '</center>';

    return str;

}