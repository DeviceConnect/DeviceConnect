/**
 notification.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
 
/**
 * Notification Menu
 *
 * @param {String}deviceId デバイスID
 */
function showNotification(deviceId) {
  
    initAll();
	
	var sessionKey = "nortificationEvent";
	
	var btnStr = "";    
    btnStr += getBackButton('Device Top','doNotificationBack', deviceId, sessionKey);
	reloadHeader(btnStr);
	reloadFooter(btnStr);

    
    if(myDeviceName.indexOf("Pebble") != -1){
	
	} else if(myDeviceName.indexOf("SmartWatch") != -1){
	
	} else if(myDeviceName.indexOf("Chromecast") != -1){
	
	} else {
		dConnect.connectWebSocket(sessionKey, function(errorCode, errorMessage) {});
	
    	doRegisterNotificationShow(deviceId, sessionKey);
    	doRegisterNotificationClick(deviceId, sessionKey);
    	doRegisterNotificationClose(deviceId, sessionKey);
    	//doRegisterNotificationError(deviceId, sessionKey);
    }
     
    setTitle("Notification Profile(Notify)");
   
    var str = "";
    str += '<form name="notificationForm">';
     
    if(myDeviceName.indexOf("Pebble") != -1){
	
	} else if(myDeviceName.indexOf("SmartWatch") != -1){
	
	} else if(myDeviceName.indexOf("Chromecast") != -1){
	
	} else  {
   		str += makeInputText("onClick", "click", "click")
   		str += makeInputText("onShow", "show", "show")
   		str += makeInputText("onClose", "close", "close")
   		//str += makeInputText("onError", "error", "error")
    }   
    str += '<br>';
    str += '<center><input type="text" value="hello world!" name="bodyTxt" id="bodyTxt">';
    str += '<SELECT name="type" id="type">';
    str += '<OPTION value="0">Call event</OPTION>';
    str += '<OPTION value="1">Mail event</OPTION>';
    str += '<OPTION value="2">SMS event</OPTION>';
    str += '<OPTION value="3">Normal event</OPTION>';
    str += '</SELECT>';
    str += '</form>';
    str += '<input type="button" onclick="doNotificationNotify(\'' + deviceId + '\');" value="Notify" type="button" >';
    str += '</center>';
	reloadContent(str);
   
}

/**
 * Back Button
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doNotificationBack(deviceId, sessionKey){
	
	if(myDeviceName.indexOf("Pebble") != -1){
	
	} else if(myDeviceName.indexOf("SmartWatch") != -1){
	
	} else if(myDeviceName.indexOf("Chromecast") != -1){
	
	} else {
		doUnregisterNotificationShow(deviceId, sessionKey);
   	 	doUnregisterNotificationClick(deviceId, sessionKey);
   	 	doUnregisterNotificationClose(deviceId, sessionKey);
    	//doUnregisterNotificationError(deviceId, sessionKey);
    }
    searchSystem(deviceId);
}

/**
 * onShowイベントの登録
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doRegisterNotificationShow(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("onshow");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
     
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
       
        document.notificationForm.show.value = json.notificationId;
                
    }, function(error){
    	var json = JSON.parse(error);
    	showError("PUT notification/onshow", json);
    });
}

/**
 * onShowイベントの解除
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doUnregisterNotificationShow(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("onshow");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}


/**
 * onClickイベントの登録
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doRegisterNotificationClick(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("onclick");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
     
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
       
        document.notificationForm.click.value = json.notificationId;
                
    }, function(error){
    	var json = JSON.parse(error);
    	showError("PUT notification/onclick", json);
    });
}

/**
 * onClickイベントの解除
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doUnregisterNotificationClick(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("onclick");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}

/**
 * onCloseイベントの登録
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doRegisterNotificationClose(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("onclose");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
       
        document.notificationForm.close.value = json.notificationId;
                
    }, function(error){
    	var json = JSON.parse(error);
    	showError("PUT notification/onclose", json);
    });   
}

/**
 * onCloseイベントの解除
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doUnregisterNotificationClose(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("onclose");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}


/**
 * onErrorイベントの登録
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doRegisterNotificationError(deviceId, sessionKey) {
    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("onerror");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.addEventListener(uri,function(message) {
        // イベントメッセージが送られてくる
        if(DEBUG) console.log("Event-Message:"+message)
        
        var json = JSON.parse(message);
       
        document.notificationForm.error.value = json.notificationId;
                
    }, function(error){
    	var json = JSON.parse(error);
    	showError("PUT notification/onerror", json);
    });
    
   
}

/**
 * onErrorイベントの解除
 *
 * @param {String}deviceId デバイスID
 * @param {String}sessionKey セッションキー
 */
function doUnregisterNotificationError(deviceId, sessionKey) {

    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("onerror");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("sessionKey",sessionKey);
    var uri = builder.build();
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.removeEventListener(uri);
}

/**
 * Notification(Notify)
 *
 * @param {String}deviceId デバイスID
 */
function doNotificationNotify(deviceId) {
    //var type = document.notificationForm.type.value;¥
    //var txtBody = document.notificationForm.body1.value;
    var type = $('#type').val();
    var txtBody = $('#bodyTxt').val();
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("notify");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("type", type);
    builder.addParameter("body", txtBody);
    var uri = builder.build();

	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('POST', uri, null, null, function(status, headerMap, responseText) {
        
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	var str = "";
        	
        	if(myDeviceName.indexOf("Pebble") != -1){
        	
        	} else if(myDeviceName.indexOf("SmartWatch") != -1){
        	
        	}else {
				str += '<center>';
    			str += '<input type="button" onclick="notificationDel(\'' + deviceId + '\',\'' + json.notificationId + '\');" value="Delete" type="button" >';
 				str += '</center>';
			
				reloadMenu(str)
			}
        } else {
        	showError("POST notification/notify", json);
        }
    }, function(xhr, textStatus, errorThrown) {

    });
   
}

/**
 * ID指定でNotificationを消す
 *
 * @param {String}deviceId デバイスID
 */
function notificationDel(deviceId, notificationId) {
    
    var builder = new dConnect.URIBuilder();
    builder.setProfile("notification");
    builder.setAttribute("notify");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    builder.addParameter("notificationId", notificationId);
    var uri = builder.build();

	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('DELETE', uri, null, null, function(status, headerMap, responseText) {
        
        if(DEBUG) console.log("Response:"+responseText)
        
        var json = JSON.parse(responseText);
        if (json.result == 0) {
         	var str = "";
			reloadMenu(str);
        }
    });
}