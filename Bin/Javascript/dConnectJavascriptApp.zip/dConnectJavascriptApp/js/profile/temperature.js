/**
 dconnectsdk-0.1.0.js
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
 
/** 
 * Templature
 *
 * @param deviceId デバイスID
 */
function showTemperature(deviceId) {
    initListView();
    setTitle("Temperature");
	
	var builder = new dConnect.URIBuilder();
    builder.setProfile("temperature");
    builder.setDeviceId(deviceId);
    builder.setAccessToken(accessToken);
    var uri = builder.build();
	
	if(DEBUG) console.log("Uri:"+uri)
	
    dConnect.execute('GET', uri, null, null, function(status, headerMap, responseText) {
    
    	if(DEBUG) console.log("Response:"+responseText)
    	
        var json = JSON.parse(responseText);

        if (json.result == 0) {
        	var temp = json.temperature * 100;
			temp = Math.round(temp) / 100;
  			
  			var str = "";
  			str += "<center><h1>" + temp + "<h1></center>";
  			str += getProfileListLink(deviceId);
  			reloadContent(str); 
  
        } else {

        }

    }, function(xhr, textStatus, errorThrown) {

    });
}


