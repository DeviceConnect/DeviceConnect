/*
 com.nttdocomo.android.dconnect.deviceplugin.host.camera
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

/**
 * カメラ関連.
 */
package com.nttdocomo.android.dconnect.deviceplugin.host.camera;
