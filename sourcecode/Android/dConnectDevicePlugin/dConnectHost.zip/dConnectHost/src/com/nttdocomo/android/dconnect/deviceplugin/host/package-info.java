/*
 com.nttdocomo.android.dconnect.deviceplugin.host
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */

/**
 * d-Connect ホストデバイスプラグインパッケージ.
 *
 * <h4>対応プロファイル</h4>
 * <ul>
 *   <li>Connect プロファイル</li>
 * </ul>
 */
package com.nttdocomo.android.dconnect.deviceplugin.host;
