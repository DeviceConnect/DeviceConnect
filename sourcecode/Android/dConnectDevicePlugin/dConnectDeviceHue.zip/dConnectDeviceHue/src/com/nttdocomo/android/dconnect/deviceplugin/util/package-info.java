/**
 * Hueデバイスプラグイン.
 */
package com.nttdocomo.android.dconnect.deviceplugin.util;
