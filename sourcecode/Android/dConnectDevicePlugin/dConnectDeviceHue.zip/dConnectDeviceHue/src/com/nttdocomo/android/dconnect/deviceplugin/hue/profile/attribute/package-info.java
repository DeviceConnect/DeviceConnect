/**
 * Hueデバイスプラグイン.
 */
package com.nttdocomo.android.dconnect.deviceplugin.hue.profile.attribute;
