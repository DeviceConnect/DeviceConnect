/**
 * デバイスプラグイン設定画面用Package.
 */
package com.nttdocomo.android.dconnect.deviceplugin.hue.activity;
