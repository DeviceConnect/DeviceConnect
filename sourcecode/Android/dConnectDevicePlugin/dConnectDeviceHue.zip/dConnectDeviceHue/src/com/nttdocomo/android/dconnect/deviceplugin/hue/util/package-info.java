/**
 * Hueデバイスプラグイン.
 */
package com.nttdocomo.android.dconnect.deviceplugin.hue.util;
