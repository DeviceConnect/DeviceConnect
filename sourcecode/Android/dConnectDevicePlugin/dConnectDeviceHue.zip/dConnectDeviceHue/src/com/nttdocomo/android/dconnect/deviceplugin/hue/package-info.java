/**
 * 本デバイスプラグインのプロファイルをdConnectに登録するサービス.
 */
package com.nttdocomo.android.dconnect.deviceplugin.hue;
