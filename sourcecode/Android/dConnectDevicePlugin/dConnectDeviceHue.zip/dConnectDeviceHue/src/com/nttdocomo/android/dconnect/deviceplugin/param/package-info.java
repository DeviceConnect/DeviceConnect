/**
 * Hueデバイスプラグイン.
 */
package com.nttdocomo.android.dconnect.deviceplugin.param;
