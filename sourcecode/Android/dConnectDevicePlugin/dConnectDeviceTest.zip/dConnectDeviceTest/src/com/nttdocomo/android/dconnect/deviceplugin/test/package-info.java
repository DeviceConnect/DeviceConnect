/*
 com.nttdocomo.android.dconnect.deviceplugin.test
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-ConnectManagerのテスト機能を提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.test;
