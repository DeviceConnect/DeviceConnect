/*
 com.nttdocomo.android.dconnect.deviceplugin.test.profile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-ConnectのTest用Profile.
 */
package com.nttdocomo.android.dconnect.deviceplugin.test.profile;
