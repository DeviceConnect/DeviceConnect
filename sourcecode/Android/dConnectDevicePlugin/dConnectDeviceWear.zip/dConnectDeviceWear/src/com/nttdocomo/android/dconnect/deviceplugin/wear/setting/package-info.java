
/**
 * d-Connect DicePlus DevicePlugin の設定画面.
 */
package com.nttdocomo.android.dconnect.deviceplugin.wear.setting;