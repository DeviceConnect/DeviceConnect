/**
 * プロファイル群を提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.sphero.profile;
