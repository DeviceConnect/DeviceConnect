/**
 * 設定画面のクラスを提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.sphero.setting;

