/**
 * d-Connect Sphero DevicePlugin の基本クラスを提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.sphero;
