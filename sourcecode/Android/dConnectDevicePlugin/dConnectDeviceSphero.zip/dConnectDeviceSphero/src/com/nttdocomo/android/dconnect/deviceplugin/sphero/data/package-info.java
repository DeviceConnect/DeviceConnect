/**
 * データクラスを提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.sphero.data;
