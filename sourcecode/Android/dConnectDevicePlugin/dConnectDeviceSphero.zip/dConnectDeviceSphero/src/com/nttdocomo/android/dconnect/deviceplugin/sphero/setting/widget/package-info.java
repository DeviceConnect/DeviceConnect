/**
 * 設定画面のウィジェットを提供する.
 * 
 */
package com.nttdocomo.android.dconnect.deviceplugin.sphero.setting.widget;
