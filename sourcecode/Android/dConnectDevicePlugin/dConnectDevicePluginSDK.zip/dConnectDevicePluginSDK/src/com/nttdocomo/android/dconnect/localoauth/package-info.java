/*
 com.nttdocomo.android.dconnect.localoauth
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * LocalOAuth.
 */
package com.nttdocomo.android.dconnect.localoauth;

