/*
 com.nttdocomo.android.dconnect.localoauth.temp
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * 切り離せないRestletの型を、ここで定義する同名のクラスに置き換えてシンプルに実装する.
 */
package com.nttdocomo.android.dconnect.localoauth.temp;
