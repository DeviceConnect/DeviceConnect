/*
 com.nttdocomo.android.dconnect.localoauth.oauthserver.db
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * LocalOAuthのDB操作に関わるクラスを提供する.
 */
package com.nttdocomo.android.dconnect.localoauth.oauthserver.db;
