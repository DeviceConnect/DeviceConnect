/*
 com.nttdocomo.android.dconnect.provider
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect デバイスプラグインファイル.
 */
package com.nttdocomo.android.dconnect.provider;
