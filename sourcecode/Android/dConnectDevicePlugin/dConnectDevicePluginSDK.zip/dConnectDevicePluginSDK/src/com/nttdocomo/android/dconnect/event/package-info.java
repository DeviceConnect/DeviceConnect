/*
 com.nttdocomo.android.dconnect.event
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * デバイスプラグイン イベントパッケージ.
 */
package com.nttdocomo.android.dconnect.event;
