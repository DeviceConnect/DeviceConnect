/*
 com.nttdocomo.android.dconnect.localoauth.fragment
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * LocalOAuth Fragment.
 */
package com.nttdocomo.android.dconnect.localoauth.fragment;
