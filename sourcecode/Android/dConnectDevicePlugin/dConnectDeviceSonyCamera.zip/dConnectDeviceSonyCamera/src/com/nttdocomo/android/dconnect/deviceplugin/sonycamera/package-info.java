/**
 * SonyCameraデバイスプラグイン.
 */
package com.nttdocomo.android.dconnect.deviceplugin.sonycamera;
