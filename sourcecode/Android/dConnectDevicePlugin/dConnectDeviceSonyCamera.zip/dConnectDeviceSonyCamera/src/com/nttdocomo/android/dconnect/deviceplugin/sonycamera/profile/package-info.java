/**
 * SonyCameraプロファイル群.
 */
package com.nttdocomo.android.dconnect.deviceplugin.sonycamera.profile;
