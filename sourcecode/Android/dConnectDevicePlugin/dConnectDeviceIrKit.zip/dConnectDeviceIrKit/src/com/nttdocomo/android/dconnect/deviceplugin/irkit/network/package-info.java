/**
 * ネットワークに関する機能を提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.irkit.network;
