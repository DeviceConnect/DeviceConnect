/**
 * 設定画面用のFragmentを提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.irkit.settings.fragment;
