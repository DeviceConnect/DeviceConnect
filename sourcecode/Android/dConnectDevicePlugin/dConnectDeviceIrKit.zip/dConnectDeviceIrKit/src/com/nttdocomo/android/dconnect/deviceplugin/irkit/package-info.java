/**
 * IRKitデバイスプラグイン.
 */
package com.nttdocomo.android.dconnect.deviceplugin.irkit;
