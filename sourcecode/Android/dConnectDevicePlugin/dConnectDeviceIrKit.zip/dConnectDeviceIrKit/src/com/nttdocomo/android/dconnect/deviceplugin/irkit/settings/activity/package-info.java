/**
 * 設定画面用のActivityを提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.irkit.settings.activity;
