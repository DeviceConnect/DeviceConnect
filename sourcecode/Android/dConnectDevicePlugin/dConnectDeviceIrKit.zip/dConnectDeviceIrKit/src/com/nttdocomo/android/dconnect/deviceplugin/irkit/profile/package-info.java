/**
 * プロファイルを提供する.
 */
package com.nttdocomo.android.dconnect.deviceplugin.irkit.profile;
