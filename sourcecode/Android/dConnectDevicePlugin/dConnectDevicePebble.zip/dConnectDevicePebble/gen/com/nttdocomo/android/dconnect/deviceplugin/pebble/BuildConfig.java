/** Automatically generated file. DO NOT MODIFY */
package com.nttdocomo.android.dconnect.deviceplugin.pebble;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}