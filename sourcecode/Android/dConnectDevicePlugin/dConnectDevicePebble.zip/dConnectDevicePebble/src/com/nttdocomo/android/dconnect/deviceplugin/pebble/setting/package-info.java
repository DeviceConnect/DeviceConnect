/**
 * d-Connect DicePlus DevicePlugin の設定画面.
 * @author docomo
 */
package com.nttdocomo.android.dconnect.deviceplugin.pebble.setting;