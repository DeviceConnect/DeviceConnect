/**
 * Pebbleとの通信のためのユーティリティ.
 * @author docomo
 */
package com.nttdocomo.android.dconnect.deviceplugin.pebble.util;