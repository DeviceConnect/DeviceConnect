package com.nttdocomo.android.dconnect.deviceplugin.chromecast.profile;

import android.content.Context;

public final class ChromeCastUtil {
    static Context context;
    
    private ChromeCastUtil(final Context context) {
        ChromeCastUtil.context = context;
    }
}
