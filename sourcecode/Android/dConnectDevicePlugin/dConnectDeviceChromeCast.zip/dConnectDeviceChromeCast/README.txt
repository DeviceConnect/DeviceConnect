ChromeCast Device Plugin
----------------------------------------------------------------------------
本プロジェクトをビルドするためには、下記の準備が必要です。

1. dConnectDevicePluginSDK
2. google-play-services_lib 
3. android-support-v7-appcompat
4. android-support-v7-mediarouter

以上