/**
 * SonySmartWatchプロファイル群.
 */
package com.nttdocomo.android.dconnect.deviceplugin.sw.profile;
