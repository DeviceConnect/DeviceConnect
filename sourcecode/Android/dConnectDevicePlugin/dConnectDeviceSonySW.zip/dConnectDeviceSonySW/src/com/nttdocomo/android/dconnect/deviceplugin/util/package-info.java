/**
 * SonySmartWatchユーティリティ群.
 */
package com.nttdocomo.android.dconnect.deviceplugin.util;
