/**
 * SonySmartWatchチュートリアル群.
 */
package com.nttdocomo.android.dconnect.deviceplugin.sw.setting;
