SW Device Plugin
----------------------------------------------------------------------------
本プロジェクトをビルドするためには、下記の準備が必要です。
1. Sony Add-on SDK v3.0のインストール
   以下のURLを参照。
   http://developer.sonymobile.com/knowledge-base/sony-add-on-sdk/install-the-sony-add-on-sdk/

2. SmartExtensionAPIプロジェクトのインポート
2.1. Eclipseのメニュー [File] > [New] > [Project...]を選択
2.2. [Android] > [Android Sample Project]を選択し、Nextを押下。
2.3. Sony Add-on SDK 3.0 を選択し、Nextを押下。
2.4. サンプルの一覧から「SmartExtensions > SmartExtensionAPI」を選択し、Finishを押下。
2.5. SmartExtensionAPIプロジェクトがインポートされる。

3. SmartExtensionUtilsプロジェクトのインポート
上記手順2と同様に、SmartExtensionUtilsプロジェクトをインポートしてください。

以上