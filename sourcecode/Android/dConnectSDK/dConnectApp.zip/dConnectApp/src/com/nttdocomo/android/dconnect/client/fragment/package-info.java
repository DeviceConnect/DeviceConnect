/**
 * d-Connect クライアントフラグメントパッケージ.
 */
package com.nttdocomo.android.dconnect.client.fragment;
