/**
 * d-Connect クライアントフラグメントパッケージ.
 */
package com.nttdocomo.android.dconnect.uiapp.fragment;
