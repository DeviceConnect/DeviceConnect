/**
 * d-Connect クライアントアクティビティパッケージ.
 */
package com.nttdocomo.android.dconnect.client.activity;
