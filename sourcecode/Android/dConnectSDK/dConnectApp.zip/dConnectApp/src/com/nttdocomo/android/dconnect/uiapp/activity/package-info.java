/**
 * d-Connect クライアントアクティビティパッケージ.
 */
package com.nttdocomo.android.dconnect.uiapp.activity;
