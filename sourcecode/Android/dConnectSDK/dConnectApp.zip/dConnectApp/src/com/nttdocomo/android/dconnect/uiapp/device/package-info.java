/**
 * d-Connect デバイス/プロファイルパッケージ.
 */
package com.nttdocomo.android.dconnect.uiapp.device;
