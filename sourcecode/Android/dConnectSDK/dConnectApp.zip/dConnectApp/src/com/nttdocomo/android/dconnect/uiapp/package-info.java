/**
 * d-Connect アプリケーションパッケージ.
 */
package com.nttdocomo.android.dconnect.uiapp;
