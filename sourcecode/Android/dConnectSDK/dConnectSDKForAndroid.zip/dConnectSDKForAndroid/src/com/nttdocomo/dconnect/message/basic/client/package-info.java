/*
 com.nttdocomo.dconnect.message.basic.client
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect のメッセージを用いて通信処理を行うクライアントクラス及びインターフェースを提供する.
 */
package com.nttdocomo.dconnect.message.basic.client;
