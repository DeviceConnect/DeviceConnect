/*
 com.nttdocomo.dconnect.message.basic.conn
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * コネクションの基本実装クラスを提供する.
 */
package com.nttdocomo.dconnect.message.basic.conn;
