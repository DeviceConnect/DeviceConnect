/*
 com.nttdocomo.dconnect.message.conn
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect メッセージコネクションパッケージ.
 */
package com.nttdocomo.dconnect.message.conn;
