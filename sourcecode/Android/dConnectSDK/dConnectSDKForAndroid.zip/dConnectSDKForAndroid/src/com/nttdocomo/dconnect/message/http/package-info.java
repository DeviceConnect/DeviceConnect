/*
 com.nttdocomo.dconnect.message.http
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * HTTPクライアント.
 */
package com.nttdocomo.dconnect.message.http;
