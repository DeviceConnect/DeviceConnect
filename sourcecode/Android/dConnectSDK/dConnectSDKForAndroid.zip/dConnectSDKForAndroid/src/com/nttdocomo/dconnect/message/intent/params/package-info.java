/*
 com.nttdocomo.dconnect.message.intent.params
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Intentパラメータパッケージ.
 */
package com.nttdocomo.dconnect.message.intent.params;
