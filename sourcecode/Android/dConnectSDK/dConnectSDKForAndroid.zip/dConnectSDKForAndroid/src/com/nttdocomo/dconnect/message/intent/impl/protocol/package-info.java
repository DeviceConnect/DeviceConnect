/*
 com.nttdocomo.dconnect.message.intent.impl.io
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 *  Device Connect Intentプロトコルパッケージ.
 */
package com.nttdocomo.dconnect.message.intent.impl.protocol;
