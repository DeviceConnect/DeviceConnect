/*
 com.nttdocomo.dconnect.message.intent.impl.client
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Intentメッセージクライアントパッケージ.
 */
package com.nttdocomo.dconnect.message.intent.impl.client;
