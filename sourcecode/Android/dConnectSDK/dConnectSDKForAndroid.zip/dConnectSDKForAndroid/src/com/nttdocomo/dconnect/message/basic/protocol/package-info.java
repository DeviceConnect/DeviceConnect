/*
 com.nttdocomo.dconnect.message.basic.protocol
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect ベーシックプロトコルパッケージ.
 */
package com.nttdocomo.dconnect.message.basic.protocol;
