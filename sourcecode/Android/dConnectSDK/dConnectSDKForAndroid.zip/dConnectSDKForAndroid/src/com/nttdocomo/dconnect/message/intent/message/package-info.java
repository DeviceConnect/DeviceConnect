/*
 com.nttdocomo.dconnect.message.intent.message
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Intentメッセージパッケージ.
 */
package com.nttdocomo.dconnect.message.intent.message;
