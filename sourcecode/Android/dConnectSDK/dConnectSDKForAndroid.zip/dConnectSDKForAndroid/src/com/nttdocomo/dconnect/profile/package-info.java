/*
 com.nttdocomo.dconnect.profile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * プロファイルの定数群を定義するインターフェースを提供する.
 */
package com.nttdocomo.dconnect.profile;
