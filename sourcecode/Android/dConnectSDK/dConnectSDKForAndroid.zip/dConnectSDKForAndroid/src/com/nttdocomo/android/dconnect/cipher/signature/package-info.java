/*
 com.nttdocomo.android.dconnect.cipher.signature
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect LocalOAuth用のシグネチャ操作に必要なクラスを提供する.
 */
package com.nttdocomo.android.dconnect.cipher.signature;
