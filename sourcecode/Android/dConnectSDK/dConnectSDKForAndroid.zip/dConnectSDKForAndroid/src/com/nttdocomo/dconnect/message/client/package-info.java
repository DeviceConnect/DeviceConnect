/*
 com.nttdocomo.dconnect.message.client
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect のメッセージを用いて通信処理を行うクライアントのインターフェースを提供する.
 */
package com.nttdocomo.dconnect.message.client;
