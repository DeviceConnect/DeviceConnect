/*
 com.nttdocomo.dconnect.message.http.impl.client
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * HTTPメッセージクライアントパッケージ.
 * HTTP通信を行うクライアントクラスを提供する。
 */
package com.nttdocomo.dconnect.message.http.impl.client;
