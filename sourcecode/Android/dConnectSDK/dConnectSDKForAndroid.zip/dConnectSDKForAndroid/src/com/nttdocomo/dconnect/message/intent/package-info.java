/*
 com.nttdocomo.dconnect.message.intent
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 *  Intentをメッセージとして操作するクラスを提供する.
 */
package com.nttdocomo.dconnect.message.intent;
