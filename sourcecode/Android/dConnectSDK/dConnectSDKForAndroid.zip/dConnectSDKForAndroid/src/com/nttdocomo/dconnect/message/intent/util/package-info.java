/*
 com.nttdocomo.dconnect.message.intent.util
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Intent ユーティリティ.
 * Intent API のユーティリティクラスを提供する。
 */
package com.nttdocomo.dconnect.message.intent.util;
