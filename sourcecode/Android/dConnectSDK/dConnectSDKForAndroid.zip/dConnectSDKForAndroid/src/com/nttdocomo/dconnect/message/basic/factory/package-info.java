/*
 com.nttdocomo.dconnect.message.basic.factory
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect メッセージファクトリーパッケージ.
 */
package com.nttdocomo.dconnect.message.basic.factory;
