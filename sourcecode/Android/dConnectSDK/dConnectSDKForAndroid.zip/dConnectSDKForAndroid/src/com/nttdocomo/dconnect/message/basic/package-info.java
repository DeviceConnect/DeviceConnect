/*
 com.nttdocomo.dconnect.message.basic
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect のメッセージを操作するための基本クラスを提供する.
 */
package com.nttdocomo.dconnect.message.basic;
