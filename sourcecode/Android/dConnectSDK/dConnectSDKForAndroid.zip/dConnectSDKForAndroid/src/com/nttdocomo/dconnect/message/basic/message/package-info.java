/*
 com.nttdocomo.dconnect.message.basic.message
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * Device Connect ベーシックメッセージパッケージ.
 */
package com.nttdocomo.dconnect.message.basic.message;
