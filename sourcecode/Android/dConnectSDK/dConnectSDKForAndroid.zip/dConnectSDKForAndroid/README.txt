Device Connect SDK for Android
----------------------------------------------------------------------------
Device Connect SDK for Android は Device Connectアプリケーション のソフトウェア開発キットである。


How to Build
----------------------------------------------------------------------------
ライブラリプロジェクトのビルド

    % cd android
    % android update project -p . -t [Android 4.4 Target] --subprojects
    % ant debug


サンプルアプリケーションのビルドは example/android/README.txt を参照すること



