/*
 com.nttdocomo.android.dconnect.manager.request
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connect Managerのリクエスト処理を行うパッケージ.
 */
package com.nttdocomo.android.dconnect.manager.request;
