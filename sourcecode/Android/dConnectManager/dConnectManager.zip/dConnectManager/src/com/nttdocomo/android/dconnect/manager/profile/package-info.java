/*
 com.nttdocomo.android.dconnect.manager.profile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connect Managerのプロファイル群.
 */
package com.nttdocomo.android.dconnect.manager.profile;
