/*
 com.nttdocomo.android.dconnect.observer.receiver
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connectの監視に関わるBroadCastReceiverのクラスを提供する.
 */
package com.nttdocomo.android.dconnect.observer.receiver;
