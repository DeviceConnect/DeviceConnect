/*
 com.nttdocomo.android.dconnect.manager.util
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connect ManagerのUtilityクラス群.
 */
package com.nttdocomo.android.dconnect.manager.util;
