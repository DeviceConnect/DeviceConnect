/*
 com.nttdocomo.android.dconnect.manager.receiver
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connect Manager関連のReceiverクラス群.
 */
package com.nttdocomo.android.dconnect.manager.receiver;
