/*
 com.nttdocomo.android.dconnect.observer
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connectの監視を行うクラスを提供します.
 */
package com.nttdocomo.android.dconnect.observer;
