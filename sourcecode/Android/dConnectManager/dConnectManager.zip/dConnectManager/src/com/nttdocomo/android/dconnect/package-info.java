/*
 com.nttdocomo.android.dconnect
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connectを管理する.
 */
package com.nttdocomo.android.dconnect;
