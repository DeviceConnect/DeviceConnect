/*
 com.nttdocomo.android.dconnect.observer.activity
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connectの監視に関するActivityクラスを提供します.
 */
package com.nttdocomo.android.dconnect.observer.activity;
