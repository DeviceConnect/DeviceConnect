/*
 com.nttdocomo.android.dconnect.manager.test
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connect Manager本体のテストケース.
 */
package com.nttdocomo.android.dconnect.manager.test;
