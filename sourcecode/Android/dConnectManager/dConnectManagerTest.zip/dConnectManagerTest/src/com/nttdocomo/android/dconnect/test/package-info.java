/*
 com.nttdocomo.android.dconnect.test
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-ConnectのTestCase.
 */
package com.nttdocomo.android.dconnect.test;
