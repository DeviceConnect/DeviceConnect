/*
 com.nttdocomo.android.dconnect.profile.intent.test
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connect Android Intent APIのテストケース.
 * <p>
 * 本パッケージの各テストケースのリクエストに対するレスポンスは、下記のパッケージで定義する.
 * com.nttdocomo.android.dconnect.test.plugin.profile
 * </p>
 */
package com.nttdocomo.android.dconnect.profile.intent.test;
