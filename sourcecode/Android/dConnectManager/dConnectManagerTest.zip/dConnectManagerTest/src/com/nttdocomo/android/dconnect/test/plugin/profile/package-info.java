/*
 com.nttdocomo.android.dconnect.test.plugin.profile
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-ConnectのTest用ProfileConstants.
 */
package com.nttdocomo.android.dconnect.test.plugin.profile;
