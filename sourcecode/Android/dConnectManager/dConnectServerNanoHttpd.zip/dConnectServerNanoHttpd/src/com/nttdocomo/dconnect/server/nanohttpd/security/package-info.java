/*
 com.nttdocomo.dconnect.server.nanohttpd.security
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * DConnectServerNanoHttpd セキュリティーパッケージ.
 */
package com.nttdocomo.dconnect.server.nanohttpd.security;
