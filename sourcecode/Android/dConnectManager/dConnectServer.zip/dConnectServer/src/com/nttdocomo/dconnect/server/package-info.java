/*
 com.nttdocomo.dconnect.server
 Copyright (c) 2014 NTT DOCOMO,INC.
 Released under the MIT license
 http://opensource.org/licenses/mit-license.php
 */
/**
 * d-Connect 仮想サーバーパッケージ.
 */
package com.nttdocomo.dconnect.server;
