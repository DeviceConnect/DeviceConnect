//
//  DPChromecastGuideViewController.h
//  dConnectChromecast
//
//  Created by Takashi Tsuchiya on 2014/09/19.
//  Copyright (c) 2014年 NTT DOCOMO, INC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DPChromecastGuideViewController : UIViewController

@end
