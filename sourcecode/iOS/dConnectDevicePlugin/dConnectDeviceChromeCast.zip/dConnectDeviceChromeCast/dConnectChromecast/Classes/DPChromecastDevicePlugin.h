//
//  DPChromecastDevicePlugin.h
//  dConnectChromecast
//
//  Created by Ryuya Takahashi on 2014/09/03.
//  Copyright (c) 2014年 Docomo. All rights reserved.
//

#import <DConnectSDK/DConnectSDK.h>
#import "DPChromecastManager.h"

@interface DPChromecastDevicePlugin : DConnectDevicePlugin

@end
