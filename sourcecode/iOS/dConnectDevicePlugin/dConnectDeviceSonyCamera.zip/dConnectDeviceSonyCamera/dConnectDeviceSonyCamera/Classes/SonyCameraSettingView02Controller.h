//
//  SonyCameraSettingView02Controller.h
//  dConnectDeviceSonyCamera
//
//  Created by 小林伸郎 on 2014/08/08.
//  Copyright (c) 2014年 小林 伸郎. All rights reserved.
//

#import "SonyCameraDataViewController.h"

/*!
 @brief 2ページ目のViewController。
 */
@interface SonyCameraSettingView02Controller : SonyCameraDataViewController

@end
