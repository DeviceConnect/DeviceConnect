//
//  SonyCameraFlashProfile.m
//  dConnectDeviceSonyCamera
//
//  Created by 小林伸郎 on 2014/07/29.
//  Copyright (c) 2014年 小林 伸郎. All rights reserved.
//

#import "SonyCameraFlashProfile.h"

@implementation SonyCameraFlashProfile

@end
