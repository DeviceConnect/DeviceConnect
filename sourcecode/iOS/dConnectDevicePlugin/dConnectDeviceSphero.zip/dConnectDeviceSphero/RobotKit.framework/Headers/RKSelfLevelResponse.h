//
//  RKSelfLevelResponse.h
//  RobotKit
//
//  Created by Michael DePhillips on 7/14/12.
//  Copyright (c) 2012 Orbotix Inc. All rights reserved.
//

/*! @file */

#import "RKDeviceResponse.h"

@interface RKSelfLevelResponse : RKDeviceResponse

@end
