//
//  RKRemoteSphero.h
//  RobotKit
//
//  Created by Jon Carroll on 8/9/11.
//  Copyright 2011 Orbotix Inc. All rights reserved.
//

#if defined (SRCLIBRARY)
#import <RobotKit/Multiplayer/RKRemoteRobot.h>
#else

#import <RobotKit/RKRemoteRobot.h>

#endif


@interface RKRemoteSphero : RKRemoteRobot {

}

@end
