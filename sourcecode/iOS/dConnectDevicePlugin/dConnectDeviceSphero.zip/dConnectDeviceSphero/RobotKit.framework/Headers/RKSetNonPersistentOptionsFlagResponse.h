//
//  RKReadNonPersistentOptionsFlagResponse.h
//  RobotKit
//
//  Created by wes felteau on 4/16/13.
//  Copyright (c) 2013 Orbotix Inc. All rights reserved.
//

#import <RobotKit/RobotKit.h>

@interface RKSetNonPersistentOptionsFlagResponse : RKDeviceResponse

@end
