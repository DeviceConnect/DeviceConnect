//
//  RKSetOptionFlagsResponse.h
//  RobotKit
//
//  Created by Michael DePhillips on 7/31/12.
//  Copyright (c) 2012 Orbotix Inc. All rights reserved.
//

#import "RKDeviceResponse.h"

@interface RKSetOptionFlagsResponse : RKDeviceResponse

@end
