//
//  RKSetMotionTimeoutResponse.h
//  RobotKit
//
//  Created by Michael DePhillips on 7/31/12.
//  Copyright (c) 2012 Orbotix Inc. All rights reserved.
//

/*! @file */

/*! @sa RKSetMotionTimeoutCommand */

#import "RKDeviceResponse.h"

@interface RKSetMotionTimeoutResponse : RKDeviceResponse

@end
