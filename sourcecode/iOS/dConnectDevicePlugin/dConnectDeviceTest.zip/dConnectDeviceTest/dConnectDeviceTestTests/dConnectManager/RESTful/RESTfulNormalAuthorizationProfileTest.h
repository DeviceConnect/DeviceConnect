//
//  RESTfulNormalAuthorizationProfileTest.h
//  dConnectDeviceTest
//
//  Created by mtaka on 2014/09/02.
//  Copyright (c) 2014年 NTT DOCOMO, INC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RESTfulNormalAuthorizationProfileTest : NSObject

@end
