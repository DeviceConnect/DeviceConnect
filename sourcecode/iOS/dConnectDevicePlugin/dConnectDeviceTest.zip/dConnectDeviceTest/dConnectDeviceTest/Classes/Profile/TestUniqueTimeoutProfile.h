//
//  TestUniqueTimeoutProfile.h
//  dConnectDeviceTest
//
//  Created by Masaru Takano on 2014/08/21.
//  Copyright (c) 2014年 NTT DOCOMO, INC. All rights reserved.
//

#import <DConnectSDK/DConnectSDK.h>

@interface TestUniqueTimeoutProfile : DConnectProfile

@end
