#import "PebbleDataViewController.h"

/*!
 @brief 2ページ目のViewController。
 */
@interface PebbleSettingView02Controller : PebbleDataViewController

@end
