

#import "PebbleDataViewController.h"

/*!
 @brief 1ページ目のViewController。
 */
@interface PebbleSettingView01Controller : PebbleDataViewController

@end
