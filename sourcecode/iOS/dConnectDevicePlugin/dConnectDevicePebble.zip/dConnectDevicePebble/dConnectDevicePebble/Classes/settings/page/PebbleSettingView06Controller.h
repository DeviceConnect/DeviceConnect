

#import "PebbleDataViewController.h"

/*!
 @brief 1ページ目のViewController。
 */
@interface PebbleSettingView06Controller : PebbleDataViewController

@end
