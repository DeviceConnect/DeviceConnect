

#import "PebbleDataViewController.h"

/*!
 @brief 3ページ目のViewController。
 */
@interface PebbleSettingView03Controller : PebbleDataViewController

@end
