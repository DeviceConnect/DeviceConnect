

#import "PebbleDataViewController.h"

/*!
 @brief 4ページ目のViewController。
 */
@interface PebbleSettingView04Controller : PebbleDataViewController

@end
