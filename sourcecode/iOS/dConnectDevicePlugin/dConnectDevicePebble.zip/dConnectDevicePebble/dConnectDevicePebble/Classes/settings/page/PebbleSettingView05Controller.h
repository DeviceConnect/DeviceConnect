

#import "PebbleDataViewController.h"

/*!
 @brief 5ページ目のViewController。
 */
@interface PebbleSettingView05Controller : PebbleDataViewController

@end
