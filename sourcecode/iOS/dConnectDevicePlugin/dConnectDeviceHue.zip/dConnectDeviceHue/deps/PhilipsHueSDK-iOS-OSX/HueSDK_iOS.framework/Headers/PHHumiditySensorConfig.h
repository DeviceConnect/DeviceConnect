/*******************************************************************************
 Copyright (c) 2013-2014 Koninklijke Philips N.V.
 All Rights Reserved.
 ********************************************************************************/

#import "PHSensorConfig.h"

@interface PHHumiditySensorConfig : PHSensorConfig

@end
