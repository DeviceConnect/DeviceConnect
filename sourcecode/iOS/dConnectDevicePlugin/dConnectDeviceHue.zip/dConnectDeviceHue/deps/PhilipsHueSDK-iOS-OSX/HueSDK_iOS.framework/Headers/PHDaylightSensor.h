/*******************************************************************************
 Copyright (c) 2013-2014 Koninklijke Philips N.V.
 All Rights Reserved.
 ********************************************************************************/

#import "PHSensor.h"

@interface PHDaylightSensor : PHSensor

/**
 Supported types:
 - Daylight
 */

@end
