/*******************************************************************************
 Copyright (c) 2013-2014 Koninklijke Philips N.V.
 All Rights Reserved.
 ********************************************************************************/

#import "PHSensor.h"

@interface PHTemperatureSensor : PHSensor

/**
 Supported types:
 - CLIPTemperature
 - ZLLTemperature
 */

@end
