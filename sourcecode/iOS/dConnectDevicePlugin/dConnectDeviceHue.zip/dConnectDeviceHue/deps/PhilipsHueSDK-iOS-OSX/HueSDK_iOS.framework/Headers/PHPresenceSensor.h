/*******************************************************************************
 Copyright (c) 2013-2014 Koninklijke Philips N.V.
 All Rights Reserved.
 ********************************************************************************/

#import "PHSensor.h"

@interface PHPresenceSensor : PHSensor

/**
 Supported types:
 - CLIPPresence
 - ZLLPresence
 */

@end
