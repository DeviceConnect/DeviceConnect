#ifndef Hue_defines_h
#define Hue_defines_h

#define SETTING_PAGE_COUNT_IPHNE 3
#define SETTING_PAGE_COUNT_IPAD 3


#endif
