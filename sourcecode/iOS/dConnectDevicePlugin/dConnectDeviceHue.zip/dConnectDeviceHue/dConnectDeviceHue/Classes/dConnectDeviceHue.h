//
//  dConnectDeviceHue.h
//  dConnectDeviceHue
//
//  Created by 星　貴之 on 2014/07/07.
//  Copyright (c) 2014年 Docomo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <DConnectSDK/DConnectSDK.h>
@interface dConnectDeviceHue : DConnectDevicePlugin


@end
