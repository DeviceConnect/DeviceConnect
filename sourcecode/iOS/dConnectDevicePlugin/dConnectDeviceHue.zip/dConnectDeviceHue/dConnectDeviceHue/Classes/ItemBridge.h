#import <Foundation/Foundation.h>

@interface ItemBridge : NSObject <NSCopying>
@property (nonatomic, copy) NSString *macAdress;
@property (nonatomic, copy) NSString *ipAdress;
@end
