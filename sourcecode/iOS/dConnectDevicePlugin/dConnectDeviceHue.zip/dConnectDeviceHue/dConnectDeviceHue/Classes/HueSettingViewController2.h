//
//  HueSettingViewController2.h
//  dConnectDeviceHue
//
//  Created by DConnect05 on 2014/09/04.
//  Copyright (c) 2014年 Docomo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HueSettingViewControllerBase.h"

@interface HueSettingViewController2 : HueSettingViewControllerBase

@end
