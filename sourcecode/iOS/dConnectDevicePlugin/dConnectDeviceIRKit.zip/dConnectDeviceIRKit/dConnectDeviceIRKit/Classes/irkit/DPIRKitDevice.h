//
//  DPIRKitDevice.h
//  dConnectDeviceIRKit
//
//  Created by 安部 将史 on 2014/08/19.
//  Copyright (c) 2014年 NTT DOCOMO, INC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DPIRKitDevice : NSObject

// Service Info.
@property (nonatomic, copy) NSString *hostName;
@property (nonatomic, copy) NSString *name;

@end
