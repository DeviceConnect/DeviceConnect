//
//  NSString+Hex.h
//  dConnectDeviceIRKit
//
//  Created by 安部 将史 on 2014/08/21.
//  Copyright (c) 2014年 NTT DOCOMO, INC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Hex)

- (NSString *) stringByHexingWithLength:(size_t)length;

@end
