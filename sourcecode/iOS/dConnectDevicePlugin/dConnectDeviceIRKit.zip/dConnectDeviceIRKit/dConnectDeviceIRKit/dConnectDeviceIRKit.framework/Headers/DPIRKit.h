//
//  DPIRKit.h
//  dConnectDeviceIRKit
//
//  Created by 安部 将史 on 2014/08/20.
//  Copyright (c) 2014年 NTT DOCOMO, INC. All rights reserved.
//

/*! @brief プロファイル名: remote_controller。 */
extern NSString *const DPIRKitRemoteControllerProfileName;

/*! @brief パラメータ: message。 */
extern NSString *const DPIRKitRemoteControllerProfileParamMessage;