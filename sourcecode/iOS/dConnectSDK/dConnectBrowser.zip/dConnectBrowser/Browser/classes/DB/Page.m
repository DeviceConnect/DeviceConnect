//
//  Page.m
//  Browser
//
//  Copyright (c) 2014 NTT DOCOMO,INC.
//  Released under the MIT license
//  http://opensource.org/licenses/mit-license.php
//

#import "Page.h"
#import "Page.h"


@implementation Page

@dynamic category;
@dynamic created_date;
@dynamic identifier;
@dynamic priority;
@dynamic sectionIndex;
@dynamic title;
@dynamic type;
@dynamic url;
@dynamic children;
@dynamic parent;

@end
